"""Catalogo experimental de observaciones locales del Digivice Ver. Complete."""

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path


RUTA = Path(__file__).resolve().parent / "data" / "complete_local.json"


def campos(palabras):
    if len(palabras) != 2 or any(((p >> 8) ^ (p & 255)) != 255 for p in palabras):
        raise ValueError("Se necesitan dos paquetes clasicos con bytes complementarios validos.")
    return str((palabras[1] >> 4) & 15), palabras[0] & 15


def cargar(ruta=None):
    destino = ruta or RUTA
    if not destino.exists():
        return {"schema": 1, "modelo": "dcomplete", "observaciones": []}
    return json.loads(destino.read_text(encoding="utf-8"))


def candidatos(version, slot, ruta=None):
    # Una observacion NO demuestra exclusividad. Mejora y resultado son
    # campos variables de batalla: no deben formar parte de la clave.
    return sorted({o["nombre"] for o in cargar(ruta)["observaciones"]
                   if o["version_comunicacion"] == version and o["slot"] == slot})


def registrar(nombre, captura, ruta=None):
    from catalogo import palabras

    nombre = nombre.strip()
    if not nombre:
        raise ValueError("El nombre no puede estar vacio.")
    if captura.get("modelo") != "dcomplete" or captura.get("completo") is not True:
        raise ValueError("Solo se registran capturas completas del modelo dcomplete.")
    codigo = "-".join(captura["recibidos"])
    version, slot = campos(palabras(codigo))
    datos = cargar(ruta)
    observacion = {"nombre": nombre, "version_comunicacion": version, "slot": slot,
                   "codigo_recibido": codigo, "evidencia": "confirmacion_manual_usuario",
                   "fecha_captura": captura.get("fecha"), "comando": captura.get("comando"),
                   "fecha_registro": datetime.now(timezone.utc).isoformat()}
    if not any(o["nombre"] == nombre and o["codigo_recibido"] == codigo
               for o in datos["observaciones"]):
        datos["observaciones"].append(observacion)
        (ruta or RUTA).write_text(json.dumps(datos, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return candidatos(version, slot, ruta)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--nombre", required=True, help="Personaje que seleccionaste fisicamente; no se deduce del codigo.")
    p.add_argument("--capturas", type=Path, default=Path("capturas.jsonl"))
    p.add_argument("--codigo", help="Selecciona una captura recibida exacta; si se omite, usa la ultima completa dcomplete.")
    a = p.parse_args()
    try:
        capturas = [json.loads(l) for l in a.capturas.read_text(encoding="utf-8").splitlines() if l.strip()]
        elegida = next((c for c in reversed(capturas)
                        if c.get("modelo") == "dcomplete" and c.get("completo") is True
                        and (not a.codigo or "-".join(c["recibidos"]).upper() == a.codigo.upper())), None)
        if elegida is None:
            raise ValueError("No hay una captura completa dcomplete que coincida.")
        nombres = registrar(a.nombre, elegida)
        print("Observacion local guardada en:", RUTA)
        print("Codigo:", "-".join(elegida["recibidos"]))
        print("Candidatos observados para version/slot:", ", ".join(nombres))
        print("Esto no verifica que el codigo sea exclusivo; otros personajes pueden compartirlo.")
        return 0
    except (ValueError, OSError, KeyError) as error:
        print("Error:", error)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
