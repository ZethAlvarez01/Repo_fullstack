"""Conectar con el Beta Link o recibir una senal del V-Pet."""

import argparse
import json
import re
import secrets
import time
from datetime import datetime, timezone
from pathlib import Path

import serial
from serial.tools import list_ports

from battle_probability import resolve_battle
from catalogo import cargar_catalogo, identificar, identificar_inicio_batalla, mostrar
from dmc_profiles import load_dmc_profiles
from pen20_profiles import choose_pen20_proxy, load_pen20_profiles
from reference_book import find_profiles


def abrir_serial(puerto, **opciones):
    """Abre un COM local o el socket serial usado por el puente WebUSB."""
    if "://" in str(puerto):
        return serial.serial_for_url(puerto, **opciones)
    return serial.Serial(puerto, **opciones)


# Perfiles de batalla: el Beta Link inicia con un rival de prueba.
# Fuentes: https://humulos.com/digimon/dmx/digirom/
# https://github.com/dmcomm/dmcomm-project/blob/main/codes.txt
# Pen20: sondeo Single Battle de https://humulos.com/digimon/0NL1NE/converter/
PERFILES = {
    "dcomplete": {
        "nombre": "Digivice Ver. Complete (batalla clasica experimental)",
        # Rival clasico documentado por DMComm; NO es el codigo de desbloqueo
        # de emblemas del D2 Complete. Falta validar este sondeo con el aparato.
        "codigo": "V1-FC03-FD02",
        "paquetes": 2,
    },
    "dmx": {
        "nombre": "Digital Monster X",
        "codigo": "V1-800E-218E-483E-142E-010E-@800E",
        "paquetes": 6,
    },
    "penx": {
        "nombre": "Pendulum X",
        "codigo": "X1-0159-4379-0009-C009",
        "paquetes": 4,
    },
    "accel": {
        "nombre": "Digimon Accel (batalla X experimental)",
        # El DigiROM PenX tambien funciona con Accel, Mini e iC por tres pines:
        # https://dmcomm.github.io/guide/nano/
        "codigo": "X1-0159-4379-0009-C009",
        "paquetes": 4,
    },
    "mini": {
        "nombre": "Digimon Mini (batalla X experimental)",
        "codigo": "X1-0159-4379-0009-C009",
        "paquetes": 4,
    },
    "xrosmini": {
        "nombre": "Digimon Xros Wars Mini",
        "codigo": "Y2-1017-0057-0007-@C^1^F7",
        "paquetes": 4,
    },
    "pen20": {
        "nombre": "Pendulum Ver.20th (batalla individual)",
        "codigo": "V1-000E-003E-000E-000E-000E-000E-000E-000E-000E-EF0E",
        "paquetes": 10,
    },
    "dm20": {
        "nombre": "Digital Monster Ver.20th (batalla individual)",
        "codigo": "V1-0101-0101-800E-008E-05AE-01EE-000E-000E-000E-@0F0E",
        "paquetes": 10,
    },
    "penz": {
        "nombre": "Pendulum Z (batalla)",
        "codigo": "V1-836E-212E-288E-182E-018E-@800E",
        "paquetes": 6,
    },
    "dmog": {
        "nombre": "Digital Monster original (versiones 1-5)",
        "codigo": "V1-FC03-FD02",
        "paquetes": 2,
    },
    "penog": {
        "nombre": "Pendulum original (batalla)",
        "codigo": "V1-211F-000F-080F-EABF",
        "paquetes": 4,
    },
}

# Pares publicados y comprobables: nunca se construyen paquetes al azar.
# El resultado se expresa desde el punto de vista del V-Pet fisico.
RESULTADOS_VERIFICADOS = {
    "penx": {
        "rival_protocolo": "Kuwagamon X",
        "vpet_gana": "X1-0159-4379-0009-C009",
        "vpet_pierde": "X1-0159-4379-0009-C1F9",
    },
    "accel": {
        "rival_protocolo": "Kuwagamon X (formato PenX compatible)",
        "vpet_gana": "X1-0159-4379-0009-C009",
        "vpet_pierde": "X1-0159-4379-0009-C1F9",
    },
    "mini": {
        "rival_protocolo": "Kuwagamon X (formato PenX compatible)",
        "vpet_gana": "X1-0159-4379-0009-C009",
        "vpet_pierde": "X1-0159-4379-0009-C1F9",
    },
}

# Los Color intercambian bloques de 128 bits, no palabras de 16 bits.
# Codigos publicados en Humulos /dmc/digirom/ y /penc/digirom/.
for _modelo in ("dmc", "penc", "dmh", "dmgz", "dmxw", "pengz"):
    _pendulum_color = _modelo in ("penc", "pengz")
    PERFILES[_modelo] = {
        "nombre": cargar_catalogo()["familias"][_modelo]["nombre"] + " (perfil Color experimental)",
        "codigo": (
            "C1-47444470001000000002001400038BDD-47444470001200390000000000028C01"
            if _pendulum_color else
            "C1-47444C4300000000000B007300019406-47444C4300020002000000000000938B"
        ),
        "paquetes": 2,
        "digitos_por_paquete": 32,
    }


# Batallas Alpha de una sola conexion. El comando elige el protocolo en el
# firmware; la especie fisica siempre se obtiene de los paquetes recibidos.
BATALLAS_ALPHA = {
    "pen20": {"comando": "A0", "rival_protocolo": "Perfil Pendulum 20th"},
    "penx": {"comando": "A1", "rival_protocolo": "Kuwagamon X"},
    "accel": {"comando": "A1", "rival_protocolo": "Kuwagamon X"},
    "mini": {"comando": "A1", "rival_protocolo": "Kuwagamon X"},
    "dmx": {"comando": "A2", "rival_protocolo": "Agumon X"},
    "penz": {"comando": "A3", "rival_protocolo": "Sunarizamon"},
    "dmc": {"comando": "A4", "rival_protocolo": "Metal Greymon (Virus)"},
    "penc": {"comando": "A5", "rival_protocolo": "Tentomon"},
    "dmh": {"comando": "A6", "rival_protocolo": "Metal Greymon (Virus)"},
    "dmgz": {"comando": "A7", "rival_protocolo": "Metal Greymon (Virus)"},
    "dmxw": {"comando": "A8", "rival_protocolo": "Metal Greymon (Virus)"},
    "pengz": {"comando": "A9", "rival_protocolo": "Tentomon"},
    "dcomplete": {"comando": "B0", "rival_protocolo": "Agumon"},
    "xrosmini": {"comando": "B1", "rival_protocolo": "Shoutmon"},
}

DMC_PROXY_MODELS = {"dmc", "dmh", "dmgz", "dmxw"}


def extraer_consulta_alpha(texto, modelo):
    """Devuelve una consulta completa; nunca acepta un fragmento del serial."""
    coincidencia = re.search(r"(?:^|\n)alpha:q:([0-9A-Fa-f-]+)\n", texto)
    if not coincidencia:
        return None
    consulta = coincidencia.group(1).upper()
    longitud = len(consulta.replace("-", ""))
    if modelo in ("penx", "accel", "mini", "xrosmini", "dcomplete") and longitud != 4:
        return None
    if modelo == "dmx" and longitud != 8:
        return None
    if modelo == "penz" and longitud != 8:
        return None
    if modelo not in ("penx", "accel", "mini", "xrosmini", "dcomplete", "dmx", "penz") and longitud not in (8, 32):
        return None
    if modelo == "dmx" and not re.fullmatch(r"[0-9A-F]{4}-[0-9A-F]{4}", consulta):
        return None
    if modelo == "penz" and not re.fullmatch(r"[0-9A-F]{4}-[0-9A-F]{4}", consulta):
        return None
    return consulta


def analizar_intercambio(linea, cantidad, digitos_por_paquete=4):
    """Analiza UN intento; nunca junta paquetes de batallas distintas."""
    eventos = re.findall(r"(?:^|\s)([rs]):([0-9A-Fa-f]+)(?=\s|$)", linea)
    recibidos = [valor.upper() for tipo, valor in eventos if tipo == "r"]
    enviados = [valor.upper() for tipo, valor in eventos if tipo == "s"]
    # Con V1/X1 la conversacion debe alternar envio y respuesta.
    orden = [tipo for tipo, _ in eventos]
    orden_correcto = orden in (["s", "r"] * cantidad, ["r", "s"] * cantidad)
    timeout_entre_paquetes = re.search(r"\bt\b", linea[:linea.rfind("r:")])
    completo = (
        orden_correcto
        and all(len(valor) == digitos_por_paquete for _, valor in eventos)
        and not timeout_entre_paquetes
        and not re.search(r"\[|\bt:-?\d", linea)
    )
    return {"recibidos": recibidos, "enviados": enviados, "completo": completo}


def resultado_pen20(intercambio):
    """Lee impactos y, si empatan, el nivel de ataque de una batalla Single."""
    if not intercambio.get("completo"):
        return None
    recibidos = intercambio.get("recibidos", [])
    enviados = intercambio.get("enviados", [])
    if len(recibidos) != 10 or len(enviados) != 10:
        return None
    impactos_vpet = ((int(recibidos[-1], 16) >> 4) & 0x0F).bit_count()
    impactos_web = ((int(enviados[-1], 16) >> 4) & 0x0F).bit_count()
    if impactos_vpet == impactos_web:
        ataque_vpet = (int(recibidos[0], 16) >> 12) & 0x0F
        ataque_web = (int(enviados[0], 16) >> 12) & 0x0F
        if ataque_vpet == ataque_web:
            return None
        return "gana" if ataque_vpet > ataque_web else "pierde"
    return "gana" if impactos_vpet > impactos_web else "pierde"


def crear_comando_pen20(comando_alpha, perfil, patron_ataque=None):
    """Construye una mascara Pen20 con una sacudida virtual no nula."""
    if patron_ataque is None:
        patron_ataque = secrets.randbelow(15) + 1
    if not 1 <= patron_ataque <= 15:
        raise ValueError("El patron de ataque Pen20 debe estar entre 1 y 15.")
    comando = "{}:{:04X}:{:04X}:{:04X}:{:04X}".format(
        comando_alpha, patron_ataque << 12, perfil["index"],
        perfil["base_power"], perfil["attribute_word"],
    )
    return comando, patron_ataque


def resultado_dmc(intercambio):
    """Lee la bandera de victoria que el DMC devuelve en su segundo bloque."""
    if not intercambio.get("completo"):
        return None
    recibidos = intercambio.get("recibidos", [])
    if len(recibidos) != 2 or len(recibidos[1]) != 32:
        return None
    words = [int(recibidos[1][i:i + 4], 16) for i in range(0, 32, 4)]
    if words[:3] != [0x4744, 0x4C43, 0x0002]:
        return None
    if (sum(words[:7]) & 0xFFFF) != words[7]:
        return None
    return "gana" if words[4] & 1 else "pierde"


def resultado_xrosmini(intercambio):
    """Decodifica HitMe del cuarto paquete enviado por el Mini fisico."""
    if not intercambio.get("completo"):
        return None
    recibidos = intercambio.get("recibidos", [])
    if len(recibidos) != 4:
        return None
    packet = int(recibidos[-1], 16)
    if packet & 0x0F != 0x07:
        return None
    golpes_recibidos = ((packet >> 4) & 0x1F).bit_count()
    return "pierde" if golpes_recibidos >= 3 else "gana"


def resultado_decision_alpha(texto, resultado_objetivo):
    """Devuelve la decisión que el firmware realmente alcanzó a aplicar."""
    if "alpha:decision:web" in texto:
        return "pierde"
    if "alpha:decision:vpet" in texto or "alpha:decision:timeout-vpet" in texto:
        return "gana"
    return resultado_objetivo


def intercambiar_vpet(
    puerto, espera, modelo, registro, version=None, rival_visual=None,
    resultado_vpet=None, probabilidad_rival=None, probabilidad_efectiva=None,
    ruido=None,
):
    perfil = PERFILES[modelo]
    resultado = RESULTADOS_VERIFICADOS.get(modelo)
    if resultado_vpet:
        if not resultado:
            raise ValueError(f"{modelo} aun no tiene resultados ganar/perder verificados.")
        codigo = resultado["vpet_gana" if resultado_vpet == "gana" else "vpet_pierde"]
    else:
        codigo = perfil["codigo"]
    print(f"Perfil: {perfil['nombre']}. Se esperan {perfil['paquetes']} paquetes por lado.")
    print("ATENCION: este modo realiza una batalla y puede cambiar el record.")
    if rival_visual:
        print(f"Rival web: {rival_visual}")
        print(f"Rival compatible enviado: {resultado['rival_protocolo']}")
        if probabilidad_rival is not None:
            print(f"Probabilidad calculada del rival web: {probabilidad_rival:.1%}")
        if probabilidad_efectiva is not None:
            print(f"Probabilidad efectiva con ruido: {probabilidad_efectiva:.1%}")
    with abrir_serial(puerto, baudrate=9600, timeout=0.2) as conexion:
        time.sleep(2.2)
        conexion.reset_input_buffer()
        conexion.write((codigo + "\n").encode("ascii"))
        conexion.flush()
        print(f"Codigo del rival de prueba: {codigo}", flush=True)
        print("Beta Link inicia automaticamente. Prepara el aparato en modo batalla.", flush=True)
        if modelo == "dmx":
            print("En el Digital Monster X elige CONNECT > X.", flush=True)
        elif modelo == "accel":
            print("En el Digimon Accel elige CONNECT > BATTLE > X (segunda opcion).", flush=True)
            print("Usa el conector de tres pines compatible con timing X; no es infrarrojo.", flush=True)
        elif modelo == "dcomplete":
            print("Perfil experimental: prueba el intercambio clasico de dos paquetes.", flush=True)
            print("En el Ver. Complete selecciona CONNECT y el Digimon para batalla.", flush=True)
            print("Dejalo esperando; Beta Link inicia. No pulses OK para iniciar a la vez.", flush=True)
            print("Se consultara el catalogo local experimental; aun no hay mapa publico verificado.", flush=True)
        elif modelo == "pen20":
            print("En CONNECT/BATTLE del Pendulum 20th elige batalla Ver.20th, individual (SINGLE).", flush=True)
            print("Selecciona un Digimon, completa las sacudidas y deja el aparato listo para conectar.", flush=True)
            print("Usa batalla Ver.20th; evita los modos Pendulum Original/OLD y OTHER.", flush=True)
        elif modelo == "dm20":
            print("Elige batalla Ver.20th individual/SINGLE, no OTHER.", flush=True)
        elif modelo == "penz":
            print("Elige batalla con Pendulum Z, no OTHER ni Jogress.", flush=True)
        elif modelo == "dmog":
            print("Usa un Digital Monster original; OTHER de un modelo moderno no identifica su especie.", flush=True)
        elif modelo == "penog":
            print("Elige batalla nativa de Pendulum original, no OTHER ni Jogress.", flush=True)
        elif codigo.startswith("C"):
            print("Perfil Color experimental: requiere firmware DMComm y circuito compatibles con C.", flush=True)
            print("Elige batalla nativa Color, no OTHER. No se actualiza firmware automaticamente.", flush=True)
        print("Une los contactos y mantenlos hasta terminar el intercambio.", flush=True)
        limite = time.monotonic() + espera
        pendiente = ""
        try:
            while time.monotonic() < limite:
                datos = conexion.read(conexion.in_waiting or 1)
                if not datos:
                    continue
                texto = datos.decode("ascii", errors="replace").replace("\r", "")
                print(texto, end="", flush=True)
                pendiente += texto
                while "\n" in pendiente:
                    linea, pendiente = pendiente.split("\n", 1)
                    resultado = analizar_intercambio(linea, perfil["paquetes"], perfil.get("digitos_por_paquete", 4))
                    if not resultado["recibidos"]:
                        continue
                    captura = {
                        "fecha": datetime.now(timezone.utc).isoformat(),
                        "modelo": modelo,
                        "comando": codigo,
                        "crudo": linea,
                        **resultado,
                    }
                    if rival_visual:
                        captura["rival_visual"] = rival_visual
                        captura["rival_protocolo"] = RESULTADOS_VERIFICADOS[modelo]["rival_protocolo"]
                        captura["resultado_vpet"] = resultado_vpet
                        captura["probabilidad_rival"] = probabilidad_rival
                        captura["probabilidad_efectiva"] = probabilidad_efectiva
                        captura["ruido_probabilidad"] = ruido
                    if resultado["completo"]:
                        captura["identificacion"] = identificar(modelo, "-".join(resultado["recibidos"]), version)
                    with registro.open("a", encoding="utf-8") as archivo:
                        archivo.write(json.dumps(captura, ensure_ascii=False) + "\n")
                    print(f"\nRecibidos ({len(resultado['recibidos'])}):", "-".join(resultado["recibidos"]))
                    print(f"Enviados ({len(resultado['enviados'])}):", "-".join(resultado["enviados"]))
                    print(f"Captura guardada en: {registro.resolve()}")
                    if resultado["completo"]:
                        print("Intercambio completo recibido.")
                        mostrar(captura["identificacion"])
                        if rival_visual and resultado_vpet:
                            nombres = [
                                nombre
                                for item in captura["identificacion"]
                                for nombre in item.get("nombres", [])
                            ]
                            vpet = nombres[0] if len(set(nombres)) == 1 else "V-Pet"
                            ganador = vpet if resultado_vpet == "gana" else rival_visual
                            perdedor = rival_visual if resultado_vpet == "gana" else vpet
                            print(f"Ganador: {ganador}")
                            print(f"Perdedor: {perdedor}")
                        return 0
                    print("Intento parcial; no se combinara con el siguiente. Intenta conectar otra vez.")
        finally:
            # Desactiva el rival automatico incluso al cancelar o terminar.
            conexion.write((codigo[0] + "0\n").encode("ascii"))
            conexion.flush()
    print("\nTermino la espera sin un intercambio completo.")
    return 1


def resolver_rival_detectado(modelo, paquete, rivales, rival_variante, modificador_rival):
    """Identifica los paquetes iniciales y resuelve sin tocar el puerto."""
    identidad = identificar_inicio_batalla(modelo, paquete)
    genericos = {"accel", "mini", "xrosmini", "dcomplete", "dmx"}
    if identidad["estado"] != "identificado" and modelo not in genericos:
        detalle = identidad.get("nota") or "identidad no disponible"
        raise ValueError(f"La lectura {paquete} no identifica un {modelo} de forma unica: {detalle}")
    nombre_vpet = identidad["nombres"][0] if identidad["nombres"] else {
        "accel": "Digimon Accel",
        "mini": "Digimon Mini",
        "xrosmini": "Digimon Xros Wars Mini",
        "dcomplete": "Digivice Ver. Complete",
        "dmx": "Digital Monster X",
    }[modelo]
    perfiles_vpet = find_profiles(nombre_vpet)
    rival = rivales[rival_variante]
    # Crossovers (Monster Hunter/Godzilla) and some Japanese catalog names do
    # not have a direct Reference Book entry. They still battle: absent fields
    # are neutral by configuration instead of silently forcing a winner.
    vpet = perfiles_vpet[0] if perfiles_vpet else {
        "name": nombre_vpet,
        "level": identidad.get("nivel"),
        "attribute": identidad.get("atributo", "Unknown"),
        "antibody": identidad.get("x_antibody", nombre_vpet.casefold().endswith(" x")),
    }
    calculo = resolve_battle({
        "attackerLevel": rival.get("level"),
        "attackerAttribute": rival.get("attribute"),
        "attackerHasXAntibody": rival.get("antibody", False),
        "attackerStatModifier": modificador_rival,
        "defenderLevel": vpet.get("level"),
        "defenderAttribute": vpet.get("attribute"),
        "defenderHasXAntibody": vpet.get("antibody", False),
        "defenderStatModifier": 0,
    })
    return nombre_vpet, identidad, rival, calculo


def batalla_ponderada(
    puerto, espera, modelo, registro, rival_visual, rival_variante=0,
    modificador_rival=0, dmc_proxy_id=None, pen20_proxy_id=None,
):
    """Resuelve y responde durante una sola conexion con el firmware Alpha."""
    if modelo not in BATALLAS_ALPHA:
        raise ValueError("La familia no tiene un flujo Alpha de una sola conexion.")
    if not rival_visual:
        raise ValueError("La batalla ponderada requiere --rival-visual.")

    rivales = find_profiles(rival_visual)
    if not rivales or rival_variante >= len(rivales):
        raise ValueError("El rival web o su variante no existe en el Reference Book.")

    alpha = BATALLAS_ALPHA[modelo]
    perfil = PERFILES[modelo]
    es_color = modelo in ("dmc", "penc", "dmh", "dmgz", "dmxw", "pengz")
    proxy_dmc = None
    proxy_pen20 = None
    ataque_pen20 = None
    if modelo == "pen20" and not pen20_proxy_id:
        selected = rivales[rival_variante]
        proxy_pen20 = choose_pen20_proxy(
            selected.get("level") or "Unknown",
            selected.get("attribute") or "Free",
            selected.get("name") or rival_visual,
        )
        pen20_proxy_id = proxy_pen20["id"]
    if dmc_proxy_id:
        if modelo not in DMC_PROXY_MODELS:
            raise ValueError("La mascara DMC solo puede usarse con familias Color compatibles.")
        proxy_dmc = next(
            (item for item in load_dmc_profiles() if item["id"] == dmc_proxy_id), None,
        )
        if not proxy_dmc or not proxy_dmc["battle_eligible"]:
            raise ValueError("El perfil DMC solicitado no es apto para batalla.")
        command = "{}:{:04X}:{:04X}:{:04X}:{:04X}".format(
            alpha["comando"], proxy_dmc["version_word"], proxy_dmc["slot_word"],
            proxy_dmc["base_power"], proxy_dmc["attribute_word"],
        )
    else:
        command = alpha["comando"]
    if pen20_proxy_id:
        if modelo != "pen20":
            raise ValueError("La mascara Pen20 solo puede usarse con Pendulum Ver.20th.")
        proxy_pen20 = proxy_pen20 or next(
            (item for item in load_pen20_profiles() if item["id"] == pen20_proxy_id), None,
        )
        if not proxy_pen20 or not proxy_pen20["battle_eligible"]:
            raise ValueError("El perfil Pendulum 20th solicitado no es apto para batalla.")
        command, ataque_pen20 = crear_comando_pen20(alpha["comando"], proxy_pen20)
    perfil_nativo = proxy_dmc or proxy_pen20
    print("BATALLA UNICA: el firmware identificara y respondera sin desconectar.", flush=True)
    if modelo == "pen20":
        print("Inicia CONNECT > BATTLE > SINGLE en el Pendulum 20th y completa las sacudidas.", flush=True)
        print(f"Mascara web: {rivales[rival_variante]['name']}", flush=True)
        print(
            f"Combatiente Pen20 enviado: {proxy_pen20['name']} "
            f"({proxy_pen20['level']}, {proxy_pen20['attribute']}, poder {proxy_pen20['base_power']}).",
            flush=True,
        )
        print(f"Sacudida virtual Pen20: {ataque_pen20}/15.", flush=True)
    elif modelo in ("penx", "accel", "mini", "xrosmini"):
        nombre_modelo = {
            "penx": "Pendulum X", "accel": "Digimon Accel", "mini": "Digimon Mini",
            "xrosmini": "Digimon Xros Wars Mini",
        }[modelo]
        print(f"Inicia una batalla en el {nombre_modelo} y manten unidos los tres pines.", flush=True)
    elif modelo == "dcomplete":
        print("Deja el Ver. Complete listo para conectar; Beta Link iniciara la batalla.", flush=True)
    elif modelo in ("dmx", "penz"):
        print("Inicia la batalla nativa X/Z y manten unidos los contactos.", flush=True)
    else:
        print("Inicia la batalla nativa Color y manten unidos los contactos.", flush=True)
        if proxy_dmc:
            print(f"Mascara web: {rivales[rival_variante]['name']}", flush=True)
            print(
                f"Combatiente DMC enviado: {proxy_dmc['name']} "
                f"({proxy_dmc['level']}, {proxy_dmc['attribute']}, poder {proxy_dmc['base_power']}).",
                flush=True,
            )
        else:
            print("Resultado Color experimental: usa potencia extrema y requiere validacion con tu aparato.", flush=True)
    limite = time.monotonic() + espera
    with abrir_serial(puerto, baudrate=9600, timeout=0.01) as conexion:
        time.sleep(2.2)
        conexion.reset_input_buffer()
        listo_mostrado = False
        while time.monotonic() < limite:
            conexion.write((command + "\n").encode("ascii"))
            conexion.flush()
            respuesta = bytearray()
            consulta_atendida = False
            datos_batalla = None
            baudios_rapidos = False
            fin_intento = min(limite, time.monotonic() + 8)
            while time.monotonic() < fin_intento:
                datos = conexion.read(conexion.in_waiting or 1)
                if not datos:
                    continue
                respuesta.extend(datos)
                texto_nuevo = datos.decode("ascii", errors="replace")
                print(texto_nuevo, end="", flush=True)
                texto = respuesta.decode("ascii", errors="replace").replace("\r", "")
                if not baudios_rapidos and "alpha:switch-baud:115200\n" in texto:
                    conexion.baudrate = 115200
                    baudios_rapidos = True
                if not listo_mostrado and re.search(
                    r"(?:^|\n)alpha:armed:family-battle-v(?:[2-9]|[1-9][0-9]+):[0-9A-Z]\n", texto,
                ):
                    listo_mostrado = True
                    print("Listo para la batalla. Conecta tu V-Pet.", flush=True)
                consulta = extraer_consulta_alpha(texto, modelo)
                if consulta and not consulta_atendida:
                    consulta_atendida = True
                    paquete = consulta
                    try:
                        if perfil_nativo:
                            identidad = identificar_inicio_batalla(modelo, paquete)
                            if identidad["estado"] != "identificado":
                                detalle = identidad.get("nota") or "identidad no disponible"
                                raise ValueError(
                                    f"La lectura {paquete} no identifica un {modelo} de forma unica: {detalle}"
                                )
                            nombre_vpet = identidad["nombres"][0]
                            rival = rivales[rival_variante]
                            calculo = None
                            resultado_vpet = None
                        else:
                            nombre_vpet, identidad, rival, calculo = resolver_rival_detectado(
                                modelo, paquete, rivales, rival_variante, modificador_rival,
                            )
                            resultado_vpet = "pierde" if calculo["winner"] == "attacker" else "gana"
                            decision = b"W\n" if resultado_vpet == "pierde" else b"P\n"
                        datos_batalla = (nombre_vpet, identidad, rival, calculo, resultado_vpet)
                    except ValueError as error:
                        # Nunca dejamos colgado al juguete: el V-Pet gana como respaldo seguro.
                        decision = b"P\n"
                        print(f"\nError de identidad: {error}", flush=True)
                    if not perfil_nativo:
                        conexion.write(decision)
                        conexion.flush()
                    if datos_batalla:
                        nombre_vpet, identidad, rival, calculo, resultado_vpet = datos_batalla
                        print(f"\nDigimon: {nombre_vpet}", flush=True)
                        if identidad.get("nivel") or identidad.get("atributo"):
                            print(
                                "Datos V-Pet: {} | {} | {}".format(
                                    identidad.get("nivel") or "Sin dato",
                                    identidad.get("atributo") or "Sin dato",
                                    "X-Antibody" if identidad.get("x_antibody") else "Normal",
                                ),
                                flush=True,
                            )
                        if proxy_dmc:
                            print("Perfil DMC autentico enviado; el V-Pet Color resolvera la batalla.", flush=True)
                        elif proxy_pen20:
                            print("Perfil Pendulum 20th autentico enviado; el V-Pet resolvera la batalla.", flush=True)
                        else:
                            desglose = calculo["breakdown"]
                            print(
                                "Desglose: nivel={levelProbability:.1%}, atributo={attributeModifier:+.1%}, "
                                "X-Antibody={xAntibodyModifier:+.1%}, estadisticas={statsModifier:+.1%}.".format(**desglose),
                                flush=True,
                            )
                            print(f"Probabilidad calculada del rival web: {calculo['attackerWinProbability']:.1%}", flush=True)
                            print(f"Ruido aplicado: {calculo['noiseModifier']:+.1%}", flush=True)
                            print(f"Probabilidad efectiva del rival web: {calculo['effectiveAttackerWinProbability']:.1%}", flush=True)
                        if es_color and not proxy_dmc:
                            print("Perfil ponderado enviado; el V-Pet Color resolvera el resultado.", flush=True)
                        elif not es_color:
                            print("Resultado enviado dentro de la misma conexion.", flush=True)
                if "alpha:done:default-mode" not in texto:
                    continue
                if baudios_rapidos:
                    conexion.baudrate = 9600
                    baudios_rapidos = False
                linea = next((item for item in texto.splitlines() if "s:" in item and "r:" in item), "")
                if not datos_batalla and proxy_dmc and linea:
                    preliminar = analizar_intercambio(
                        linea, perfil["paquetes"], perfil.get("digitos_por_paquete", 4),
                    )
                    if preliminar["recibidos"]:
                        identidad = identificar_inicio_batalla(modelo, preliminar["recibidos"][0])
                        if identidad["estado"] == "identificado":
                            nombre_vpet = identidad["nombres"][0]
                            rival = rivales[rival_variante]
                            datos_batalla = (nombre_vpet, identidad, rival, None, None)
                            print(f"\nDigimon: {nombre_vpet}", flush=True)
                            print("Perfil DMC autentico enviado; el V-Pet Color resolvera la batalla.", flush=True)
                if not datos_batalla:
                    break

                nombre_vpet, _, rival, calculo, resultado_vpet = datos_batalla
                intercambio = analizar_intercambio(
                    linea, perfil["paquetes"], perfil.get("digitos_por_paquete", 4),
                )
                resultado_objetivo_vpet = resultado_vpet
                if modelo == "xrosmini":
                    resultado_vpet = resultado_xrosmini(intercambio)
                elif not es_color and not proxy_pen20:
                    resultado_vpet = resultado_decision_alpha(texto, resultado_vpet)
                captura = {
                    "fecha": datetime.now(timezone.utc).isoformat(),
                    "modelo": modelo,
                    "comando": f"alpha-single-battle-v12:{modelo}",
                    "crudo": linea,
                    **intercambio,
                    "rival_visual": rival["name"],
                    "rival_protocolo": perfil_nativo["name"] if perfil_nativo else alpha["rival_protocolo"],
                }
                if calculo:
                    captura.update({
                        "probabilidad_rival": calculo["attackerWinProbability"],
                        "probabilidad_efectiva": calculo["effectiveAttackerWinProbability"],
                        "ruido_probabilidad": calculo["noiseModifier"],
                    })
                if modelo == "xrosmini" or resultado_vpet != resultado_objetivo_vpet:
                    captura["resultado_objetivo_vpet"] = resultado_objetivo_vpet
                if proxy_dmc:
                    captura["perfil_dmc"] = {
                        key: proxy_dmc[key]
                        for key in ("id", "display_id", "name", "level", "attribute", "base_power")
                    }
                if proxy_pen20:
                    captura["perfil_pen20"] = {
                        key: proxy_pen20[key]
                        for key in ("id", "index", "name", "level", "attribute", "base_power")
                    }
                    captura["perfil_pen20"]["attack_pattern"] = ataque_pen20
                if es_color:
                    if resultado_vpet:
                        captura["resultado_objetivo_vpet"] = resultado_vpet
                    if modelo == "dmc":
                        resultado_vpet = resultado_dmc(intercambio)
                    if resultado_vpet:
                        captura["resultado_vpet"] = resultado_vpet
                    captura["resultado_confirmado"] = bool(resultado_vpet)
                elif proxy_pen20:
                    resultado_vpet = resultado_pen20(intercambio)
                    if resultado_vpet:
                        captura["resultado_vpet"] = resultado_vpet
                    captura["resultado_confirmado"] = bool(resultado_vpet)
                else:
                    captura["resultado_vpet"] = resultado_vpet
                    captura["resultado_confirmado"] = True
                if intercambio["completo"]:
                    captura["identificacion"] = identificar(modelo, "-".join(intercambio["recibidos"]))
                    nombres_completos = {
                        nombre
                        for item in captura["identificacion"]
                        for nombre in item.get("nombres", [])
                    }
                    if len(nombres_completos) == 1:
                        nombre_completo = next(iter(nombres_completos))
                        if nombre_completo != nombre_vpet:
                            nombre_vpet = nombre_completo
                            print(f"Digimon: {nombre_vpet}")
                with registro.open("a", encoding="utf-8") as archivo:
                    archivo.write(json.dumps(captura, ensure_ascii=False) + "\n")
                print(f"Captura guardada en: {registro.resolve()}")
                if not intercambio["completo"]:
                    print("El V-Pet rechazo o interrumpio la respuesta; no se registra un ganador.")
                    return 1
                if es_color:
                    if resultado_vpet:
                        ganador = nombre_vpet if resultado_vpet == "gana" else rival["name"]
                        perdedor = rival["name"] if resultado_vpet == "gana" else nombre_vpet
                        print(f"Ganador: {ganador}")
                        print(f"Perdedor: {perdedor}")
                    else:
                        print("Batalla completada. El resultado real lo determina y muestra el V-Pet Color.")
                    return 0
                if proxy_pen20:
                    if not resultado_vpet:
                        print("Batalla completada. No se pudo desempatar el marcador recibido.")
                        return 0
                    ganador = nombre_vpet if resultado_vpet == "gana" else rival["name"]
                    perdedor = rival["name"] if resultado_vpet == "gana" else nombre_vpet
                    print(f"Ganador: {ganador}")
                    print(f"Perdedor: {perdedor}")
                    return 0
                ganador = nombre_vpet if resultado_vpet == "gana" else rival["name"]
                perdedor = rival["name"] if resultado_vpet == "gana" else nombre_vpet
                print(f"Ganador: {ganador}")
                print(f"Perdedor: {perdedor}")
                return 0

    print("\nTermino la espera sin una batalla completa.")
    return 1


def encontrar_puerto():
    """Busca el adaptador USB CH340 usado por este Beta Link."""
    puertos = [
        puerto.device
        for puerto in list_ports.comports()
        if puerto.vid == 0x1A86 and puerto.pid in (0x7523, 0x5523)
    ]
    if len(puertos) != 1:
        raise RuntimeError(
            "No encontre un unico CH340. Indica el puerto con --puerto COM5."
        )
    return puertos[0]


def leer_beta_link(puerto):
    # El firmware DMComm de nuestro Beta Link usa 9600 baudios.
    with abrir_serial(puerto, baudrate=9600, timeout=0.2) as conexion:
        # Abrir el puerto puede reiniciar el Arduino del Beta Link.
        time.sleep(2.2)
        conexion.reset_input_buffer()

        # 'i' pide informacion al firmware; '\n' termina el comando.
        conexion.write(b"i\n")
        conexion.flush()

        respuesta = bytearray()
        limite = time.monotonic() + 3
        while time.monotonic() < limite:
            respuesta.extend(conexion.read(conexion.in_waiting or 1))

    return respuesta.decode("ascii", errors="replace").strip()


def recibir_vpet(puerto, espera, tipo="V0"):
    """Escucha con el timing elegido y muestra los mensajes recibidos."""
    with abrir_serial(puerto, baudrate=9600, timeout=0.2) as conexion:
        time.sleep(2.2)
        conexion.reset_input_buffer()
        print(f"Escuchando con {tipo} (solo recepcion).", flush=True)
        if tipo == "V0":
            print("Modo V: timing para V-Pets de dos contactos.", flush=True)
            print("En Digital Monster X usa CONNECT > X; en otros, su modo de conexion.", flush=True)
        elif tipo == "X0":
            print("Modo X: timing para aparatos compatibles de tres pines.", flush=True)
            print("Usa el adaptador compatible e inicia la conexion en el Pendulum X, Accel, Mini o iC.", flush=True)
        else:
            print("Modo Color: requiere firmware y circuito compatibles con C.", flush=True)
        print("Manten los contactos unidos. Ctrl+C para salir.\n", flush=True)
        limite = time.monotonic() + espera

        while time.monotonic() < limite:
            # Cada intento de escucha del firmware puede terminar sin senal.
            conexion.write((tipo + "\n").encode("ascii"))
            conexion.flush()
            fin_intento = min(limite, time.monotonic() + 7)
            respuesta = bytearray()
            while time.monotonic() < fin_intento:
                datos = conexion.read(conexion.in_waiting or 1)
                if datos:
                    respuesta.extend(datos)
                    print(datos.decode("ascii", errors="replace"), end="", flush=True)

            # r:XXXX significa que el Beta Link recibio un paquete del V-Pet.
            texto = respuesta.decode("ascii", errors="replace")
            for linea in texto.replace("\r", "").split("\n"):
                paquetes = re.findall(r"(?:^|\s)r:([0-9A-Fa-f]+)(?=\s|$)", linea)
                if paquetes:
                    print("\n\nSenal recibida del V-Pet:", "-".join(paquetes).upper())
                    print("Para identificarlo, usa un intercambio completo con --modelo.")
                    return 0

    print("\nNo se recibieron paquetes durante el tiempo de espera.")
    return 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--puerto", help="Ejemplo: COM5. Se detecta si se omite.")
    modos = parser.add_mutually_exclusive_group()
    modos.add_argument("--recibir", action="store_true", help="Escucha al V-Pet usando el tipo elegido.")
    modos.add_argument("--intercambiar", action="store_true", help="Realiza una batalla para recibir todos los paquetes.")
    modos.add_argument("--batalla-ponderada", action="store_true", help="Detecta el V-Pet, calcula probabilidades y ejecuta una batalla Alpha.")
    modos.add_argument("--identificar", action="store_true", help="Identifica un codigo guardado sin abrir el puerto USB.")
    modos.add_argument("--catalogo", action="store_true", help="Muestra la cobertura de identificadores por familia.")
    parser.add_argument("--modelo", choices=sorted(set(cargar_catalogo()["familias"]) | set(PERFILES)), help="Familia del aparato; consulta --catalogo para ver cobertura.")
    parser.add_argument("--codigo", help="Paquetes recibidos para --identificar.")
    parser.add_argument("--version", help="Version fisica DMOG (1-5), o version del catalogo al identificar.")
    parser.add_argument("--registro", type=Path, default=Path("capturas.jsonl"), help="Archivo de capturas del intercambio.")
    parser.add_argument("--rival-visual", help="Digimon mostrado en la interfaz; no altera la especie del protocolo.")
    parser.add_argument("--rival-variante", type=int, default=0, help="Indice de variante del rival en el Reference Book.")
    parser.add_argument("--modificador-rival", type=float, default=0, help="Ajuste estadistico del rival web.")
    parser.add_argument("--dmc-proxy-id", help="Perfil DMC autentico usado como mascara de protocolo Color.")
    parser.add_argument("--pen20-proxy-id", help="Perfil autentico usado como mascara Pendulum Ver.20th.")
    parser.add_argument("--resultado-vpet", choices=("gana", "pierde"), help="Usa un resultado documentado para el V-Pet fisico.")
    parser.add_argument("--probabilidad-rival", type=float, help="Probabilidad base calculada para el rival web.")
    parser.add_argument("--probabilidad-efectiva", type=float, help="Probabilidad aplicada despues del ruido.")
    parser.add_argument("--ruido", type=float, help="Ruido aplicado a la probabilidad de batalla.")
    parser.add_argument(
        "--tipo", type=str.upper, choices=("V0", "X0", "C0"), default="V0",
        help="V0=dos contactos clasicos; X0=tres pines (PenX/Accel/Mini/iC); C0=Color. Por defecto: V0.",
    )
    parser.add_argument("--espera", type=float, default=60, help="Segundos de escucha (60 por defecto).")
    args = parser.parse_args()
    if args.espera <= 0:
        parser.error("--espera debe ser mayor que cero")
    if args.catalogo:
        for modelo, familia in cargar_catalogo()["familias"].items():
            filas = familia["entradas"]
            mapeadas = sum(e["identificador"] is not None for e in filas)
            lectura = "intercambio disponible" if modelo in PERFILES else "consulta offline; sin perfil USB"
            if modelo in PERFILES and PERFILES[modelo]["codigo"].startswith("C"):
                lectura = "perfil Color experimental; requiere firmware compatible"
            print(f"{modelo}: {mapeadas}/{len(filas)} registros con ID; {lectura}")
        for modelo in PERFILES.keys() - cargar_catalogo()["familias"].keys():
            print(f"{modelo}: catalogo local de observaciones; intercambio clasico experimental")
        return 0
    if args.identificar:
        if not args.modelo or not args.codigo:
            parser.error("--identificar requiere --modelo y --codigo")
        try:
            mostrar(identificar(args.modelo, args.codigo, args.version))
            return 0
        except ValueError as error:
            parser.error(str(error))
    modo_batalla = args.intercambiar or args.batalla_ponderada
    if modo_batalla and not args.modelo:
        parser.error("la batalla requiere --modelo: " + ", ".join(PERFILES))
    if modo_batalla and args.modelo not in PERFILES:
        parser.error("Esta familia tiene catalogo offline pero aun no tiene perfil de intercambio USB. Usa --identificar con una captura compatible.")
    if args.intercambiar and args.modelo == "dmog" and args.version not in ("1", "2", "3", "4", "5"):
        parser.error("Para DMOG indica la version fisica con --version 1..5")
    if args.batalla_ponderada and args.modelo not in BATALLAS_ALPHA:
        parser.error("--batalla-ponderada admite: " + ", ".join(BATALLAS_ALPHA))
    if args.batalla_ponderada and not args.rival_visual:
        parser.error("--batalla-ponderada requiere --rival-visual")
    if args.rival_variante < 0:
        parser.error("--rival-variante no puede ser negativo")
    if args.modelo and not modo_batalla:
        parser.error("--modelo se utiliza con --intercambiar o --batalla-ponderada")

    try:
        puerto = args.puerto or encontrar_puerto()
        print(f"Abriendo {puerto} a 9600 baudios...")
        if args.batalla_ponderada:
            return batalla_ponderada(
                puerto, args.espera, args.modelo, args.registro,
                args.rival_visual, args.rival_variante, args.modificador_rival,
                args.dmc_proxy_id, args.pen20_proxy_id,
            )
        if args.intercambiar:
            return intercambiar_vpet(
                puerto, args.espera, args.modelo, args.registro, args.version,
                args.rival_visual, args.resultado_vpet, args.probabilidad_rival,
                args.probabilidad_efectiva, args.ruido,
            )
        if args.recibir:
            return recibir_vpet(puerto, args.espera, args.tipo)
        respuesta = leer_beta_link(puerto)
        if not respuesta:
            print("El puerto abrio, pero no recibimos respuesta al comando i.")
            return 1
        print(f"Respuesta del dispositivo:\n{respuesta}")
        if "dmcomm" not in respuesta.lower():
            print("Hay respuesta, pero no pude confirmar que sea DMComm.")
            return 1
        print("\nBeta Link conectado y respondiendo correctamente.")
        return 0
    except (serial.SerialException, RuntimeError, ValueError, OSError) as error:
        print(f"Error: {error}")
        print("Verifica el USB y cierra otras aplicaciones que usen el puerto.")
        return 1
    except KeyboardInterrupt:
        print("\nRecepcion cancelada. Puerto cerrado.")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
