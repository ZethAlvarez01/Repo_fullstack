import unittest

from battle_probability import calculateBattleProbability, resolve_battle


def matchup(**overrides):
    params = {
        "attackerLevel": "Rookie",
        "attackerAttribute": "Free",
        "attackerHasXAntibody": False,
        "attackerStatModifier": 0,
        "defenderLevel": "Rookie",
        "defenderAttribute": "Free",
        "defenderHasXAntibody": False,
        "defenderStatModifier": 0,
    }
    params.update(overrides)
    return calculateBattleProbability(params)


class BattleProbabilityTests(unittest.TestCase):
    def test_rookie_vaccine_against_rookie_virus_is_65_percent(self):
        result = matchup(attackerAttribute="Vaccine", defenderAttribute="Virus")
        self.assertEqual(result["attackerWinProbability"], 0.65)

    def test_rookie_vaccine_against_rookie_data_is_35_percent(self):
        result = matchup(attackerAttribute="Vaccine", defenderAttribute="Data")
        self.assertEqual(result["attackerWinProbability"], 0.35)

    def test_rookie_against_champion_is_40_percent(self):
        result = matchup(defenderLevel="Champion")
        self.assertEqual(result["attackerWinProbability"], 0.4)

    def test_champion_against_rookie_is_60_percent(self):
        result = matchup(attackerLevel="Champion")
        self.assertEqual(result["attackerWinProbability"], 0.6)

    def test_large_level_gaps_are_weighted_more_heavily(self):
        neutral = matchup(attackerLevel="Mega", defenderLevel="Rookie")
        disadvantaged = matchup(
            attackerLevel="Mega", attackerAttribute="Vaccine",
            defenderLevel="Rookie", defenderAttribute="Data",
        )
        self.assertEqual(neutral["attackerWinProbability"], 0.9)
        self.assertEqual(disadvantaged["attackerWinProbability"], 0.75)

    def test_same_level_and_attribute_is_50_percent(self):
        result = matchup(attackerAttribute="Virus", defenderAttribute="Virus")
        self.assertEqual(result["attackerWinProbability"], 0.5)
        self.assertEqual(result["defenderWinProbability"], 0.5)

    def test_attacker_with_x_against_normal_is_55_percent(self):
        result = matchup(attackerHasXAntibody=True)
        self.assertEqual(result["attackerWinProbability"], 0.55)

    def test_in_training_levels_have_only_five_percent_against_fighters(self):
        baby_one = matchup(
            attackerLevel="In-Training I", attackerAttribute="Vaccine",
            attackerHasXAntibody=True, attackerStatModifier=1,
            defenderLevel="Rookie", defenderAttribute="Virus",
        )
        baby_two = matchup(attackerLevel="In-Training II", defenderLevel="Mega")
        self.assertEqual(baby_one["attackerWinProbability"], 0.05)
        self.assertEqual(baby_two["attackerWinProbability"], 0.05)
        self.assertEqual(baby_one["breakdown"]["attributeModifier"], 0)

    def test_fighter_has_ninety_five_percent_against_in_training(self):
        result = matchup(
            attackerLevel="Rookie", attackerAttribute="Data",
            defenderLevel="In-Training II", defenderAttribute="Virus",
            defenderHasXAntibody=True, defenderStatModifier=1,
        )
        self.assertEqual(result["attackerWinProbability"], 0.95)

    def test_non_combatant_matchup_does_not_receive_noise(self):
        result = resolve_battle(
            {**matchup_params(), "attackerLevel": "In-Training II"},
            rng=lambda: 1.0,
        )
        self.assertEqual(result["noiseModifier"], 0)
        self.assertEqual(result["effectiveAttackerWinProbability"], 0.05)

    def test_minimum_and_maximum_are_clamped(self):
        minimum = matchup(attackerStatModifier=-5)
        maximum = matchup(attackerStatModifier=5)
        self.assertEqual(minimum["attackerWinProbability"], 0.05)
        self.assertEqual(maximum["attackerWinProbability"], 0.95)

    def test_noise_is_separate_and_injectable(self):
        values = iter((1.0, 0.52))
        result = resolve_battle(matchup_params(), rng=lambda: next(values))
        self.assertEqual(result["noiseModifier"], 0.03)
        self.assertEqual(result["effectiveAttackerWinProbability"], 0.53)
        self.assertEqual(result["winner"], "attacker")


def matchup_params():
    return {
        "attackerLevel": "Rookie",
        "attackerAttribute": "Free",
        "attackerHasXAntibody": False,
        "attackerStatModifier": 0,
        "defenderLevel": "Rookie",
        "defenderAttribute": "Free",
        "defenderHasXAntibody": False,
        "defenderStatModifier": 0,
    }


if __name__ == "__main__":
    unittest.main()
