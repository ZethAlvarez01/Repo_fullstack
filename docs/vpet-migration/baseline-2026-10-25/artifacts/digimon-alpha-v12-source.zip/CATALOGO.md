# Catalogo de identidad Digimon

Solo identificador y nombre; no contiene estadisticas de combate.

La clave completa es familia + version/espacio de nombres + identificador.
Un numero de album o el orden de una lista no se convierte automaticamente en un ID del cable.
PENDIENTE significa que existe el roster pero falta una correspondencia verificada.

## Cobertura

| Familia | Con ID | Sin ID |
| --- | ---: | ---: |
| Digital Monster Ver.20th | 154 | 0 |
| Pendulum Ver.20th | 263 | 0 |
| Digital Monster X | 248 | 0 |
| Pendulum Z | 251 | 0 |
| Digital Monster Color | 90 | 0 |
| Pendulum Color | 331 | 0 |
| Digital Monster Color Monster Hunter | 38 | 0 |
| Digital Monster Color Godzilla | 34 | 0 |
| Digital Monster Color Xros Wars | 95 | 0 |
| Pendulum Color Godzilla | 58 | 0 |
| Digital Monster original | 60 | 10 |
| Pendulum original | 123 | 12 |
| Pendulum Progress | 0 | 69 |
| Pendulum X | 3 | 65 |
| Digimon Accel | 0 | 122 |
| Digimon Mini | 0 | 43 |

La cobertura de IDs no implica soporte USB ni prueba fisica de todos los modelos.
Los Color requieren firmware y circuito compatibles; no se actualiza firmware automaticamente.
DMX puede ocultar su indice. OTHER transmite slots compartidos y no identifica la especie moderna.

## Digital Monster Ver.20th (dm20)

Indice global de especie; comun a los colores/versiones compatibles del modelo.

| Version | Identificador | Digimon |
| --- | --- | --- |
| comun | 0 (0x00) | Botamon |
| comun | 1 (0x01) | Koromon |
| comun | 2 (0x02) | Agumon |
| comun | 3 (0x03) | Betamon |
| comun | 4 (0x04) | Greymon |
| comun | 5 (0x05) | Tyranomon |
| comun | 6 (0x06) | Devimon |
| comun | 7 (0x07) | Meramon |
| comun | 8 (0x08) | Airdramon |
| comun | 9 (0x09) | Seadramon |
| comun | 10 (0x0A) | Numemon |
| comun | 11 (0x0B) | Metal Greymon |
| comun | 12 (0x0C) | Mamemon |
| comun | 13 (0x0D) | Monzaemon |
| comun | 14 (0x0E) | Blitz Greymon |
| comun | 15 (0x0F) | Bancho Mamemon |
| comun | 16 (0x10) | Punimon |
| comun | 17 (0x11) | Tunomon |
| comun | 18 (0x12) | Gabumon |
| comun | 19 (0x13) | Elecmon |
| comun | 20 (0x14) | Kabuterimon |
| comun | 21 (0x15) | Garurumon |
| comun | 22 (0x16) | Angemon |
| comun | 23 (0x17) | Yukidarumon |
| comun | 24 (0x18) | Birdramon |
| comun | 25 (0x19) | Whamon |
| comun | 26 (0x1A) | Vegimon |
| comun | 27 (0x1B) | Skull Greymon |
| comun | 28 (0x1C) | Metal Mamemon |
| comun | 29 (0x1D) | Vademon |
| comun | 30 (0x1E) | Skull Mammon |
| comun | 31 (0x1F) | Cres Garurumon |
| comun | 32 (0x20) | Poyomon |
| comun | 33 (0x21) | Tokomon |
| comun | 34 (0x22) | Patamon |
| comun | 35 (0x23) | Kunemon |
| comun | 36 (0x24) | Unimon |
| comun | 37 (0x25) | Centalmon |
| comun | 38 (0x26) | Ogremon |
| comun | 39 (0x27) | Bakemon |
| comun | 40 (0x28) | Shellmon |
| comun | 41 (0x29) | Drimogemon |
| comun | 42 (0x2A) | Scumon |
| comun | 43 (0x2B) | Andromon |
| comun | 44 (0x2C) | Giromon |
| comun | 45 (0x2D) | Etemon |
| comun | 46 (0x2E) | Hi Andromon |
| comun | 47 (0x2F) | King Etemon |
| comun | 48 (0x30) | Yuramon |
| comun | 49 (0x31) | Tanemon |
| comun | 50 (0x32) | Piyomon |
| comun | 51 (0x33) | Palmon |
| comun | 52 (0x34) | Monochromon |
| comun | 53 (0x35) | Cockatrimon |
| comun | 54 (0x36) | Leomon |
| comun | 55 (0x37) | Kuwagamon |
| comun | 56 (0x38) | Coelamon |
| comun | 57 (0x39) | Mojyamon |
| comun | 58 (0x3A) | Nanimon |
| comun | 59 (0x3B) | Megadramon |
| comun | 60 (0x3C) | Piccolomon |
| comun | 61 (0x3D) | Digitamamon |
| comun | 62 (0x3E) | Aegisdramon |
| comun | 63 (0x3F) | Titamon |
| comun | 64 (0x40) | Zurumon |
| comun | 65 (0x41) | Pagumon |
| comun | 66 (0x42) | Gazimon |
| comun | 67 (0x43) | Gizamon |
| comun | 68 (0x44) | Dark Tyranomon |
| comun | 69 (0x45) | Cyclomon |
| comun | 70 (0x46) | Devidramon |
| comun | 71 (0x47) | Tuskmon |
| comun | 72 (0x48) | Flymon |
| comun | 73 (0x49) | Deltamon |
| comun | 74 (0x4A) | Raremon |
| comun | 75 (0x4B) | Metal Tyranomon |
| comun | 76 (0x4C) | Nanomon |
| comun | 77 (0x4D) | Ex-Tyranomon |
| comun | 78 (0x4E) | Mugendramon |
| comun | 79 (0x4F) | Pinochimon |
| comun | 80 (0x50) | Sakumon |
| comun | 81 (0x51) | Sakuttomon |
| comun | 82 (0x52) | Zubamon |
| comun | 83 (0x53) | Zubaeagermon |
| comun | 84 (0x54) | Duramon |
| comun | 85 (0x55) | Durandamon |
| comun | 86 (0x56) | Hackmon |
| comun | 87 (0x57) | Bao Hackmon |
| comun | 88 (0x58) | Savior Hackmon |
| comun | 89 (0x59) | Jesmon |
| comun | 90 (0x5A) | Petitmon |
| comun | 91 (0x5B) | Babydmon |
| comun | 92 (0x5C) | Dracomon |
| comun | 93 (0x5D) | Coredramon (Blue) |
| comun | 94 (0x5E) | Wingdramon |
| comun | 95 (0x5F) | Slayerdramon |
| comun | 96 (0x60) | Coredramon (Green) |
| comun | 97 (0x61) | Groundramon |
| comun | 98 (0x62) | Breakdramon |
| comun | 99 (0x63) | Pitchmon |
| comun | 100 (0x64) | Pukamon |
| comun | 101 (0x65) | Coronamon |
| comun | 102 (0x66) | Firamon |
| comun | 103 (0x67) | Flaremon |
| comun | 104 (0x68) | Apollomon |
| comun | 105 (0x69) | Lunamon |
| comun | 106 (0x6A) | Lekismon |
| comun | 107 (0x6B) | Crescemon |
| comun | 108 (0x6C) | Dianamon |
| comun | 109 (0x6D) | Taichi's Agumon |
| comun | 110 (0x6E) | Taichi's Greymon |
| comun | 111 (0x6F) | Taichi's Metal Greymon |
| comun | 112 (0x70) | Taichi's War Greymon |
| comun | 113 (0x71) | Yamato's Gabumon |
| comun | 114 (0x72) | Yamato's Garurumon |
| comun | 115 (0x73) | Yamato's Were Garurumon |
| comun | 116 (0x74) | Yamato's Metal Garurumon |
| comun | 117 (0x75) | Dodomon |
| comun | 118 (0x76) | Dorimon |
| comun | 119 (0x77) | DORUmon |
| comun | 120 (0x78) | DORUgamon |
| comun | 121 (0x79) | DORUguremon |
| comun | 122 (0x7A) | Alphamon |
| comun | 123 (0x7B) | Yukimibotamon |
| comun | 124 (0x7C) | Nyaromon |
| comun | 125 (0x7D) | Plotmon |
| comun | 126 (0x7E) | Meicoomon |
| comun | 127 (0x7F) | Meicrackmon |
| comun | 128 (0x80) | Rasielmon |
| comun | 129 (0x81) | Omegamon Alter S |
| comun | 130 (0x82) | Rust Tyranomon |
| comun | 131 (0x83) | Examon |
| comun | 132 (0x84) | Grace Novamon |
| comun | 133 (0x85) | Omegamon |
| comun | 134 (0x86) | Lucemon: Falldown Mode |
| comun | 135 (0x87) | Beelzebumon |
| comun | 136 (0x88) | Belphemon: Rage Mode |
| comun | 137 (0x89) | Lilithmon |
| comun | 138 (0x8A) | Demon |
| comun | 139 (0x8B) | Barbamon |
| comun | 140 (0x8C) | Leviamon |
| comun | 141 (0x8D) | Belial Vamdemon |
| comun | 142 (0x8E) | Deathmon |
| comun | 143 (0x8F) | Murmukusmon |
| comun | 144 (0x90) | Imperialdramon: Paladin Mode |
| comun | 145 (0x91) | Ulforce V-dramon |
| comun | 146 (0x92) | Sleipmon |
| comun | 147 (0x93) | Duftmon |
| comun | 148 (0x94) | Magnamon |
| comun | 149 (0x95) | Lord Knightmon |
| comun | 150 (0x96) | Craniummon |
| comun | 151 (0x97) | Dynasmon |
| comun | 152 (0x98) | Gankoomon |
| comun | 153 (0x99) | Dukemon |

Fuente: https://humulos.com/digimon/dm20/list/

## Pendulum Ver.20th (pen20)

Indice global de especie; comun a los colores/versiones compatibles del modelo.

| Version | Identificador | Digimon |
| --- | --- | --- |
| comun | 1 (0x01) | Bubbmon |
| comun | 2 (0x02) | Mochimon |
| comun | 3 (0x03) | Tentomon |
| comun | 4 (0x04) | Gottsumon |
| comun | 5 (0x05) | Otamamon |
| comun | 6 (0x06) | Kabuterimon |
| comun | 7 (0x07) | Tortamon |
| comun | 8 (0x08) | Monochromon |
| comun | 9 (0x09) | Starmon |
| comun | 10 (0x0A) | Gekomon |
| comun | 11 (0x0B) | Kuwagamon |
| comun | 12 (0x0C) | Tailmon |
| comun | 13 (0x0D) | Atlur Kabuterimon |
| comun | 14 (0x0E) | Jyagamon |
| comun | 15 (0x0F) | Triceramon |
| comun | 16 (0x10) | Piccolomon |
| comun | 17 (0x11) | Tonosama Gekomon |
| comun | 18 (0x12) | Okuwamon |
| comun | 19 (0x13) | Angewomon |
| comun | 20 (0x14) | Herakle Kabuterimon |
| comun | 21 (0x15) | Saber Leomon |
| comun | 22 (0x16) | Holydramon |
| comun | 23 (0x17) | Metal Etemon |
| comun | 24 (0x18) | Pitchmon |
| comun | 25 (0x19) | Pukamon |
| comun | 26 (0x1A) | Gomamon |
| comun | 27 (0x1B) | Ganimon |
| comun | 28 (0x1C) | Shakomon |
| comun | 29 (0x1D) | Rukamon |
| comun | 30 (0x1E) | Ikkakumon |
| comun | 31 (0x1F) | Seadramon |
| comun | 32 (0x20) | Coelamon |
| comun | 33 (0x21) | Octmon |
| comun | 34 (0x22) | Gesomon |
| comun | 35 (0x23) | Ebidramon |
| comun | 36 (0x24) | Whamon |
| comun | 37 (0x25) | Zudomon |
| comun | 38 (0x26) | Mega Seadramon |
| comun | 39 (0x27) | Anomalocarimon |
| comun | 40 (0x28) | Dagomon |
| comun | 41 (0x29) | Marin Devimon |
| comun | 42 (0x2A) | Hangyomon |
| comun | 43 (0x2B) | Marin Angemon |
| comun | 44 (0x2C) | Metal Seadramon |
| comun | 45 (0x2D) | Pukumon |
| comun | 46 (0x2E) | Plesiomon |
| comun | 47 (0x2F) | Mokumon |
| comun | 48 (0x30) | Peti Meramon |
| comun | 49 (0x31) | Bakumon |
| comun | 50 (0x32) | Candmon |
| comun | 51 (0x33) | Pico Devimon |
| comun | 52 (0x34) | Hanumon |
| comun | 53 (0x35) | Garurumon |
| comun | 54 (0x36) | Meramon |
| comun | 55 (0x37) | Wizarmon |
| comun | 56 (0x38) | Devimon |
| comun | 57 (0x39) | Bakemon |
| comun | 58 (0x3A) | Dokugumon |
| comun | 59 (0x3B) | Mammon |
| comun | 60 (0x3C) | Were Garurumon |
| comun | 61 (0x3D) | Death Meramon |
| comun | 62 (0x3E) | Pumpmon |
| comun | 63 (0x3F) | Vamdemon |
| comun | 64 (0x40) | Fantomon |
| comun | 65 (0x41) | Lady Devimon |
| comun | 66 (0x42) | Skull Mammon |
| comun | 67 (0x43) | Boltmon |
| comun | 68 (0x44) | Demon |
| comun | 69 (0x45) | Piemon |
| comun | 70 (0x46) | Nyokimon |
| comun | 71 (0x47) | Pyocomon |
| comun | 72 (0x48) | Piyomon |
| comun | 73 (0x49) | Floramon |
| comun | 74 (0x4A) | Mushmon |
| comun | 75 (0x4B) | Palmon |
| comun | 76 (0x4C) | V-dramon |
| comun | 77 (0x4D) | Birdramon |
| comun | 78 (0x4E) | Togemon |
| comun | 79 (0x4F) | Kiwimon |
| comun | 80 (0x50) | Woodmon |
| comun | 81 (0x51) | Red Vegimon |
| comun | 82 (0x52) | Aero V-dramon |
| comun | 83 (0x53) | Garudamon |
| comun | 84 (0x54) | Blossomon |
| comun | 85 (0x55) | Delumon |
| comun | 86 (0x56) | Jyureimon |
| comun | 87 (0x57) | Gerbemon |
| comun | 88 (0x58) | Lilimon |
| comun | 89 (0x59) | Hououmon |
| comun | 90 (0x5A) | Griffomon |
| comun | 91 (0x5B) | Pinochimon |
| comun | 92 (0x5C) | Rosemon |
| comun | 93 (0x5D) | Choromon |
| comun | 94 (0x5E) | Caprimon |
| comun | 95 (0x5F) | Toy Agumon |
| comun | 96 (0x60) | Kokuwamon |
| comun | 97 (0x61) | Hagurumon |
| comun | 98 (0x62) | Greymon |
| comun | 99 (0x63) | Revolmon |
| comun | 100 (0x64) | Tankmon |
| comun | 101 (0x65) | Clockmon |
| comun | 102 (0x66) | Guardromon |
| comun | 103 (0x67) | Mechanorimon |
| comun | 104 (0x68) | Thunderballmon |
| comun | 105 (0x69) | Metal Greymon |
| comun | 106 (0x6A) | Andromon |
| comun | 107 (0x6B) | Knightmon |
| comun | 108 (0x6C) | Big Mamemon |
| comun | 109 (0x6D) | Megadramon |
| comun | 110 (0x6E) | Waru Monzaemon |
| comun | 111 (0x6F) | Cyberdramon |
| comun | 112 (0x70) | War Greymon |
| comun | 113 (0x71) | Metal Garurumon |
| comun | 114 (0x72) | Mugendramon |
| comun | 115 (0x73) | Venom Vamdemon |
| comun | 116 (0x74) | Yukimi Botamon |
| comun | 117 (0x75) | Nyaromon |
| comun | 118 (0x76) | Agumon |
| comun | 119 (0x77) | Gabumon |
| comun | 120 (0x78) | Plotmon |
| comun | 121 (0x79) | Leomon |
| comun | 122 (0x7A) | Igamon |
| comun | 123 (0x7B) | Angemon |
| comun | 124 (0x7C) | Asuramon |
| comun | 125 (0x7D) | Metal Mamemon |
| comun | 126 (0x7E) | Holy Angemon |
| comun | 127 (0x7F) | Seraphimon |
| comun | 128 (0x80) | Ofanimon |
| comun | 129 (0x81) | Phascomon |
| comun | 130 (0x82) | Impmon |
| comun | 131 (0x83) | Porcupamon |
| comun | 132 (0x84) | Mad Leomon |
| comun | 133 (0x85) | Shadramon |
| comun | 134 (0x86) | Troopmon |
| comun | 135 (0x87) | Astamon |
| comun | 136 (0x88) | Baalmon |
| comun | 137 (0x89) | Dark Knightmon |
| comun | 138 (0x8A) | Belphemon: Rage Mode |
| comun | 139 (0x8B) | Beelzebumon |
| comun | 140 (0x8C) | Botamon |
| comun | 141 (0x8D) | Koromon |
| comun | 142 (0x8E) | Guilmon |
| comun | 143 (0x8F) | Bushi Agumon |
| comun | 144 (0x90) | Growmon |
| comun | 145 (0x91) | Reppamon |
| comun | 146 (0x92) | Arresterdramon |
| comun | 147 (0x93) | Manbomon |
| comun | 148 (0x94) | Megalo Growmon |
| comun | 149 (0x95) | Beowolfmon |
| comun | 150 (0x96) | Rize Greymon |
| comun | 151 (0x97) | Dukemon |
| comun | 152 (0x98) | Duftmon |
| comun | 153 (0x99) | Sakumon |
| comun | 154 (0x9A) | Sakuttomon |
| comun | 155 (0x9B) | Zubamon |
| comun | 156 (0x9C) | Hackmon |
| comun | 157 (0x9D) | Zubaeagermon |
| comun | 158 (0x9E) | Bao Hackmon |
| comun | 159 (0x9F) | Targetmon |
| comun | 160 (0xA0) | Duramon |
| comun | 161 (0xA1) | Savior Hackmon |
| comun | 162 (0xA2) | Etemon |
| comun | 163 (0xA3) | Durandamon |
| comun | 164 (0xA4) | Jesmon |
| comun | 165 (0xA5) | Jesmon X |
| comun | 166 (0xA6) | Bancho Leomon |
| comun | 167 (0xA7) | Petitmon |
| comun | 168 (0xA8) | Babydmon |
| comun | 169 (0xA9) | Dracomon |
| comun | 170 (0xAA) | Agumon Hakase |
| comun | 171 (0xAB) | Coredramon (Blue) |
| comun | 172 (0xAC) | Coredramon (Green) |
| comun | 173 (0xAD) | Devidramon |
| comun | 174 (0xAE) | Wingdramon |
| comun | 175 (0xAF) | Groundramon |
| comun | 176 (0xB0) | Slayerdramon |
| comun | 177 (0xB1) | Breakdramon |
| comun | 178 (0xB2) | Darkdramon |
| comun | 179 (0xB3) | Zerimon |
| comun | 180 (0xB4) | Gummymon |
| comun | 181 (0xB5) | Terriermon |
| comun | 182 (0xB6) | Galgomon |
| comun | 183 (0xB7) | Rapidmon |
| comun | 184 (0xB8) | Saint Galgomon |
| comun | 185 (0xB9) | Cocomon |
| comun | 186 (0xBA) | Chocomon |
| comun | 187 (0xBB) | Lopmon |
| comun | 188 (0xBC) | Turuiemon |
| comun | 189 (0xBD) | Andiramon |
| comun | 190 (0xBE) | Cherubimon |
| comun | 191 (0xBF) | Cotsucomon |
| comun | 192 (0xC0) | Kakkinmon |
| comun | 193 (0xC1) | Ludomon |
| comun | 194 (0xC2) | Tia Ludomon |
| comun | 195 (0xC3) | Raiji Ludomon |
| comun | 196 (0xC4) | Bryweludramon |
| comun | 197 (0xC5) | Vorvomon |
| comun | 198 (0xC6) | Lavorvomon |
| comun | 199 (0xC7) | Lavogaritamon |
| comun | 200 (0xC8) | Volcanicdramon |
| comun | 201 (0xC9) | Chicomon |
| comun | 202 (0xCA) | Chibimon |
| comun | 203 (0xCB) | V-mon |
| comun | 204 (0xCC) | XV-mon |
| comun | 205 (0xCD) | Ulforce V-dramon |
| comun | 206 (0xCE) | Meicoomon |
| comun | 207 (0xCF) | Meicrackmon: Vicious Mode |
| comun | 208 (0xD0) | Raguelmon |
| comun | 209 (0xD1) | Fufumon |
| comun | 210 (0xD2) | Kyokyomon |
| comun | 211 (0xD3) | Ryudamon |
| comun | 212 (0xD4) | Ginryumon |
| comun | 213 (0xD5) | Hisyaryumon |
| comun | 214 (0xD6) | Ouryumon |
| comun | 215 (0xD7) | Budmon |
| comun | 216 (0xD8) | Lalamon |
| comun | 217 (0xD9) | Sunflowmon |
| comun | 218 (0xDA) | Lilamon |
| comun | 219 (0xDB) | Lotusmon |
| comun | 220 (0xDC) | Dodomon |
| comun | 221 (0xDD) | Dorimon |
| comun | 222 (0xDE) | DORUmon |
| comun | 223 (0xDF) | DORUgamon |
| comun | 224 (0xE0) | DORUguremon |
| comun | 225 (0xE1) | DORUgoramon |
| comun | 226 (0xE2) | Alphamon |
| comun | 227 (0xE3) | Omegamon |
| comun | 228 (0xE4) | Ogudomon |
| comun | 229 (0xE5) | Ordinemon |
| comun | 230 (0xE6) | Paildramon |
| comun | 231 (0xE7) | Imperialdramon: Fighter Mode |
| comun | 232 (0xE8) | Voltobautamon |
| comun | 233 (0xE9) | Beelzebumon: Blast Mode |
| comun | 234 (0xEA) | Ragna Lordmon |
| comun | 235 (0xEB) | Alphamon: Ouryuken |
| comun | 236 (0xEC) | Rafflesimon |
| comun | 237 (0xED) | Mastemon |
| comun | 238 (0xEE) | Chaosmon |
| comun | 239 (0xEF) | Examon |
| comun | 240 (0xF0) | Imperialdramon: Paladin Mode |
| comun | 241 (0xF1) | Magnamon |
| comun | 242 (0xF2) | Dynasmon |
| comun | 243 (0xF3) | Craniummon |
| comun | 244 (0xF4) | Gankoomon |
| comun | 245 (0xF5) | Lord Knightmon |
| comun | 246 (0xF6) | Sleipmon |
| comun | 247 (0xF7) | Ofanimon: Falldown Mode |
| comun | 248 (0xF8) | Beel Starmon |
| comun | 249 (0xF9) | Stingmon |
| comun | 250 (0xFA) | Susanoomon |
| comun | 251 (0xFB) | Apocalymon |
| comun | 252 (0xFC) | N.E.O |
| comun | 253 (0xFD) | Herissmon |
| comun | 254 (0xFE) | Blucomon |
| comun | 255 (0xFF) | Sistermon Ciel |
| comun | 256 (0x100) | Sistermon Blanc |
| comun | 257 (0x101) | Sistermon Noir |
| comun | 258 (0x102) | Lilithmon |
| comun | 259 (0x103) | Leviamon |
| comun | 260 (0x104) | Barbamon |
| comun | 261 (0x105) | Lucemon: Falldown Mode |
| comun | 262 (0x106) | Omegamon Alter-S |
| comun | 263 (0x107) | Rust Tyranomon |

Fuente: https://humulos.com/digimon/pen20/list/

## Digital Monster X (dmx)

XA-XF; el indice puede venir oculto como 0. No se infiere una especie a partir de estadisticas.

| Version | Identificador | Digimon |
| --- | --- | --- |
| XA | 0 (0x00) | Puttimon |
| XB | 0 (0x00) | Puttimon |
| XA | 1 (0x01) | Tokomon X |
| XB | 1 (0x01) | Tokomon X |
| XB | 2 (0x02) | Dracomon X |
| XB | 3 (0x03) | Gabumon X |
| XB | 4 (0x04) | Sistermon Blanc |
| XA | 5 (0x05) | Renamon X |
| XA | 6 (0x06) | Agumon X |
| XA | 7 (0x07) | Herissmon |
| XB | 8 (0x08) | Growmon X |
| XB | 9 (0x09) | Rhinomon X |
| XB | 10 (0x0A) | Sistermon Ciel |
| XA | 11 (0x0B) | Leomon X |
| XA | 12 (0x0C) | Tyranomon X |
| XA | 13 (0x0D) | Sangloupmon |
| XA | 14 (0x0E) | Damemon |
| XB | 14 (0x0E) | Damemon |
| XB | 15 (0x0F) | Megalo Growmon X |
| XB | 16 (0x10) | Were Garurumon X |
| XB | 17 (0x11) | Cho-Hakkaimon |
| XB | 18 (0x12) | Lilimon X |
| XA | 19 (0x13) | Cerberumon X |
| XA | 20 (0x14) | Metal Greymon X |
| XA | 21 (0x15) | Lucemon: Falldown Mode |
| XA | 22 (0x16) | Skull Baluchimon |
| XA | 23 (0x17) | Metal Tyranomon X |
| XB | 23 (0x17) | Metal Tyranomon X |
| XA | 24 (0x18) | Yatagaramon |
| XB | 24 (0x18) | Yatagaramon |
| XB | 25 (0x19) | Craniummon X |
| XB | 26 (0x1A) | Metal Garurumon X |
| XB | 27 (0x1B) | Beel Starmon X |
| XB | 28 (0x1C) | Megidramon X |
| XA | 29 (0x1D) | Sleipmon X |
| XA | 30 (0x1E) | War Greymon X |
| XA | 31 (0x1F) | Sakuyamon X |
| XA | 32 (0x20) | Beelzebumon X |
| XA | 33 (0x21) | Jesmon X |
| XB | 33 (0x21) | Jesmon X |
| XA | 34 (0x22) | Valdurmon |
| XB | 34 (0x22) | Valdurmon |
| XA | 35 (0x23) | Belial Vamdemon |
| XB | 35 (0x23) | Belial Vamdemon |
| XA | 36 (0x24) | Rafflesimon |
| XB | 36 (0x24) | Rafflesimon |
| XA | 37 (0x25) | Platinum Numemon |
| XB | 37 (0x25) | Platinum Numemon |
| XA | 38 (0x26) | Omegamon X |
| XB | 38 (0x26) | Omegamon X |
| XA | 39 (0x27) | Diablomon X |
| XB | 39 (0x27) | Diablomon X |
| XA | 40 (0x28) | Dukemon X |
| XB | 40 (0x28) | Dukemon X |
| XA | 41 (0x29) | Alphamon |
| XB | 41 (0x29) | Alphamon |
| XA | 42 (0x2A) | Minervamon X |
| XB | 43 (0x2B) | Lord Knightmon X |
| XA | 44 (0x2C) | Tobucatmon |
| XB | 44 (0x2C) | Tobucatmon |
| XC | 0 (0x00) | Kiimon |
| XD | 0 (0x00) | Kiimon |
| XC | 1 (0x01) | Yaamon |
| XD | 1 (0x01) | Yaamon |
| XC | 2 (0x02) | Agumon (Black) X |
| XC | 3 (0x03) | Gomamon X |
| XC | 4 (0x04) | Kokuwamon X |
| XD | 5 (0x05) | Impmon X |
| XD | 6 (0x06) | Plotmon X |
| XD | 7 (0x07) | Otamamon X |
| XC | 8 (0x08) | Herissmon |
| XD | 8 (0x08) | Herissmon |
| XC | 9 (0x09) | Duskmon |
| XD | 9 (0x09) | Duskmon |
| XC | 10 (0x0A) | Dark Tyranomon X |
| XC | 11 (0x0B) | Mantaraymon X |
| XC | 12 (0x0C) | Kuwagamon X |
| XD | 13 (0x0D) | Ogremon X |
| XD | 14 (0x0E) | Nefertimon X |
| XD | 15 (0x0F) | Seadramon X |
| XC | 16 (0x10) | Allomon X |
| XD | 16 (0x10) | Allomon X |
| XC | 17 (0x11) | Numemon X |
| XD | 17 (0x11) | Numemon X |
| XC | 18 (0x12) | Filmon |
| XD | 18 (0x12) | Filmon |
| XC | 19 (0x13) | Velgrmon |
| XD | 19 (0x13) | Velgrmon |
| XC | 20 (0x14) | Metal Greymon (Virus) X |
| XC | 21 (0x15) | Lady Devimon X |
| XC | 22 (0x16) | Okuwamon X |
| XC | 23 (0x17) | Triceramon X |
| XD | 24 (0x18) | Vamdemon X |
| XD | 25 (0x19) | Mephismon X |
| XD | 26 (0x1A) | Mega Seadramon X |
| XD | 27 (0x1B) | Metal Fantomon |
| XC | 28 (0x1C) | Mammon X |
| XD | 28 (0x1C) | Mammon X |
| XC | 29 (0x1D) | Mametyramon |
| XD | 29 (0x1D) | Mametyramon |
| XC | 30 (0x1E) | Stiffilmon |
| XD | 30 (0x1E) | Stiffilmon |
| XC | 31 (0x1F) | Kaiser Leomon |
| XD | 31 (0x1F) | Kaiser Leomon |
| XC | 32 (0x20) | Black War Greymon X |
| XC | 33 (0x21) | Ofanimon: Falldown Mode X |
| XC | 34 (0x22) | Grandis Kuwagamon |
| XC | 35 (0x23) | Ultimate Brachiomon |
| XD | 36 (0x24) | Dark Knightmon X |
| XD | 37 (0x25) | Cherubimon (Vice) X |
| XD | 38 (0x26) | Giga Seadramon |
| XD | 39 (0x27) | Dinorexmon |
| XC | 40 (0x28) | Chaosdramon X |
| XD | 40 (0x28) | Chaosdramon X |
| XC | 41 (0x29) | Rosemon X |
| XD | 41 (0x29) | Rosemon X |
| XC | 42 (0x2A) | Beel Starmon X |
| XD | 42 (0x2A) | Beel Starmon X |
| XC | 43 (0x2B) | Prince Mamemon X |
| XD | 43 (0x2B) | Prince Mamemon X |
| XC | 44 (0x2C) | Skull Mammon X |
| XD | 44 (0x2C) | Skull Mammon X |
| XC | 45 (0x2D) | Metal Piranimon |
| XD | 45 (0x2D) | Metal Piranimon |
| XC | 46 (0x2E) | Rasenmon: Fury Mode |
| XD | 46 (0x2E) | Rasenmon: Fury Mode |
| XC | 47 (0x2F) | Raihimon |
| XD | 47 (0x2F) | Raihimon |
| XC | 48 (0x30) | Bagramon |
| XD | 48 (0x30) | Bagramon |
| XC | 49 (0x31) | Demon X |
| XC | 50 (0x32) | Lilithmon X |
| XD | 51 (0x33) | Lucemon X |
| XD | 52 (0x34) | Belphemon X |
| XC | 53 (0x35) | Leviamon X |
| XD | 53 (0x35) | Leviamon X |
| XC | 54 (0x36) | Barbamon X |
| XD | 54 (0x36) | Barbamon X |
| XC | 55 (0x37) | Beelzebumon X |
| XD | 55 (0x37) | Beelzebumon X |
| XC | 56 (0x38) | Diablomon X |
| XD | 56 (0x38) | Diablomon X |
| XC | 57 (0x39) | Rasenmon |
| XD | 57 (0x39) | Rasenmon |
| XC | 58 (0x3A) | Ancient Sphinxmon |
| XD | 58 (0x3A) | Ancient Sphinxmon |
| XC | 59 (0x3B) | Darkness Bagramon |
| XD | 59 (0x3B) | Darkness Bagramon |
| XE | 0 (0x00) | Zerimon |
| XF | 1 (0x01) | Cocomon |
| XE | 2 (0x02) | Kuramon |
| XF | 2 (0x02) | Kuramon |
| XE | 3 (0x03) | Gummymon |
| XF | 4 (0x04) | Chocomon |
| XE | 5 (0x05) | Tsumemon |
| XF | 5 (0x05) | Tsumemon |
| XE | 6 (0x06) | Terriermon X |
| XE | 7 (0x07) | Palmon X |
| XE | 8 (0x08) | DORUmon |
| XF | 9 (0x09) | Lopmon X |
| XF | 10 (0x0A) | Shakomon X |
| XF | 11 (0x0B) | Ryudamon |
| XE | 12 (0x0C) | Blucomon |
| XF | 12 (0x0C) | Blucomon |
| XE | 13 (0x0D) | Jazamon |
| XF | 13 (0x0D) | Jazamon |
| XE | 14 (0x0E) | Keramon X |
| XF | 14 (0x0E) | Keramon X |
| XE | 15 (0x0F) | Siesamon X |
| XE | 16 (0x10) | Meramon X |
| XE | 17 (0x11) | DORUgamon |
| XE | 18 (0x12) | Pteranomon X |
| XE | 19 (0x13) | Togemon X |
| XF | 20 (0x14) | Pegasmon X |
| XF | 21 (0x15) | Wizarmon X |
| XF | 22 (0x16) | Ginryumon |
| XF | 23 (0x17) | Tailmon X |
| XF | 24 (0x18) | Tylomon X |
| XE | 25 (0x19) | Omekamon |
| XF | 25 (0x19) | Omekamon |
| XE | 26 (0x1A) | Paledramon |
| XF | 26 (0x1A) | Paledramon |
| XE | 27 (0x1B) | Jazardmon |
| XF | 27 (0x1B) | Jazardmon |
| XE | 28 (0x1C) | Omega Shoutmon X |
| XE | 29 (0x1D) | Cyberdramon X |
| XE | 30 (0x1E) | DORUguremon |
| XE | 31 (0x1F) | Garudamon X |
| XE | 32 (0x20) | Cannonbeemon |
| XF | 33 (0x21) | Monzaemon X |
| XF | 34 (0x22) | Rize Greymon X |
| XF | 35 (0x23) | Hisyaryumon |
| XF | 36 (0x24) | Angewomon X |
| XF | 37 (0x25) | Anomalocarimon X |
| XE | 38 (0x26) | Grademon |
| XF | 38 (0x26) | Grademon |
| XE | 39 (0x27) | Mamemon X |
| XF | 39 (0x27) | Mamemon X |
| XE | 40 (0x28) | Crys Paledramon |
| XF | 40 (0x28) | Crys Paledramon |
| XE | 41 (0x29) | Jazarichmon |
| XF | 41 (0x29) | Jazarichmon |
| XE | 42 (0x2A) | Pumpmon |
| XF | 42 (0x2A) | Pumpmon |
| XE | 43 (0x2B) | Rapidmon X |
| XE | 44 (0x2C) | Justimon X |
| XE | 45 (0x2D) | Alphamon |
| XE | 46 (0x2E) | Hououmon X |
| XE | 47 (0x2F) | Tiger Vespamon |
| XF | 48 (0x30) | Cherubimon (Virtue) X |
| XF | 49 (0x31) | Goddramon X |
| XF | 50 (0x32) | Ouryumon |
| XF | 51 (0x33) | Ofanimon X |
| XF | 52 (0x34) | Plesiomon X |
| XE | 53 (0x35) | Gaioumon |
| XF | 53 (0x35) | Gaioumon |
| XE | 44 (0x2C) | Dinotigermon |
| XF | 44 (0x2C) | Dinotigermon |
| XE | 45 (0x2D) | Holydramon X |
| XF | 45 (0x2D) | Holydramon X |
| XE | 56 (0x38) | Ebemon X |
| XF | 56 (0x38) | Ebemon X |
| XE | 57 (0x39) | Hexeblaumon |
| XF | 57 (0x39) | Hexeblaumon |
| XE | 58 (0x3A) | Metallicdramon |
| XF | 58 (0x3A) | Metallicdramon |
| XE | 59 (0x3B) | Noble Pumpmon |
| XF | 59 (0x3B) | Noble Pumpmon |
| XE | 60 (0x3C) | Magnamon X |
| XE | 61 (0x3D) | Gankoomon X |
| XE | 62 (0x3E) | Dynasmon X |
| XE | 63 (0x3F) | Craniummon X |
| XE | 64 (0x40) | Lord Knightmon X |
| XE | 65 (0x41) | Dukemon X |
| XF | 66 (0x42) | Ulforce V-dramon X |
| XF | 67 (0x43) | Examon X |
| XF | 68 (0x44) | Duftmon X |
| XF | 69 (0x45) | Sleipmon X |
| XF | 70 (0x46) | Jesmon X |
| XF | 71 (0x47) | Omegamon X |
| XE | 72 (0x48) | Alphamon: Ouryuken |
| XF | 72 (0x48) | Alphamon: Ouryuken |
| XE | 73 (0x49) | Diablomon X |
| XF | 73 (0x49) | Diablomon X |
| XE | 74 (0x4A) | Jesmon GX |
| XF | 74 (0x4A) | Jesmon GX |
| XE | 75 (0x4B) | Ogudomon X |
| XF | 75 (0x4B) | Ogudomon X |

Fuente: https://humulos.com/digimon/dmx/list/

## Pendulum Z (penz)

IDs de la tabla publica; las versiones son los prefijos de esa fuente.

| Version | Identificador | Digimon |
| --- | --- | --- |
| Z1 | 0 (0x00) | Botamon |
| Z1 | 1 (0x01) | Wanyamon |
| Z1 | 2 (0x02) | Gaomon |
| Z1 | 3 (0x03) | Morphomon |
| Z1 | 4 (0x04) | Sunarizamon |
| Z1 | 5 (0x05) | Plotmon |
| Z1 | 6 (0x06) | Baboongamon |
| Z1 | 7 (0x07) | Unimon |
| Z1 | 8 (0x08) | Hudiemon |
| Z1 | 9 (0x09) | Gaogamon |
| Z1 | 10 (0x0A) | Golemon |
| Z1 | 11 (0x0B) | Gokimon |
| Z1 | 12 (0x0C) | Tailmon |
| Z1 | 13 (0x0D) | Gogmamon |
| Z1 | 14 (0x0E) | Jewelbeemon |
| Z1 | 15 (0x0F) | Scorpiomon |
| Z1 | 16 (0x10) | Mach Gaogamon |
| Z1 | 17 (0x11) | Orochimon |
| Z1 | 18 (0x12) | Archnemon |
| Z1 | 19 (0x13) | Angewomon |
| Z1 | 20 (0x14) | Ancient Beatmon |
| Z1 | 21 (0x15) | Holydramon |
| Z1 | 22 (0x16) | Baihumon |
| Z1 | 23 (0x17) | Mirage Gaogamon |
| Z1 | 24 (0x18) | Nidhoggmon |
| Z1 | 25 (0x19) | Ancient Volcamon |
| Z1 | 26 (0x1A) | Ofanimon |
| Z1 | 27 (0x1B) | Tsubumon |
| Z1 | 28 (0x1C) | Upamon |
| Z1 | 29 (0x1D) | Swimmon |
| Z1 | 30 (0x1E) | Sangomon |
| Z1 | 31 (0x1F) | Gizamon |
| Z1 | 32 (0x20) | Armadimon |
| Z1 | 33 (0x21) | Tobiumon |
| Z1 | 34 (0x22) | Yukidarumon |
| Z1 | 35 (0x23) | Shellmon |
| Z1 | 36 (0x24) | Submarimon |
| Z1 | 37 (0x25) | Hookmon |
| Z1 | 38 (0x26) | Karatuki Numemon |
| Z1 | 39 (0x27) | Ankylomon |
| Z1 | 40 (0x28) | Marin Chimairamon |
| Z1 | 41 (0x29) | Gusokumon |
| Z1 | 42 (0x2A) | Sirenmon |
| Z1 | 43 (0x2B) | Mermaimon |
| Z1 | 44 (0x2C) | Waru Seadramon |
| Z1 | 45 (0x2D) | Piranimon |
| Z1 | 46 (0x2E) | Aegisdramon |
| Z1 | 47 (0x2F) | Marin Angemon |
| Z1 | 48 (0x30) | Ancient Mermaimon |
| Z1 | 49 (0x31) | Ancient Megatheriumon |
| Z1 | 50 (0x32) | Regalecusmon |
| Z1 | 51 (0x33) | Leviamon |
| Z1 | 52 (0x34) | Algomon (Baby I) |
| Z1 | 53 (0x35) | Algomon (Baby II) |
| Z1 | 54 (0x36) | Ghostmon |
| Z1 | 55 (0x37) | Labramon |
| Z1 | 56 (0x38) | Algomon (Child) |
| Z1 | 57 (0x39) | Wormmon |
| Z1 | 58 (0x3A) | Witchmon |
| Z1 | 59 (0x3B) | Dobermon |
| Z1 | 60 (0x3C) | Algomon (Adult) |
| Z1 | 61 (0x3D) | Devimon |
| Z1 | 62 (0x3E) | Flare Lizamon |
| Z1 | 63 (0x3F) | Mojyamon |
| Z1 | 64 (0x40) | Stingmon |
| Z1 | 65 (0x41) | Chimairamon |
| Z1 | 66 (0x42) | Cerberumon |
| Z1 | 67 (0x43) | Algomon (Perfect) |
| Z1 | 68 (0x44) | Neo Devimon |
| Z1 | 69 (0x45) | Ex-Tyranomon |
| Z1 | 70 (0x46) | Mummymon |
| Z1 | 71 (0x47) | Deathmon |
| Z1 | 72 (0x48) | Anubimon |
| Z1 | 73 (0x49) | Algomon (Ultimate) |
| Z1 | 74 (0x4A) | Done Devimon |
| Z1 | 75 (0x4B) | Ancient Sphinxmon |
| Z1 | 76 (0x4C) | Megidramon |
| Z1 | 77 (0x4D) | Apocalymon |
| Z1 | 78 (0x4E) | Armagemon |
| Z1 | 79 (0x4F) | Huanglongmon |
| Z1 | 80 (0x50) | Susanoomon |
| Z1 | 81 (0x51) | Omegamon |
| Z1 | 82 (0x52) | Imperialdramon: Paladin Mode |
| Z1 | 83 (0x53) | Shakkoumon |
| Z1 | 84 (0x54) | Slash Angemon |
| Z1 | 85 (0x55) | Silphymon |
| Z1 | 86 (0x56) | Valkyrimon |
| Z1 | 87 (0x57) | Paildramon |
| Z1 | 88 (0x58) | Imperialdramon: Fighter Mode |
| Z1 | 89 (0x59) | Dinobeemon |
| Z1 | 90 (0x5A) | Gran Kuwagamon |
| Z1 | 91 (0x5B) | Agumon |
| Z1 | 92 (0x5C) | Agnimon |
| Z1 | 93 (0x5D) | Greymon |
| Z1 | 94 (0x5E) | Vritramon |
| Z1 | 95 (0x5F) | Metal Greymon |
| Z1 | 96 (0x60) | Aldamon |
| Z1 | 97 (0x61) | War Greymon |
| Z1 | 98 (0x62) | Kaiser Greymon |
| Z1 | 99 (0x63) | Agumon -Yuki no Kizuna- |
| Z2 | 0 (0x00) | Pururumon |
| Z2 | 1 (0x01) | Poromon |
| Z2 | 2 (0x02) | Falcomon |
| Z2 | 3 (0x03) | Pomumon |
| Z2 | 4 (0x04) | Tinkermon |
| Z2 | 5 (0x05) | Hawkmon |
| Z2 | 6 (0x06) | Peckmon |
| Z2 | 7 (0x07) | Diatrymon |
| Z2 | 8 (0x08) | Petermon |
| Z2 | 9 (0x09) | Cockatrimon |
| Z2 | 10 (0x0A) | Parasaurmon |
| Z2 | 11 (0x0B) | Vegimon |
| Z2 | 12 (0x0C) | Aquilamon |
| Z2 | 13 (0x0D) | Yatagaramon (2006) |
| Z2 | 14 (0x0E) | Parrotmon |
| Z2 | 15 (0x0F) | Hippogriffomon |
| Z2 | 16 (0x10) | Lilamon |
| Z2 | 17 (0x11) | Toropiamon |
| Z2 | 18 (0x12) | Entmon |
| Z2 | 19 (0x13) | Ravmon |
| Z2 | 20 (0x14) | Ancient Irismon |
| Z2 | 21 (0x15) | Xuanwumon |
| Z2 | 22 (0x16) | Ancient Troiamon |
| Z2 | 23 (0x17) | Ornismon |
| Z2 | 24 (0x18) | Zhuqiaomon |
| Z2 | 25 (0x19) | Ketomon |
| Z2 | 26 (0x1A) | Hopmon |
| Z2 | 27 (0x1B) | Monodramon |
| Z2 | 28 (0x1C) | Jazamon |
| Z2 | 29 (0x1D) | Junkmon |
| Z2 | 30 (0x1E) | V-mon |
| Z2 | 31 (0x1F) | Strikedramon |
| Z2 | 32 (0x20) | Machmon |
| Z2 | 33 (0x21) | Eosmon (Adult) |
| Z2 | 34 (0x22) | Komondomon |
| Z2 | 35 (0x23) | Minotaurmon |
| Z2 | 36 (0x24) | Raremon |
| Z2 | 37 (0x25) | XV-mon |
| Z2 | 38 (0x26) | Cyberdramon |
| Z2 | 39 (0x27) | Loader Liomon |
| Z2 | 40 (0x28) | Eosmon (Perfect) |
| Z2 | 41 (0x29) | Locomon |
| Z2 | 42 (0x2A) | Metal Tyranomon |
| Z2 | 43 (0x2B) | Rebellimon |
| Z2 | 44 (0x2C) | Justimon: Blitz Arm |
| Z2 | 45 (0x2D) | Heavy Leomon |
| Z2 | 46 (0x2E) | Eosmon (Ultimate) |
| Z2 | 47 (0x2F) | Grand Locomon |
| Z2 | 48 (0x30) | Ancient Wisemon |
| Z2 | 49 (0x31) | Gundramon |
| Z2 | 50 (0x32) | Poyomon |
| Z2 | 51 (0x33) | Tokomon |
| Z2 | 52 (0x34) | Agumon (2006) |
| Z2 | 53 (0x35) | Shoutmon |
| Z2 | 54 (0x36) | Guilmon |
| Z2 | 55 (0x37) | Patamon |
| Z2 | 56 (0x38) | Geo Greymon |
| Z2 | 57 (0x39) | Darcmon |
| Z2 | 58 (0x3A) | Shoutmon X3 |
| Z2 | 59 (0x3B) | Baluchimon |
| Z2 | 60 (0x3C) | Mimicmon |
| Z2 | 61 (0x3D) | Growmon |
| Z2 | 62 (0x3E) | Angemon |
| Z2 | 63 (0x3F) | Rize Greymon |
| Z2 | 64 (0x40) | Duramon |
| Z2 | 65 (0x41) | Raiji Ludomon |
| Z2 | 66 (0x42) | Shoutmon X5 |
| Z2 | 67 (0x43) | Manticoremon |
| Z2 | 68 (0x44) | Megalo Growmon |
| Z2 | 69 (0x45) | Holy Angemon |
| Z2 | 70 (0x46) | Shine Greymon |
| Z2 | 71 (0x47) | Ancient Greymon |
| Z2 | 72 (0x48) | Goddramon |
| Z2 | 73 (0x49) | Ancient Garurumon |
| Z2 | 74 (0x4A) | Qinglongmon |
| Z2 | 75 (0x4B) | Dukemon |
| Z2 | 76 (0x4C) | Seraphimon |
| Z2 | 77 (0x4D) | Lucemon: Satan Mode |
| Z2 | 91 (0x5B) | Gabumon |
| Z2 | 92 (0x5C) | Wolfmon |
| Z2 | 93 (0x5D) | Garurumon |
| Z2 | 94 (0x5E) | Garummon |
| Z2 | 95 (0x5F) | Were Garurumon |
| Z2 | 96 (0x60) | Beowolfmon |
| Z2 | 97 (0x61) | Metal Garurumon |
| Z2 | 98 (0x62) | Magna Garurumon |
| Z2 | 99 (0x63) | Gabumon -Yujo no Kizuna- |
| ZC | 0 (0x00) | Mochimon |
| ZC | 1 (0x01) | Pukamon |
| ZC | 2 (0x02) | Peti Meramon |
| ZC | 3 (0x03) | Gottsumon |
| ZC | 4 (0x04) | Tentomon |
| ZC | 5 (0x05) | Shakomon |
| ZC | 6 (0x06) | Gomamon |
| ZC | 7 (0x07) | Candmon |
| ZC | 8 (0x08) | Pico Devimon |
| ZC | 9 (0x09) | Tortamon |
| ZC | 10 (0x0A) | Monochromon |
| ZC | 11 (0x0B) | Kuwagamon |
| ZC | 12 (0x0C) | Seadramon |
| ZC | 13 (0x0D) | Gesomon |
| ZC | 14 (0x0E) | Rukamon |
| ZC | 15 (0x0F) | Bakemon |
| ZC | 16 (0x10) | Mammon |
| ZC | 17 (0x11) | Wizarmon |
| ZC | 18 (0x12) | Tonosama Gekomon |
| ZC | 19 (0x13) | Jyagamon |
| ZC | 20 (0x14) | Triceramon |
| ZC | 21 (0x15) | Dagomon |
| ZC | 22 (0x16) | Mega Seadramon |
| ZC | 23 (0x17) | Whamon |
| ZC | 24 (0x18) | Pumpmon |
| ZC | 25 (0x19) | Lady Devimon |
| ZC | 26 (0x1A) | Vamdemon |
| ZC | 27 (0x1B) | Metal Etemon |
| ZC | 28 (0x1C) | Saber Leomon |
| ZC | 29 (0x1D) | Herakle Kabuterimon |
| ZC | 30 (0x1E) | Pukumon |
| ZC | 31 (0x1F) | Plesiomon |
| ZC | 32 (0x20) | Metal Seadramon |
| ZC | 33 (0x21) | Boltmon |
| ZC | 34 (0x22) | Skull Mammon |
| ZC | 35 (0x23) | Piemon |
| ZC | 36 (0x24) | Pyocomon |
| ZC | 37 (0x25) | Caprimon |
| ZC | 38 (0x26) | Nyaromon |
| ZC | 39 (0x27) | Mushmon |
| ZC | 40 (0x28) | Palmon |
| ZC | 41 (0x29) | Hagurumon |
| ZC | 42 (0x2A) | Toy Agumon |
| ZC | 43 (0x2B) | Woodmon |
| ZC | 44 (0x2C) | Birdramon |
| ZC | 45 (0x2D) | Togemon |
| ZC | 46 (0x2E) | Clockmon |
| ZC | 47 (0x2F) | Revolmon |
| ZC | 48 (0x30) | Guardromon |
| ZC | 49 (0x31) | Igamon |
| ZC | 50 (0x32) | Leomon |
| ZC | 51 (0x33) | Delumon |
| ZC | 52 (0x34) | Gerbemon |
| ZC | 53 (0x35) | Aero V-dramon |
| ZC | 54 (0x36) | Andromon |
| ZC | 55 (0x37) | Big Mamemon |
| ZC | 56 (0x38) | Waru Monzaemon |
| ZC | 57 (0x39) | Asuramon |
| ZC | 58 (0x3A) | Metal Mamemon |
| ZC | 59 (0x3B) | Rosemon |
| ZC | 60 (0x3C) | Pinochimon |
| ZC | 61 (0x3D) | Hououmon |
| ZC | 62 (0x3E) | Venom Vamdemon |
| ZC | 63 (0x3F) | Mugendramon |

Fuente: https://humulos.com/digimon/penz/list/

## Digital Monster Color (dmc)

IDs de la tabla publica; las versiones son los prefijos de esa fuente.

| Version | Identificador | Digimon |
| --- | --- | --- |
| 01 | 0 (0x00) | Botamon |
| 01 | 1 (0x01) | Koromon |
| 01 | 2 (0x02) | Agumon |
| 01 | 3 (0x03) | Betamon |
| 01 | 4 (0x04) | Greymon |
| 01 | 5 (0x05) | Tyranomon |
| 01 | 6 (0x06) | Devimon |
| 01 | 7 (0x07) | Meramon |
| 01 | 8 (0x08) | Airdramon |
| 01 | 9 (0x09) | Seadramon |
| 01 | 10 (0x0A) | Numemon |
| 01 | 11 (0x0B) | Metal Greymon (Virus) |
| 01 | 12 (0x0C) | Mamemon |
| 01 | 13 (0x0D) | Monzaemon |
| 01 | 14 (0x0E) | Blitz Greymon |
| 01 | 15 (0x0F) | Bancho Mamemon |
| 01 | 16 (0x10) | Shin Monzaemon |
| 02 | 0 (0x00) | Punimon |
| 02 | 1 (0x01) | Tsunomon |
| 02 | 2 (0x02) | Gabumon |
| 02 | 3 (0x03) | Elecmon |
| 02 | 4 (0x04) | Kabuterimon |
| 02 | 5 (0x05) | Garurumon |
| 02 | 6 (0x06) | Angemon |
| 02 | 7 (0x07) | Yukidarumon |
| 02 | 8 (0x08) | Birdramon |
| 02 | 9 (0x09) | Whamon |
| 02 | 10 (0x0A) | Vegimon |
| 02 | 11 (0x0B) | Skull Greymon |
| 02 | 12 (0x0C) | Metal Mamemon |
| 02 | 13 (0x0D) | Vademon |
| 02 | 14 (0x0E) | Skull Mammon |
| 02 | 15 (0x0F) | Cres Garurumon |
| 02 | 16 (0x10) | Ebemon |
| 03 | 0 (0x00) | Poyomon |
| 03 | 1 (0x01) | Tokomon |
| 03 | 2 (0x02) | Patamon |
| 03 | 3 (0x03) | Kunemon |
| 03 | 4 (0x04) | Unimon |
| 03 | 5 (0x05) | Centaurmon |
| 03 | 6 (0x06) | Ogremon |
| 03 | 7 (0x07) | Bakemon |
| 03 | 8 (0x08) | Shellmon |
| 03 | 9 (0x09) | Drimogemon |
| 03 | 10 (0x0A) | Scumon |
| 03 | 11 (0x0B) | Andromon |
| 03 | 12 (0x0C) | Giromon |
| 03 | 13 (0x0D) | Etemon |
| 03 | 14 (0x0E) | Chimairamon |
| 03 | 15 (0x0F) | Hi Andromon |
| 03 | 16 (0x10) | Gokumon |
| 03 | 17 (0x11) | Bancho Leomon |
| 04 | 0 (0x00) | Yuramon |
| 04 | 1 (0x01) | Tanemon |
| 04 | 2 (0x02) | Piyomon |
| 04 | 3 (0x03) | Palmon |
| 04 | 4 (0x04) | Monochromon |
| 04 | 5 (0x05) | Cockatrimon |
| 04 | 6 (0x06) | Leomon |
| 04 | 7 (0x07) | Kuwagamon |
| 04 | 8 (0x08) | Coelamon |
| 04 | 9 (0x09) | Mojyamon |
| 04 | 10 (0x0A) | Nanimon |
| 04 | 11 (0x0B) | Megadramon |
| 04 | 12 (0x0C) | Piccolomon |
| 04 | 13 (0x0D) | Digitamamon |
| 04 | 14 (0x0E) | Darkdramon |
| 04 | 15 (0x0F) | Bloom Lordmon |
| 04 | 16 (0x10) | Gankoomon |
| 05 | 0 (0x00) | Zurumon |
| 05 | 1 (0x01) | Pagumon |
| 05 | 2 (0x02) | Gazimon |
| 05 | 3 (0x03) | Gizamon |
| 05 | 4 (0x04) | Dark Tyranomon |
| 05 | 5 (0x05) | Cyclomon |
| 05 | 6 (0x06) | Devidramon |
| 05 | 7 (0x07) | Tuskmon |
| 05 | 8 (0x08) | Flymon |
| 05 | 9 (0x09) | Deltamon |
| 05 | 10 (0x0A) | Raremon |
| 05 | 11 (0x0B) | Metal Tyranomon |
| 05 | 12 (0x0C) | Nanomon |
| 05 | 13 (0x0D) | Ex-Tyranomon |
| 05 | 14 (0x0E) | Mugendramon |
| 05 | 15 (0x0F) | Raidenmon |
| 05 | 16 (0x10) | Gaioumon |
| 17 | 17 (0x11) | Omegamon Alter-S |
| 17 | 18 (0x12) | Chaosdramon |
| 18 | 18 (0x12) | Chaosmon |
| 19 | 17 (0x11) | Millenniumon |

Fuente: https://humulos.com/digimon/dmc/list/

## Pendulum Color (penc)

IDs de la tabla publica; las versiones son los prefijos de esa fuente.

| Version | Identificador | Digimon |
| --- | --- | --- |
| 1 | 0 (0x00) | Bubbmon |
| 1 | 1 (0x01) | Mochimon |
| 1 | 2 (0x02) | Tentomon |
| 1 | 3 (0x03) | Gottsumon |
| 1 | 4 (0x04) | Otamamon |
| 1 | 5 (0x05) | Kabuterimon |
| 1 | 6 (0x06) | Tortamon |
| 1 | 7 (0x07) | Monochromon |
| 1 | 8 (0x08) | Starmon |
| 1 | 9 (0x09) | Gekomon |
| 1 | 10 (0x0A) | Kuwagamon |
| 1 | 11 (0x0B) | Tailmon |
| 1 | 12 (0x0C) | Atlur Kabuterimon |
| 1 | 13 (0x0D) | Jyagamon |
| 1 | 14 (0x0E) | Triceramon |
| 1 | 15 (0x0F) | Piccolomon |
| 1 | 16 (0x10) | Tonosama Gekomon |
| 1 | 17 (0x11) | Okuwamon |
| 1 | 18 (0x12) | Angewomon |
| 1 | 19 (0x13) | Herakle Kabuterimon |
| 1 | 20 (0x14) | Saber Leomon |
| 1 | 21 (0x15) | Metal Etemon |
| 1 | 22 (0x16) | Holydramon |
| 1 | 23 (0x17) | Blastmon |
| 1 | 24 (0x18) | El Doradimon |
| 1 | 25 (0x19) | Gran Kuwagamon |
| 1 | 26 (0x1A) | Tlalocmon |
| 1 | 27 (0x1B) | Mastemon |
| 1 | 28 (0x1C) | Angoramon |
| 1 | 29 (0x1D) | Symbare Angoramon |
| 1 | 30 (0x1E) | Lamortmon |
| 1 | 31 (0x1F) | Diarbbitmon |
| 2 | 0 (0x00) | Pitchmon |
| 2 | 1 (0x01) | Pukamon |
| 2 | 2 (0x02) | Gomamon |
| 2 | 3 (0x03) | Ganimon |
| 2 | 4 (0x04) | Shakomon |
| 2 | 5 (0x05) | Rukamon |
| 2 | 6 (0x06) | Ikkakumon |
| 2 | 7 (0x07) | Seadramon |
| 2 | 8 (0x08) | Coelamon |
| 2 | 9 (0x09) | Octmon |
| 2 | 10 (0x0A) | Gesomon |
| 2 | 11 (0x0B) | Ebidramon |
| 2 | 12 (0x0C) | Whamon |
| 2 | 13 (0x0D) | Zudomon |
| 2 | 14 (0x0E) | Mega Seadramon |
| 2 | 15 (0x0F) | Anomalocarimon |
| 2 | 16 (0x10) | Dagomon |
| 2 | 17 (0x11) | Marin Devimon |
| 2 | 18 (0x12) | Hangyomon |
| 2 | 19 (0x13) | Marin Angemon |
| 2 | 20 (0x14) | Metal Seadramon |
| 2 | 21 (0x15) | Pukumon |
| 2 | 22 (0x16) | Plesiomon |
| 2 | 23 (0x17) | Vikemon |
| 2 | 24 (0x18) | Jumbo Gamemon |
| 2 | 25 (0x19) | Cthyllamon |
| 2 | 26 (0x1A) | Mitamamon |
| 2 | 27 (0x1B) | Aegisdramon |
| 2 | 28 (0x1C) | Jellymon |
| 2 | 29 (0x1D) | Tesla Jellymon |
| 2 | 30 (0x1E) | Thetismon |
| 2 | 31 (0x1F) | Amphimon |
| 3 | 0 (0x00) | Mokumon |
| 3 | 1 (0x01) | Peti Meramon |
| 3 | 2 (0x02) | Bakumon |
| 3 | 3 (0x03) | Candmon |
| 3 | 4 (0x04) | Pico Devimon |
| 3 | 5 (0x05) | Hanumon |
| 3 | 6 (0x06) | Garurumon |
| 3 | 7 (0x07) | Meramon |
| 3 | 8 (0x08) | Wizarmon |
| 3 | 9 (0x09) | Devimon |
| 3 | 10 (0x0A) | Bakemon |
| 3 | 11 (0x0B) | Dokugumon |
| 3 | 12 (0x0C) | Mammon |
| 3 | 13 (0x0D) | Were Garurumon |
| 3 | 14 (0x0E) | Death Meramon |
| 3 | 15 (0x0F) | Pumpmon |
| 3 | 16 (0x10) | Vamdemon |
| 3 | 17 (0x11) | Fantomon |
| 3 | 18 (0x12) | Lady Devimon |
| 3 | 19 (0x13) | Skull Mammon |
| 3 | 20 (0x14) | Boltmon |
| 3 | 21 (0x15) | Demon |
| 3 | 22 (0x16) | Piemon |
| 3 | 23 (0x17) | Anubimon |
| 3 | 24 (0x18) | Noble Pumpmon |
| 3 | 25 (0x19) | Callismon |
| 3 | 26 (0x1A) | Voltobautamon |
| 3 | 27 (0x1B) | Mastemon |
| 3 | 28 (0x1C) | Loogamon |
| 3 | 29 (0x1D) | Loogarmon |
| 3 | 30 (0x1E) | Soloogarmon |
| 3 | 31 (0x1F) | Fenriloogamon |
| 4 | 0 (0x00) | Nyokimon |
| 4 | 1 (0x01) | Pyocomon |
| 4 | 2 (0x02) | Piyomon |
| 4 | 3 (0x03) | Floramon |
| 4 | 4 (0x04) | Mushmon |
| 4 | 5 (0x05) | Palmon |
| 4 | 6 (0x06) | V-dramon |
| 4 | 7 (0x07) | Birdramon |
| 4 | 8 (0x08) | Togemon |
| 4 | 9 (0x09) | Kiwimon |
| 4 | 10 (0x0A) | Woodmon |
| 4 | 11 (0x0B) | Red Vegimon |
| 4 | 12 (0x0C) | Aero V-dramon |
| 4 | 13 (0x0D) | Garudamon |
| 4 | 14 (0x0E) | Blossomon |
| 4 | 15 (0x0F) | Delumon |
| 4 | 16 (0x10) | Jyureimon |
| 4 | 17 (0x11) | Gerbemon |
| 4 | 18 (0x12) | Lilimon |
| 4 | 19 (0x13) | Hououmon |
| 4 | 20 (0x14) | Griffomon |
| 4 | 21 (0x15) | Pinochimon |
| 4 | 22 (0x16) | Rosemon |
| 4 | 23 (0x17) | Ulforce V-dramon |
| 4 | 24 (0x18) | Rafflesimon |
| 4 | 25 (0x19) | Hydramon |
| 4 | 26 (0x1A) | Mitamamon |
| 4 | 27 (0x1B) | Cernumon |
| 4 | 28 (0x1C) | Pteromon |
| 4 | 29 (0x1D) | Galemon |
| 4 | 30 (0x1E) | Grand Galemon |
| 4 | 31 (0x1F) | Zephagamon |
| 5 | 0 (0x00) | Choromon |
| 5 | 1 (0x01) | Caprimon |
| 5 | 2 (0x02) | Toy Agumon |
| 5 | 3 (0x03) | Kokuwamon |
| 5 | 4 (0x04) | Hagurumon |
| 5 | 5 (0x05) | Greymon |
| 5 | 6 (0x06) | Revolmon |
| 5 | 7 (0x07) | Tankmon |
| 5 | 8 (0x08) | Clockmon |
| 5 | 9 (0x09) | Guardromon |
| 5 | 10 (0x0A) | Mechanorimon |
| 5 | 11 (0x0B) | Thunderballmon |
| 5 | 12 (0x0C) | Metal Greymon (Vaccine) |
| 5 | 13 (0x0D) | Andromon |
| 5 | 14 (0x0E) | Knightmon |
| 5 | 15 (0x0F) | Big Mamemon |
| 5 | 16 (0x10) | Megadramon |
| 5 | 17 (0x11) | Waru Monzaemon |
| 5 | 18 (0x12) | Cyberdramon |
| 5 | 19 (0x13) | War Greymon |
| 5 | 20 (0x14) | Metal Garurumon |
| 5 | 21 (0x15) | Mugendramon |
| 5 | 22 (0x16) | Venom Vamdemon |
| 5 | 23 (0x17) | Hi Andromon |
| 5 | 24 (0x18) | Ragnamon |
| 5 | 25 (0x19) | Zeke Greymon |
| 5 | 26 (0x1A) | Omegamon |
| 5 | 27 (0x1B) | Chaosdramon |
| 5 | 28 (0x1C) | Commandramon |
| 5 | 29 (0x1D) | Hi-Commandramon |
| 5 | 30 (0x1E) | Cargodramon |
| 5 | 31 (0x1F) | Brigadramon |
| 0 | 0 (0x00) | Yukimibotamon |
| 0 | 1 (0x01) | Nyaromon |
| 0 | 2 (0x02) | Agumon |
| 0 | 3 (0x03) | Gabumon |
| 0 | 4 (0x04) | Plotmon |
| 0 | 5 (0x05) | Greymon |
| 0 | 6 (0x06) | Leomon |
| 0 | 7 (0x07) | Garurumon |
| 0 | 8 (0x08) | Igamon |
| 0 | 9 (0x09) | Angemon |
| 0 | 10 (0x0A) | Tailmon |
| 0 | 11 (0x0B) | Metal Greymon (Vaccine) |
| 0 | 12 (0x0C) | Asuramon |
| 0 | 13 (0x0D) | Were Garurumon |
| 0 | 14 (0x0E) | Metal Mamemon |
| 0 | 15 (0x0F) | Holy Angemon |
| 0 | 16 (0x10) | Angewomon |
| 0 | 17 (0x11) | War Greymon |
| 0 | 18 (0x12) | Metal Garurumon |
| 0 | 19 (0x13) | Dominimon |
| 0 | 20 (0x14) | Quantumon |
| 0 | 21 (0x15) | Omegamon |
| 0 | 22 (0x16) | Mastemon |
| 0 | 23 (0x17) | Gammamon |
| 0 | 24 (0x18) | Betel Gammamon |
| 0 | 25 (0x19) | Kaus Gammamon |
| 0 | 26 (0x1A) | Wezen Gammamon |
| 0 | 27 (0x1B) | Gulus Gammamon |
| 0 | 28 (0x1C) | Canoweissmon |
| 0 | 29 (0x1D) | Regulusmon |
| 0 | 30 (0x1E) | Siriusmon |
| 0 | 31 (0x1F) | Arcturusmon |
| 0 | 32 (0x20) | Proximamon |
| 6 | 0 (0x00) | Fukamon |
| 6 | 1 (0x01) | Mococomon |
| 6 | 2 (0x02) | Kakamon |
| 6 | 3 (0x03) | Kamemon |
| 6 | 4 (0x04) | Fujamon |
| 6 | 5 (0x05) | Takinmon |
| 6 | 6 (0x06) | Hanumon |
| 6 | 7 (0x07) | Xiquemon |
| 6 | 8 (0x08) | Gawappamon |
| 6 | 9 (0x09) | Lianpumon |
| 6 | 10 (0x0A) | Ginkakumon |
| 6 | 11 (0x0B) | Kinkakumon |
| 6 | 12 (0x0C) | Hakubamon |
| 6 | 13 (0x0D) | Turuiemon |
| 6 | 14 (0x0E) | Sanzomon |
| 6 | 15 (0x0F) | Huankunmon |
| 6 | 16 (0x10) | Cho-Hakkaimon |
| 6 | 17 (0x11) | Pandamon |
| 6 | 18 (0x12) | Gokuwmon |
| 6 | 19 (0x13) | Xingtianmon |
| 6 | 20 (0x14) | Sagomon |
| 6 | 21 (0x15) | Andiramon (Deva) |
| 6 | 22 (0x16) | Erlangmon |
| 6 | 22 (0x16) | Erlangmon: Blast Mode |
| 6 | 23 (0x17) | Xiangpengmon |
| 6 | 24 (0x18) | Shagaramon |
| 6 | 25 (0x19) | Nezhamon |
| 6 | 25 (0x19) | Nezhamon: Crimson Mode |
| 6 | 26 (0x1A) | Seiten Gokuwmon |
| 6 | 27 (0x1B) | Dijiangmon |
| 6 | 28 (0x1C) | Takutoumon |
| 6 | 28 (0x1C) | Takutoumon: Wrath Mode |
| 6 | 29 (0x1D) | Jougamon |
| 6 | 30 (0x1E) | Shakamon |
| 7 | 0 (0x00) | Tomorimon |
| 7 | 1 (0x01) | Onibimon |
| 7 | 2 (0x02) | Wankomon |
| 7 | 3 (0x03) | Hanimon |
| 7 | 4 (0x04) | Gasamon |
| 7 | 5 (0x05) | Renamon |
| 7 | 6 (0x06) | Siesamon |
| 7 | 7 (0x07) | Peckmon |
| 7 | 8 (0x08) | Kokeshimon |
| 7 | 9 (0x09) | Shellmon |
| 7 | 10 (0x0A) | Musyamon |
| 7 | 11 (0x0B) | Fugamon |
| 7 | 12 (0x0C) | Manekimon |
| 7 | 13 (0x0D) | Tenkomon |
| 7 | 14 (0x0E) | Shishimamon |
| 7 | 15 (0x0F) | Yatagaramon (2006) |
| 7 | 16 (0x10) | Karakurumon |
| 7 | 17 (0x11) | Marin Bullmon |
| 7 | 18 (0x12) | Oboromon |
| 7 | 19 (0x13) | Karatenmon |
| 7 | 20 (0x14) | Darumamon |
| 7 | 21 (0x15) | Sekkamon |
| 7 | 22 (0x16) | Amaterasumon |
| 7 | 23 (0x17) | Ravmon |
| 7 | 23 (0x17) | Ravmon: Burst Mode |
| 7 | 24 (0x18) | Kaguyamon |
| 7 | 25 (0x19) | Ryugumon |
| 7 | 26 (0x1A) | Zanbamon |
| 7 | 27 (0x1B) | Tengumon |
| 7 | 28 (0x1C) | Ariemon |
| 7 | 29 (0x1D) | Yukinamon |
| 7 | 30 (0x1E) | Enmamon |
| C | 0 (0x00) | Yihumon |
| C | 1 (0x01) | Taotiemon |
| C | 2 (0x02) | Taowumon |
| 8 | 0 (0x00) | Mokumon |
| 8 | 1 (0x01) | Sunmon |
| 8 | 2 (0x02) | Coronamon |
| 8 | 3 (0x03) | Elecmon |
| 8 | 4 (0x04) | Snakemon |
| 8 | 5 (0x05) | Firamon |
| 8 | 6 (0x06) | Aegiomon |
| 8 | 7 (0x07) | Blimpmon |
| 8 | 8 (0x08) | Coelamon |
| 8 | 9 (0x09) | Vipemon |
| 8 | 10 (0x0A) | Tylomon |
| 8 | 11 (0x0B) | Garurumon (Black) |
| 8 | 12 (0x0C) | Ogremon |
| 8 | 13 (0x0D) | Flaremon |
| 8 | 14 (0x0E) | Aegiochusmon |
| 8 | 15 (0x0F) | Master Blimpmon |
| 8 | 16 (0x10) | Skull Seadramon |
| 8 | 17 (0x11) | Ambromon |
| 8 | 18 (0x12) | Sharkmon |
| 8 | 19 (0x13) | Were Garurumon (Black) |
| 8 | 20 (0x14) | Digitamamon |
| 8 | 21 (0x15) | Apollomon |
| 8 | 21 (0x15) | Apollomon Whispered |
| 8 | 22 (0x16) | Jupitermon |
| 8 | 22 (0x16) | Jupitermon: Wrath Mode |
| 8 | 23 (0x17) | Vulcanusmon |
| 8 | 24 (0x18) | King Whamon |
| 8 | 25 (0x19) | Bacchusmon |
| 8 | 25 (0x19) | Bacchusmon: Drunk Mode |
| 8 | 26 (0x1A) | Neptunemon |
| 8 | 27 (0x1B) | Mercurymon |
| 8 | 28 (0x1C) | Titamon |
| 8 | 29 (0x1D) | Grace Novamon |
| 8 | 30 (0x1E) | Titamon + Skull Baluchimon |
| 9 | 0 (0x00) | Relemon |
| 9 | 1 (0x01) | Moonmon |
| 9 | 2 (0x02) | Bearmon |
| 9 | 3 (0x03) | Lunamon |
| 9 | 4 (0x04) | Gagamon |
| 9 | 5 (0x05) | Gryzmon |
| 9 | 6 (0x06) | Darcmon |
| 9 | 7 (0x07) | Lekismon |
| 9 | 8 (0x08) | Kiwimon |
| 9 | 9 (0x09) | Corvumon |
| 9 | 10 (0x0A) | Coatlmon |
| 9 | 11 (0x0B) | Centaurmon |
| 9 | 12 (0x0C) | Dobermon |
| 9 | 13 (0x0D) | Great Gryzmon |
| 9 | 14 (0x0E) | Luminamon |
| 9 | 15 (0x0F) | Crescemon |
| 9 | 16 (0x10) | Sirenmon |
| 9 | 17 (0x11) | Panoptemon |
| 9 | 18 (0x12) | Lamiamon |
| 9 | 19 (0x13) | Enbarrmon |
| 9 | 20 (0x14) | Cerberumon |
| 9 | 20 (0x14) | Cerberumon: Werewolf Mode |
| 9 | 21 (0x15) | Marsmon |
| 9 | 22 (0x16) | Venusmon |
| 9 | 23 (0x17) | Dianamon |
| 9 | 24 (0x18) | Ceresmon |
| 9 | 24 (0x18) | Ceresmon: Medium |
| 9 | 25 (0x19) | Junomon |
| 9 | 25 (0x19) | Junomon: Hysteric Mode |
| 9 | 26 (0x1A) | Minervamon |
| 9 | 26 (0x1A) | Mervamon |
| 9 | 27 (0x1B) | Dullahamon |
| 9 | 28 (0x1C) | Plutomon |
| 9 | 29 (0x1D) | Grace Novamon |
| 9 | 30 (0x1E) | Zombie Plutomon |

Fuente: https://humulos.com/digimon/penc/list/

## Digital Monster Color Monster Hunter (dmh)

IDs de la tabla publica; las versiones son los prefijos de esa fuente.

| Version | Identificador | Digimon |
| --- | --- | --- |
| comun | 0 (0x00) | Egg (Phase I) |
| comun | 1 (0x01) | Egg (Phase II) |
| comun | 2 (0x02) | Rathalos (Young) |
| comun | 3 (0x03) | Tigrex (Young) |
| comun | 4 (0x04) | Nargacuga (Young) |
| comun | 5 (0x05) | Zinogre (Young) |
| comun | 6 (0x06) | Gore Magala (Young) |
| comun | 7 (0x07) | Mizutsune (Young) |
| comun | 8 (0x08) | Rajang (Young) |
| comun | 9 (0x09) | Khezu (Young) |
| comun | 10 (0x0A) | Rathalos |
| comun | 11 (0x0B) | Azure Rathalos |
| comun | 12 (0x0C) | Tigrex |
| comun | 13 (0x0D) | Brute Tigrex |
| comun | 14 (0x0E) | Zinogre |
| comun | 15 (0x0F) | Stygian Zinogre |
| comun | 16 (0x10) | Nargacuga |
| comun | 17 (0x11) | Green Nargacuga |
| comun | 18 (0x12) | Gore Magala |
| comun | 19 (0x13) | Mizutsune |
| comun | 20 (0x14) | Rajang |
| comun | 21 (0x15) | Khezu |
| comun | 22 (0x16) | Red Khezu |
| comun | 23 (0x17) | Dreadking Rathalos |
| comun | 24 (0x18) | Silver Rathalos |
| comun | 25 (0x19) | Grimclaw Tigrex |
| comun | 26 (0x1A) | Molten Tigrex |
| comun | 27 (0x1B) | Silverwind Nargacuga |
| comun | 28 (0x1C) | Lucent Nargacuga |
| comun | 29 (0x1D) | Thunderlord Zinogre |
| comun | 30 (0x1E) | Shagaru Magala |
| comun | 31 (0x1F) | Chaotic Gore Magala |
| comun | 32 (0x20) | Apex Mizutsune |
| comun | 33 (0x21) | Violet Mizutsune |
| comun | 34 (0x22) | Soulseer Mizutsune |
| comun | 35 (0x23) | Furious Rajang |
| comun | 36 (0x24) | Rathalos Greymon |
| comun | 37 (0x25) | Zino Garurumon |

Fuente: https://humulos.com/digimon/dmh/list/

## Digital Monster Color Godzilla (dmgz)

IDs de la tabla publica; las versiones son los prefijos de esa fuente.

| Version | Identificador | Digimon |
| --- | --- | --- |
| comun | 0 (0x00) | Botamon |
| comun | 1 (0x01) | Koromon |
| comun | 2 (0x02) | Baby Godzilla |
| comun | 3 (0x03) | Agumon |
| comun | 4 (0x04) | Monodramon |
| comun | 5 (0x05) | Little Godzilla |
| comun | 6 (0x06) | Greymon |
| comun | 7 (0x07) | Biollante |
| comun | 8 (0x08) | Godzillasaurus |
| comun | 9 (0x09) | Raremon |
| comun | 10 (0x0A) | Gigan |
| comun | 11 (0x0B) | Mothra |
| comun | 12 (0x0C) | King Ghidorah (1991) |
| comun | 13 (0x0D) | Rodan |
| comun | 14 (0x0E) | Godzilla Jr |
| comun | 15 (0x0F) | Metal Greymon (Vaccine): G-Erosion Mode |
| comun | 16 (0x10) | Metal Greymon (Vaccine) |
| comun | 17 (0x11) | Space Godzilla |
| comun | 18 (0x12) | Godzilla (1954) |
| comun | 19 (0x13) | Skull Greymon: G-Erosion Mode |
| comun | 20 (0x14) | Zilla |
| comun | 21 (0x15) | Kiryu |
| comun | 22 (0x16) | Mecha-King Ghidorah |
| comun | 23 (0x17) | Fire Rodan |
| comun | 24 (0x18) | Godzilla (1994) |
| comun | 25 (0x19) | War Greymon: G-Erosion Mode |
| comun | 26 (0x1A) | War Greymon |
| comun | 27 (0x1B) | Destoroyah |
| comun | 28 (0x1C) | Godzilla (1999) |
| comun | 29 (0x1D) | Mugendramon: MFS-3 |
| comun | 30 (0x1E) | Mechagodzilla (1993) |
| comun | 31 (0x1F) | Burning Godzilla |
| comun | 32 (0x20) | Chibi Godzilla |
| comun | 33 (0x21) | Chibi Mechagodzilla |

Fuente: https://humulos.com/digimon/dmgz/list/

## Digital Monster Color Xros Wars (dmxw)

IDs de la tabla publica; las versiones son los prefijos de esa fuente.

| Version | Identificador | Digimon |
| --- | --- | --- |
| comun | 0 (0x00) | Chibickmon |
| comun | 1 (0x01) | Pickmon |
| comun | 2 (0x02) | Shoutmon |
| comun | 3 (0x03) | Shoutmon (King Ver.) |
| comun | 4 (0x04) | Shoutmon X2 |
| comun | 5 (0x05) | Shoutmon X3 |
| comun | 6 (0x06) | Shoutmon X3SD |
| comun | 7 (0x07) | Shoutmon X3GM |
| comun | 8 (0x08) | Shoutmon X4 |
| comun | 9 (0x09) | Shoutmon X4K |
| comun | 10 (0x0A) | Shoutmon X4S |
| comun | 11 (0x0B) | Shoutmon X4B |
| comun | 12 (0x0C) | Shoutmon X5 |
| comun | 13 (0x0D) | Shoutmon X5S |
| comun | 14 (0x0E) | Shoutmon X5B |
| comun | 15 (0x0F) | Omega Shoutmon |
| comun | 16 (0x10) | Shoutmon DX |
| comun | 17 (0x11) | Shoutmon EX6 |
| comun | 18 (0x12) | Shoutmon X7 |
| comun | 19 (0x13) | Gaossmon |
| comun | 20 (0x14) | Greymon (2010) |
| comun | 21 (0x15) | Metal Greymon (2010) |
| comun | 22 (0x16) | Decker Greymon |
| comun | 23 (0x17) | Grey Knightsmon |
| comun | 24 (0x18) | Zeke Greymon |
| comun | 25 (0x19) | Gumdramon |
| comun | 26 (0x1A) | Arresterdramon |
| comun | 27 (0x1B) | Armamon |
| comun | 28 (0x1C) | Ballistamon |
| comun | 28 (0x1C) | Atlur Ballistamon |
| comun | 29 (0x1D) | Starmons |
| comun | 29 (0x1D) | Shooting Starmon |
| comun | 30 (0x1E) | Dorulumon |
| comun | 30 (0x1E) | Jaeger Dorulumon |
| comun | 31 (0x1F) | King Whamon |
| comun | 32 (0x20) | Pawn Chessmon (White) |
| comun | 33 (0x21) | Knightmon |
| comun | 34 (0x22) | Baalmon |
| comun | 34 (0x22) | Beelzebumon (2010) |
| comun | 35 (0x23) | Sparrowmon |
| comun | 35 (0x23) | Raptor Sparrowmon |
| comun | 36 (0x24) | Spadamon |
| comun | 37 (0x25) | Mail Birdramon |
| comun | 38 (0x26) | Deckerdramon |
| comun | 39 (0x27) | Mammon |
| comun | 40 (0x28) | Troopmon |
| comun | 41 (0x29) | Octmon |
| comun | 42 (0x2A) | Ebidramon |
| comun | 43 (0x2B) | Death Meramon |
| comun | 44 (0x2C) | Ice Devimon |
| comun | 45 (0x2D) | Daipenmon |
| comun | 46 (0x2E) | Ebemon |
| comun | 47 (0x2F) | Slash Angemon |
| comun | 48 (0x30) | Lucemon: Falldown Mode |
| comun | 49 (0x31) | Grand Locomon |
| comun | 50 (0x32) | Valvemon |
| comun | 51 (0x33) | Waru Monzaemon |
| comun | 52 (0x34) | Breakdramon |
| comun | 53 (0x35) | Huanglongmon |
| comun | 54 (0x36) | Devimon |
| comun | 55 (0x37) | Lady Devimon |
| comun | 56 (0x38) | Gran Kuwagamon |
| comun | 57 (0x39) | Mummymon |
| comun | 58 (0x3A) | Marin Devimon |
| comun | 59 (0x3B) | Mermaimon |
| comun | 60 (0x3C) | Anubimon |
| comun | 61 (0x3D) | Tuwarmon |
| comun | 62 (0x3E) | Deadly Axemon |
| comun | 63 (0x3F) | Skull Knightmon |
| comun | 64 (0x40) | Venom Vamdemon |
| comun | 65 (0x41) | Belial Vamdemon |
| comun | 66 (0x42) | Mad Leomon |
| comun | 67 (0x43) | Neptunemon |
| comun | 68 (0x44) | Ancient Volcamon |
| comun | 69 (0x45) | Lilithmon |
| comun | 70 (0x46) | Mugendramon |
| comun | 71 (0x47) | Lucemon: Satan Mode |
| comun | 72 (0x48) | Blastmon |
| comun | 73 (0x49) | Tactimon |
| comun | 74 (0x4A) | Dorbickmon |
| comun | 75 (0x4B) | Neo Vamdemon |
| comun | 76 (0x4C) | Zamielmon |
| comun | 77 (0x4D) | Splashmon |
| comun | 78 (0x4E) | Splashmon Darkness Mode |
| comun | 79 (0x4F) | Olegmon |
| comun | 80 (0x50) | Gravimon |
| comun | 81 (0x51) | Apollomon Whispered |
| comun | 82 (0x52) | Dark Knightmon |
| comun | 83 (0x53) | Bagramon |
| comun | 84 (0x54) | Darkness Bagramon |
| comun | 85 (0x55) | Quartzmon |
| comun | 86 (0x56) | Shoutmon X7: Superior Mode |
| comun | 87 (0x57) | Arresterdramon: Superior Mode |
| comun | 88 (0x58) | Arresterdramon: Superior Mode (Brave Snatcher) |
| comun | 89 (0x59) | Armamon: Burst Mode |

Fuente: https://humulos.com/digimon/dmxw/list/

## Pendulum Color Godzilla (pengz)

IDs de la tabla publica; las versiones son los prefijos de esa fuente.

| Version | Identificador | Digimon |
| --- | --- | --- |
| comun | 0 (0x00) | Botamon |
| comun | 1 (0x01) | Punimon |
| comun | 2 (0x02) | Koromon |
| comun | 3 (0x03) | Tsunomon |
| comun | 4 (0x04) | Baby Godzilla |
| comun | 5 (0x05) | Agumon |
| comun | 6 (0x06) | Mothra (Larva) |
| comun | 7 (0x07) | Dorat |
| comun | 8 (0x08) | Monodramon |
| comun | 9 (0x09) | Gabumon |
| comun | 10 (0x0A) | Minilla |
| comun | 11 (0x0B) | Little Godzilla |
| comun | 12 (0x0C) | Greymon: G-Erosion Mode |
| comun | 13 (0x0D) | Tyranomon |
| comun | 14 (0x0E) | Flymon |
| comun | 15 (0x0F) | Mothra Leo |
| comun | 16 (0x10) | King Ghidorah (1991) |
| comun | 17 (0x11) | Gigan (2004) |
| comun | 18 (0x12) | Strikedramon |
| comun | 19 (0x13) | Raptordramon |
| comun | 20 (0x14) | Garurumon |
| comun | 21 (0x15) | Godzilla (1954) |
| comun | 22 (0x16) | Godzilla Jr |
| comun | 23 (0x17) | Metal Greymon (Vaccine): G-Erosion Mode |
| comun | 24 (0x18) | Master Tyranomon |
| comun | 25 (0x19) | Battra |
| comun | 26 (0x1A) | Aqua Mothra |
| comun | 27 (0x1B) | Skull Greymon: G-Erosion Mode |
| comun | 28 (0x1C) | Mecha-King Ghidorah |
| comun | 29 (0x1D) | Monster X |
| comun | 30 (0x1E) | Mechagodzilla (1974) |
| comun | 31 (0x1F) | Baragon |
| comun | 32 (0x20) | Were Garurumon |
| comun | 33 (0x21) | Metal Greymon (Virus): G-Erosion Mode |
| comun | 34 (0x22) | Atlur Kabuterimon |
| comun | 35 (0x23) | Godzilla (1999) |
| comun | 36 (0x24) | Godzilla (2004) |
| comun | 37 (0x25) | Godzilla (2022) |
| comun | 38 (0x26) | War Greymon: G-Erosion Mode |
| comun | 39 (0x27) | Dinomon |
| comun | 40 (0x28) | Armor Mothra |
| comun | 41 (0x29) | Mugendramon: MFS-3 |
| comun | 42 (0x2A) | Mechagodzilla (1993) |
| comun | 42 (0x2A) | Super Mechagodzilla |
| comun | 43 (0x2B) | King Ghidorah (2001) |
| comun | 44 (0x2C) | Keizer Ghidorah |
| comun | 45 (0x2D) | Jet Jaguar |
| comun | 46 (0x2E) | King Caesar |
| comun | 47 (0x2F) | Metal Garurumon |
| comun | 48 (0x30) | Metal Garurumon: G-Erosion Mode |
| comun | 49 (0x31) | Gatling Gigan |
| comun | 50 (0x32) | Black War Greymon: G-Erosion Mode |
| comun | 51 (0x33) | Megalon |
| comun | 52 (0x34) | Orga |
| comun | 53 (0x35) | Hedorah |
| comun | 54 (0x36) | Super Godzilla |
| comun | 55 (0x37) | Burning Godzilla (2025) |
| comun | 56 (0x38) | Omegamon: G-Fusion Mode |

Fuente: https://humulos.com/digimon/pengz/list/

## Digital Monster original (dmog)

Versiones originales 1-5. Slots 3-14; selecciona la version fisica porque V1 puede repetir la version del rival. Babies no combaten.

| Version | Identificador | Digimon |
| --- | --- | --- |
| 1 | No combate | Botamon |
| 1 | No combate | Koromon |
| 1 | 3 (0x03) | Agumon |
| 1 | 4 (0x04) | Betamon |
| 1 | 5 (0x05) | Greymon |
| 1 | 6 (0x06) | Tyranomon |
| 1 | 7 (0x07) | Devimon |
| 1 | 8 (0x08) | Meramon |
| 1 | 9 (0x09) | Airdramon |
| 1 | 10 (0x0A) | Seadramon |
| 1 | 11 (0x0B) | Numemon |
| 1 | 12 (0x0C) | MetalGreymon |
| 1 | 13 (0x0D) | Mamemon |
| 1 | 14 (0x0E) | Monzaemon |
| 2 | No combate | Punimon |
| 2 | No combate | Tsunomon |
| 2 | 3 (0x03) | Gabumon |
| 2 | 4 (0x04) | Elecmon |
| 2 | 5 (0x05) | Kabuterimon |
| 2 | 6 (0x06) | Garurumon |
| 2 | 7 (0x07) | Angemon |
| 2 | 8 (0x08) | Yukidarumon |
| 2 | 9 (0x09) | Birdramon |
| 2 | 10 (0x0A) | Whamon |
| 2 | 11 (0x0B) | Veggiemon |
| 2 | 12 (0x0C) | SkullGreymon |
| 2 | 13 (0x0D) | MetalMamemon |
| 2 | 14 (0x0E) | Vademon |
| 3 | No combate | Poyomon |
| 3 | No combate | Tokomon |
| 3 | 3 (0x03) | Patamon |
| 3 | 4 (0x04) | Kunemon |
| 3 | 5 (0x05) | Unimon |
| 3 | 6 (0x06) | Kentarumon |
| 3 | 7 (0x07) | Ogremon |
| 3 | 8 (0x08) | Bakemon |
| 3 | 9 (0x09) | Shellmon |
| 3 | 10 (0x0A) | Drimogemon |
| 3 | 11 (0x0B) | Sukamon |
| 3 | 12 (0x0C) | Andromon |
| 3 | 13 (0x0D) | Giromon |
| 3 | 14 (0x0E) | Etemon |
| 4 | No combate | Yuramon |
| 4 | No combate | Tanemon |
| 4 | 3 (0x03) | Piyomon |
| 4 | 4 (0x04) | Palmon |
| 4 | 5 (0x05) | Monochromon |
| 4 | 6 (0x06) | Cockatrimon |
| 4 | 7 (0x07) | Leomon |
| 4 | 8 (0x08) | Kuwagamon |
| 4 | 9 (0x09) | Coelamon |
| 4 | 10 (0x0A) | Mojamon |
| 4 | 11 (0x0B) | Nanimon |
| 4 | 12 (0x0C) | Megadramon |
| 4 | 13 (0x0D) | Piccolomon |
| 4 | 14 (0x0E) | Digitamamon |
| 5 | No combate | Zurumon |
| 5 | No combate | Pagumon |
| 5 | 3 (0x03) | Gazimon |
| 5 | 4 (0x04) | Gizamon |
| 5 | 5 (0x05) | DarkTyranomon |
| 5 | 6 (0x06) | Cyclomon |
| 5 | 7 (0x07) | Devidramon |
| 5 | 8 (0x08) | Tuskmon |
| 5 | 9 (0x09) | Flymon |
| 5 | 10 (0x0A) | Deltamon |
| 5 | 11 (0x0B) | Raremon |
| 5 | 12 (0x0C) | MetalTyranomon |
| 5 | 13 (0x0D) | Nanomon |
| 5 | 14 (0x0E) | X-Tyranomon |

Fuente: https://lcd.withthewill.net/VpetProfiles

## Pendulum original (penog)

Slots de batalla publicados por familia. Las versiones .0 y .5 comparten version y slots; pueden existir dos candidatos.

| Version | Identificador | Digimon |
| --- | --- | --- |
| 1.0/1.5 | No combate | Bubbmon |
| 1.0/1.5 | No combate | Mochimon |
| 1.0/1.5 | 3 (0x03) | Tentomon |
| 1.0/1.5 | 4 (0x04) | Gottsumon |
| 1.0/1.5 | 5 (0x05) | Otamamon |
| 1.0/1.5 | 6 (0x06) | Kabuterimon |
| 1.0/1.5 | 7 (0x07) | Tortamon |
| 1.0/1.5 | 7 (0x07) | Tailmon |
| 1.0/1.5 | 8 (0x08) | Monochromon |
| 1.0/1.5 | 9 (0x09) | Starmon |
| 1.0/1.5 | 10 (0x0A) | Kuwagamon |
| 1.0/1.5 | 11 (0x0B) | Gekomon |
| 1.0/1.5 | 12 (0x0C) | Atlur Kabuterimon |
| 1.0/1.5 | 13 (0x0D) | Jyagamon |
| 1.0/1.5 | 13 (0x0D) | Angewomon |
| 1.0/1.5 | 14 (0x0E) | Triceramon |
| 1.0/1.5 | 15 (0x0F) | Piccolomon |
| 1.0/1.5 | 16 (0x10) | Okuwamon |
| 1.0/1.5 | 17 (0x11) | Tonosama Gekomon |
| 1.0/1.5 | 18 (0x12) | Herakle Kabuterimon |
| 1.0/1.5 | 18 (0x12) | Holydramon |
| 1.0/1.5 | 19 (0x13) | Saber Leomon |
| 1.0/1.5 | 20 (0x14) | Metal Etemon |
| 2.0/2.5 | No combate | Pitchmon |
| 2.0/2.5 | No combate | Pukamon |
| 2.0/2.5 | 3 (0x03) | Gomamon |
| 2.0/2.5 | 4 (0x04) | Ganimon |
| 2.0/2.5 | 5 (0x05) | Shakomon |
| 2.0/2.5 | 6 (0x06) | Ikkakumon |
| 2.0/2.5 | 7 (0x07) | Rukamon |
| 2.0/2.5 | 8 (0x08) | Seadramon |
| 2.0/2.5 | 9 (0x09) | Coelamon |
| 2.0/2.5 | 9 (0x09) | Ebidramon |
| 2.0/2.5 | 10 (0x0A) | Gesomon |
| 2.0/2.5 | 11 (0x0B) | Octmon |
| 2.0/2.5 | 12 (0x0C) | Zudomon |
| 2.0/2.5 | 13 (0x0D) | Whamon |
| 2.0/2.5 | 14 (0x0E) | Mega Seadramon |
| 2.0/2.5 | 15 (0x0F) | Anomalocarimon |
| 2.0/2.5 | 15 (0x0F) | Hangyomon |
| 2.0/2.5 | 16 (0x10) | Marin Devimon |
| 2.0/2.5 | 17 (0x11) | Dagomon |
| 2.0/2.5 | 18 (0x12) | Marin Angemon |
| 2.0/2.5 | 19 (0x13) | Metal Seadramon |
| 2.0/2.5 | 19 (0x13) | Plesiomon |
| 2.0/2.5 | 20 (0x14) | Pukumon |
| 3.0/3.5 | No combate | Mokumon |
| 3.0/3.5 | No combate | Peti Meramon |
| 3.0/3.5 | 3 (0x03) | Bakumon |
| 3.0/3.5 | 4 (0x04) | Candmon |
| 3.0/3.5 | 5 (0x05) | Pico Devimon |
| 3.0/3.5 | 6 (0x06) | Hanumon |
| 3.0/3.5 | 7 (0x07) | Garurumon |
| 3.0/3.5 | 8 (0x08) | Meramon |
| 3.0/3.5 | 9 (0x09) | Wizarmon |
| 3.0/3.5 | 10 (0x0A) | Devimon |
| 3.0/3.5 | 11 (0x0B) | Bakemon |
| 3.0/3.5 | 11 (0x0B) | Dokugumon |
| 3.0/3.5 | 12 (0x0C) | Mammon |
| 3.0/3.5 | 13 (0x0D) | Were Garurumon |
| 3.0/3.5 | 14 (0x0E) | Death Meramon |
| 3.0/3.5 | 15 (0x0F) | Pumpmon |
| 3.0/3.5 | 16 (0x10) | Vamdemon |
| 3.0/3.5 | 16 (0x10) | Lady Devimon |
| 3.0/3.5 | 17 (0x11) | Fantomon |
| 3.0/3.5 | 18 (0x12) | Skull Mammon |
| 3.0/3.5 | 19 (0x13) | Boltmon |
| 3.0/3.5 | 20 (0x14) | Piemon |
| 3.0/3.5 | 20 (0x14) | Demon |
| 4.0/4.5 | No combate | Nyokimon |
| 4.0/4.5 | No combate | Pyocomon |
| 4.0/4.5 | 3 (0x03) | Piyomon |
| 4.0/4.5 | 4 (0x04) | Floramon |
| 4.0/4.5 | 4 (0x04) | Palmon |
| 4.0/4.5 | 5 (0x05) | Mushmon |
| 4.0/4.5 | 6 (0x06) | V-dramon |
| 4.0/4.5 | 7 (0x07) | Birdramon |
| 4.0/4.5 | 8 (0x08) | Togemon |
| 4.0/4.5 | 9 (0x09) | Kiwimon |
| 4.0/4.5 | 10 (0x0A) | Woodmon |
| 4.0/4.5 | 11 (0x0B) | Red Vegimon |
| 4.0/4.5 | 12 (0x0C) | Aero V-dramon |
| 4.0/4.5 | 13 (0x0D) | Garudamon |
| 4.0/4.5 | 14 (0x0E) | Blossomon |
| 4.0/4.5 | 14 (0x0E) | Lilimon |
| 4.0/4.5 | 15 (0x0F) | Delumon |
| 4.0/4.5 | 16 (0x10) | Jyureimon |
| 4.0/4.5 | 17 (0x11) | Gerbemon |
| 4.0/4.5 | 18 (0x12) | Hououmon |
| 4.0/4.5 | 19 (0x13) | Griffomon |
| 4.0/4.5 | 19 (0x13) | Rosemon |
| 4.0/4.5 | 20 (0x14) | Pinochimon |
| 5.0/5.5 | No combate | Choromon |
| 5.0/5.5 | No combate | Caprimon |
| 5.0/5.5 | 3 (0x03) | Toy Agumon |
| 5.0/5.5 | 4 (0x04) | Kokuwamon |
| 5.0/5.5 | 5 (0x05) | Hagurumon |
| 5.0/5.5 | 6 (0x06) | Greymon |
| 5.0/5.5 | 7 (0x07) | Revolmon |
| 5.0/5.5 | 8 (0x08) | Tankmon |
| 5.0/5.5 | 8 (0x08) | Thunderballmon |
| 5.0/5.5 | 9 (0x09) | Clockmon |
| 5.0/5.5 | 10 (0x0A) | Guardromon |
| 5.0/5.5 | 11 (0x0B) | Mechanorimon |
| 5.0/5.5 | 12 (0x0C) | Metal Greymon |
| 5.0/5.5 | 13 (0x0D) | Andromon |
| 5.0/5.5 | 13 (0x0D) | Cyberdramon |
| 5.0/5.5 | 14 (0x0E) | Knightmon |
| 5.0/5.5 | 15 (0x0F) | Big Mamemon |
| 5.0/5.5 | 16 (0x10) | Megadramon |
| 5.0/5.5 | 17 (0x11) | Waru Monzaemon |
| 5.0/5.5 | 18 (0x12) | War Greymon |
| 5.0/5.5 | 19 (0x13) | Metal Garurumon |
| 5.0/5.5 | 20 (0x14) | Mugendramon |
| 5.0/5.5 | 20 (0x14) | Venom Vamdemon |
| ZERO | No combate | Yukimibotamon |
| ZERO | No combate | Nyaromon |
| ZERO | 3 (0x03) | Agumon |
| ZERO | 4 (0x04) | Gabumon |
| ZERO | 5 (0x05) | Plotmon |
| ZERO | 6 (0x06) | Greymon |
| ZERO | 7 (0x07) | Leomon |
| ZERO | 8 (0x08) | Garurumon |
| ZERO | 9 (0x09) | Igamon |
| ZERO | 10 (0x0A) | Angemon |
| ZERO | 11 (0x0B) | Tailmon |
| ZERO | 12 (0x0C) | Metal Greymon |
| ZERO | 13 (0x0D) | Asuramon |
| ZERO | 14 (0x0E) | Were Garurumon |
| ZERO | 15 (0x0F) | Metal Mamemon |
| ZERO | 16 (0x10) | Holy Angemon |
| ZERO | 17 (0x11) | Angewomon |
| ZERO | 18 (0x12) | War Greymon |
| ZERO | 19 (0x13) | Metal Garurumon |
| ZERO | 20 (0x14) | Omegamon |

Fuente: https://humulos.com/digimon/pen/

## Pendulum Progress (penprog)

Roster publicado; IDs sin documentar marcados como pendientes. Koromon Mini 1.0
usa el slot observado en una captura local completa.

| Version | Identificador | Digimon |
| --- | --- | --- |
| PenProg 1.0 | PENDIENTE | Jarimon |
| PenProg 1.0 | PENDIENTE | Gigimon |
| PenProg 1.0 | PENDIENTE | Agumon |
| PenProg 1.0 | PENDIENTE | V-mon |
| PenProg 1.0 | PENDIENTE | Guilmon |
| PenProg 1.0 | PENDIENTE | Greymon |
| PenProg 1.0 | PENDIENTE | Tyranomon |
| PenProg 1.0 | PENDIENTE | XV-mon |
| PenProg 1.0 | PENDIENTE | V-Dramon |
| PenProg 1.0 | PENDIENTE | Growmon |
| PenProg 1.0 | PENDIENTE | Airdramon |
| PenProg 1.0 | PENDIENTE | MetalGreymon |
| PenProg 1.0 | PENDIENTE | MetalTyranomon |
| PenProg 1.0 | PENDIENTE | Paildramon |
| PenProg 1.0 | PENDIENTE | Aero V-Dramon |
| PenProg 1.0 | PENDIENTE | MegaloGrowmon |
| PenProg 1.0 | PENDIENTE | Megadramon |
| PenProg 1.0 | PENDIENTE | WarGreymon |
| PenProg 1.0 | PENDIENTE | Chaosdramon |
| PenProg 1.0 | PENDIENTE | Imperialdramon |
| PenProg 1.0 | PENDIENTE | Alforce V-Dramon |
| PenProg 1.0 | PENDIENTE | Dukemon |
| PenProg 1.0 | PENDIENTE | Megidramon |
| PenProg 2.0 | PENDIENTE | Puttomon |
| PenProg 2.0 | PENDIENTE | Cupimon |
| PenProg 2.0 | PENDIENTE | Patamon |
| PenProg 2.0 | PENDIENTE | Terriermon |
| PenProg 2.0 | PENDIENTE | Impmon |
| PenProg 2.0 | PENDIENTE | Lucemon |
| PenProg 2.0 | PENDIENTE | Angemon |
| PenProg 2.0 | PENDIENTE | Tailmon |
| PenProg 2.0 | PENDIENTE | Shiisamon |
| PenProg 2.0 | PENDIENTE | Witchmon |
| PenProg 2.0 | PENDIENTE | Devimon |
| PenProg 2.0 | PENDIENTE | BlackTailmon |
| PenProg 2.0 | PENDIENTE | HolyAngemon |
| PenProg 2.0 | PENDIENTE | Angewomon |
| PenProg 2.0 | PENDIENTE | Antiramon |
| PenProg 2.0 | PENDIENTE | Bastemon |
| PenProg 2.0 | PENDIENTE | NeoDevimon |
| PenProg 2.0 | PENDIENTE | LadyDevimon |
| PenProg 2.0 | PENDIENTE | Seraphimon |
| PenProg 2.0 | PENDIENTE | Ophanimon |
| PenProg 2.0 | PENDIENTE | Cherubimon |
| PenProg 2.0 | PENDIENTE | Beelzebumon |
| PenProg 2.0 | PENDIENTE | Lilithmon |
| PenProg 3.0 | PENDIENTE | Babumon |
| PenProg 3.0 | PENDIENTE | Nyaromon |
| PenProg 3.0 | PENDIENTE | Gabumon |
| PenProg 3.0 | PENDIENTE | Bearmon |
| PenProg 3.0 | PENDIENTE | Hawkmon |
| PenProg 3.0 | PENDIENTE | Garurumon |
| PenProg 3.0 | PENDIENTE | Dobermon |
| PenProg 3.0 | PENDIENTE | Grizzmon |
| PenProg 3.0 | PENDIENTE | Leomon X |
| PenProg 3.0 | PENDIENTE | Aquilamon |
| PenProg 3.0 | PENDIENTE | Kiwimon |
| PenProg 3.0 | PENDIENTE | WereGarurumon X |
| PenProg 3.0 | PENDIENTE | Cerberumon X |
| PenProg 3.0 | PENDIENTE | Mihiramon |
| PenProg 3.0 | PENDIENTE | GrappLeomon |
| PenProg 3.0 | PENDIENTE | Garudamon X |
| PenProg 3.0 | PENDIENTE | Deramon |
| PenProg 3.0 | PENDIENTE | MetalGarurumon X |
| PenProg 3.0 | PENDIENTE | Baihumon |
| PenProg 3.0 | PENDIENTE | Qinglongmon |
| PenProg 3.0 | PENDIENTE | Zhuqiaomon |
| PenProg 3.0 | PENDIENTE | Xuanwumon |
| PenProg 3.0 | PENDIENTE | Omegamon |

Fuente: https://lcd.withthewill.net/ProgProfiles

## Pendulum X (penx)

Roster publicado; IDs sin documentar marcados como pendientes, sin deducirlos por el orden.

| Version | Identificador | Digimon |
| --- | --- | --- |
| Pendulum X 1.0/1.5 | PENDIENTE | Dodomon |
| Pendulum X 1.0/1.5 | PENDIENTE | Dorimon |
| Pendulum X 1.0/1.5 | PENDIENTE | Agumon X |
| Pendulum X 1.0/1.5 | PENDIENTE | Dorumon |
| Pendulum X 1.0/1.5 | PENDIENTE | Greymon X |
| Pendulum X 1.0/1.5 | PENDIENTE | Raptordramon (1.0) |
| Pendulum X 1.0/1.5 | PENDIENTE | Dorugamon |
| Pendulum X 1.0/1.5 | PENDIENTE | Death-X-Dorugamon (1.5) |
| Pendulum X 1.0/1.5 | PENDIENTE | Seadramon X |
| Pendulum X 1.0/1.5 | 21 (0x15) | Kuwagamon X |
| Pendulum X 1.0/1.5 | PENDIENTE | MetalGreymon X |
| Pendulum X 1.0/1.5 | PENDIENTE | Grademon (1.0) |
| Pendulum X 1.0/1.5 | PENDIENTE | Dorugremon |
| Pendulum X 1.0/1.5 | PENDIENTE | Death-X-Dorugremon (1.5) |
| Pendulum X 1.0/1.5 | PENDIENTE | MegaSeadramon X |
| Pendulum X 1.0/1.5 | 36 (0x24) | Okuwamon X |
| Pendulum X 1.0/1.5 | PENDIENTE | WarGreymon X (1.0) |
| Pendulum X 1.0/1.5 | PENDIENTE | Gaioumon (1.5) |
| Pendulum X 1.0/1.5 | PENDIENTE | Alphamon (1.0) |
| Pendulum X 1.0/1.5 | PENDIENTE | Dorugoramon |
| Pendulum X 1.0/1.5 | PENDIENTE | Death-X-Dorugoramon (1.5) |
| Pendulum X 1.0/1.5 | PENDIENTE | GigaSeadramon |
| Pendulum X 1.0/1.5 | PENDIENTE | GrandisKuwagamon |
| Pendulum X 1.0/1.5 | PENDIENTE | Omegamon X |
| Pendulum X 2.0/2.5 | PENDIENTE | Fufumon |
| Pendulum X 2.0/2.5 | PENDIENTE | Kyokyomon |
| Pendulum X 2.0/2.5 | PENDIENTE | Ryuudamon |
| Pendulum X 2.0/2.5 | PENDIENTE | Guilmon X |
| Pendulum X 2.0/2.5 | PENDIENTE | GinRyumon |
| Pendulum X 2.0/2.5 | PENDIENTE | TobuCatmon |
| Pendulum X 2.0/2.5 | PENDIENTE | Allomon X |
| Pendulum X 2.0/2.5 | PENDIENTE | Growmon X |
| Pendulum X 2.0/2.5 | PENDIENTE | Monochromon X |
| Pendulum X 2.0/2.5 | PENDIENTE | Hisharyumon |
| Pendulum X 2.0/2.5 | PENDIENTE | SkullBaluchimon |
| Pendulum X 2.0/2.5 | PENDIENTE | MameTyramon |
| Pendulum X 2.0/2.5 | PENDIENTE | MegaloGrowmon X |
| Pendulum X 2.0/2.5 | 38 (0x26) | Triceramon X |
| Pendulum X 2.0/2.5 | PENDIENTE | Ouryumon |
| Pendulum X 2.0/2.5 | PENDIENTE | DinoTigemon (2.0) |
| Pendulum X 2.0/2.5 | PENDIENTE | DinoRexmon |
| Pendulum X 2.0/2.5 | PENDIENTE | MedievalDukemon |
| Pendulum X 2.0/2.5 | PENDIENTE | UltimateBrachimon |
| Pendulum X 2.0/2.5 | PENDIENTE | Dukemon X |
| Pendulum X 2.0/2.5 | PENDIENTE | Alforce V-Dramon X (2.5) |
| Pendulum X 3.0 | PENDIENTE | Pupumon |
| Pendulum X 3.0 | PENDIENTE | Proromon |
| Pendulum X 3.0 | PENDIENTE | Ryuudamon |
| Pendulum X 3.0 | PENDIENTE | Dorumon |
| Pendulum X 3.0 | PENDIENTE | FanBeemon |
| Pendulum X 3.0 | PENDIENTE | Raptordramon |
| Pendulum X 3.0 | PENDIENTE | Ginryumon |
| Pendulum X 3.0 | PENDIENTE | Waspmon |
| Pendulum X 3.0 | PENDIENTE | Omekamon |
| Pendulum X 3.0 | PENDIENTE | Grademon |
| Pendulum X 3.0 | PENDIENTE | Hisharyumon |
| Pendulum X 3.0 | PENDIENTE | CannonBeemon |
| Pendulum X 3.0 | PENDIENTE | MetalPhantmon |
| Pendulum X 3.0 | PENDIENTE | Alphamon |
| Pendulum X 3.0 | PENDIENTE | Ouryumon |
| Pendulum X 3.0 | PENDIENTE | TigerVespamon |
| Pendulum X 3.0 | PENDIENTE | MetalPiranhmon |
| Pendulum X 3.0 | PENDIENTE | Alphamon Ouryuken |
| Pendulum X 3.0 | PENDIENTE | Omegamon X |
| Pendulum X 3.0 | PENDIENTE | Dukemon X |
| Pendulum X 3.0 | PENDIENTE | Magnamon X |
| Pendulum X 3.0 | PENDIENTE | Dynasmon X |
| Pendulum X 3.0 | PENDIENTE | Death-Xmon |

Fuente: https://lcd.withthewill.net/PenxProfiles

## Digimon Accel (accel)

Roster por Genome; IDs de batalla pendientes. Usa tres pines y timing X; no usa infrarrojo.

| Version | Identificador | Digimon |
| --- | --- | --- |
| Justice Genome | PENDIENTE | Popomon |
| Justice Genome | PENDIENTE | Frimon |
| Justice Genome | PENDIENTE | Agumon X |
| Justice Genome | PENDIENTE | Piyomon |
| Justice Genome | PENDIENTE | Leormon |
| Justice Genome | PENDIENTE | Patamon |
| Justice Genome | PENDIENTE | Otamamon |
| Justice Genome | PENDIENTE | KoKabuterimon |
| Justice Genome | PENDIENTE | Greymon X |
| Justice Genome | PENDIENTE | Aquilamon |
| Justice Genome | PENDIENTE | Raiamon |
| Justice Genome | PENDIENTE | Pegasmon |
| Justice Genome | PENDIENTE | Coelamon |
| Justice Genome | PENDIENTE | BladeKuwagamon |
| Justice Genome | PENDIENTE | Revolmon |
| Justice Genome | PENDIENTE | MetalGreymon X |
| Justice Genome | PENDIENTE | Garudamon X |
| Justice Genome | PENDIENTE | LoaderLeomon |
| Justice Genome | PENDIENTE | HolyAngemon |
| Justice Genome | PENDIENTE | Dagomon |
| Justice Genome | PENDIENTE | MetalliferKuwagamon |
| Justice Genome | PENDIENTE | Volcdramon |
| Justice Genome | PENDIENTE | Chimeramon |
| Justice Genome | PENDIENTE | WarGreymon X |
| Justice Genome | PENDIENTE | Hououmon |
| Justice Genome | PENDIENTE | BanchouLeomon |
| Justice Genome | PENDIENTE | TyrantKabuterimon |
| Justice Genome | PENDIENTE | MetalEtemon |
| Justice Genome | PENDIENTE | Omegamon X |
| Justice Genome | PENDIENTE | Chaosmon |
| Evil Genome | PENDIENTE | Bombmon |
| Evil Genome | PENDIENTE | Missimon |
| Evil Genome | PENDIENTE | Hagurumon |
| Evil Genome | PENDIENTE | Gizamon |
| Evil Genome | PENDIENTE | Commandramon |
| Evil Genome | PENDIENTE | Dracmon |
| Evil Genome | PENDIENTE | Tentomon |
| Evil Genome | PENDIENTE | Penmon |
| Evil Genome | PENDIENTE | Meramon |
| Evil Genome | PENDIENTE | Gekomon |
| Evil Genome | PENDIENTE | Sealsdramon |
| Evil Genome | PENDIENTE | Sangloupmon |
| Evil Genome | PENDIENTE | Thunderbirmon |
| Evil Genome | PENDIENTE | Snimon |
| Evil Genome | PENDIENTE | Dobermon |
| Evil Genome | PENDIENTE | Volcamon |
| Evil Genome | PENDIENTE | Zudomon |
| Evil Genome | PENDIENTE | Tankdramon |
| Evil Genome | PENDIENTE | Matadormon |
| Evil Genome | PENDIENTE | HippoGryphomon |
| Evil Genome | PENDIENTE | Angewomon |
| Evil Genome | PENDIENTE | MarineDevimon |
| Evil Genome | PENDIENTE | Scorpiomon |
| Evil Genome | PENDIENTE | Mugendramon |
| Evil Genome | PENDIENTE | MarineAngemon |
| Evil Genome | PENDIENTE | Darkdramon |
| Evil Genome | PENDIENTE | GranDracmon |
| Evil Genome | PENDIENTE | Seraphimon |
| Evil Genome | PENDIENTE | Dukemon X |
| Evil Genome | PENDIENTE | Chaosmon |
| Nature Genome | PENDIENTE | Puwamon |
| Nature Genome | PENDIENTE | Pinamon |
| Nature Genome | PENDIENTE | Falcomon |
| Nature Genome | PENDIENTE | Mushmon |
| Nature Genome | PENDIENTE | Goblimon |
| Nature Genome | PENDIENTE | Swimmon |
| Nature Genome | PENDIENTE | Gotsumon |
| Nature Genome | PENDIENTE | Terriermon |
| Nature Genome | PENDIENTE | Diatrymon |
| Nature Genome | PENDIENTE | Igamon |
| Nature Genome | PENDIENTE | Seahomon |
| Nature Genome | PENDIENTE | Ogremon |
| Nature Genome | PENDIENTE | Nohemon |
| Nature Genome | PENDIENTE | Tailmon |
| Nature Genome | PENDIENTE | Tyranomon |
| Nature Genome | PENDIENTE | Yatagaramon |
| Nature Genome | PENDIENTE | Triceramon X |
| Nature Genome | PENDIENTE | Whamon |
| Nature Genome | PENDIENTE | Garbamon |
| Nature Genome | PENDIENTE | Antiramon |
| Nature Genome | PENDIENTE | Mamemon |
| Nature Genome | PENDIENTE | Jagamon |
| Nature Genome | PENDIENTE | WereGarurumon X |
| Nature Genome | PENDIENTE | Valdurmon |
| Nature Genome | PENDIENTE | Spinomon |
| Nature Genome | PENDIENTE | Neptunmon |
| Nature Genome | PENDIENTE | Mercurimon |
| Nature Genome | PENDIENTE | Rosemon |
| Nature Genome | PENDIENTE | Alforce V-Dramon |
| Nature Genome | PENDIENTE | Chaosmon |
| Ultimate Genome | PENDIENTE | Pafumon |
| Ultimate Genome | PENDIENTE | Kyaromon |
| Ultimate Genome | PENDIENTE | Kudamon |
| Ultimate Genome | PENDIENTE | Impmon |
| Ultimate Genome | PENDIENTE | Candmon |
| Ultimate Genome | PENDIENTE | Palmon |
| Ultimate Genome | PENDIENTE | Reppamon |
| Ultimate Genome | PENDIENTE | Devidramon |
| Ultimate Genome | PENDIENTE | Togemon |
| Ultimate Genome | PENDIENTE | Submarimon |
| Ultimate Genome | PENDIENTE | FlareLizamon |
| Ultimate Genome | PENDIENTE | Qilinmon |
| Ultimate Genome | PENDIENTE | Cerberumon |
| Ultimate Genome | PENDIENTE | Cyberdramon |
| Ultimate Genome | PENDIENTE | Pumpmon |
| Ultimate Genome | PENDIENTE | Piccolomon |
| Ultimate Genome | PENDIENTE | Deramon |
| Ultimate Genome | PENDIENTE | Sleipmon |
| Ultimate Genome | PENDIENTE | Beelzebumon |
| Ultimate Genome | PENDIENTE | Megidramon |
| Ultimate Genome | PENDIENTE | Bolgmon |
| Ultimate Genome | PENDIENTE | BanchouLeomon |
| Ultimate Genome | PENDIENTE | Darkdramon |
| Ultimate Genome | PENDIENTE | Valdurmon |
| Ultimate Genome | PENDIENTE | Chaosmon |
| Ultimate Genome | PENDIENTE | UltimateChaosmon |
| Ultimate Genome | PENDIENTE | Dodomon |
| Ultimate Genome | PENDIENTE | Dorimon |
| Ultimate Genome | PENDIENTE | Dorumon |
| Ultimate Genome | PENDIENTE | Dorugamon |
| Ultimate Genome | PENDIENTE | Dorugremon |
| Ultimate Genome | PENDIENTE | Alphamon |

Fuente: https://lcd.withthewill.net/AccelIntro

## Digimon Mini (mini)

Roster publicado; IDs sin documentar marcados como pendientes, sin deducirlos por el orden.

| Version | Identificador | Digimon |
| --- | --- | --- |
| Mini 1.0 | PENDIENTE | Botamon |
| Mini 1.0 | 1 (0x01) | Koromon |
| Mini 1.0 | PENDIENTE | Agumon |
| Mini 1.0 | PENDIENTE | Gabumon |
| Mini 1.0 | PENDIENTE | Betamon |
| Mini 1.0 | PENDIENTE | Greymon |
| Mini 1.0 | PENDIENTE | Garurumon |
| Mini 1.0 | PENDIENTE | Seadramon |
| Mini 1.0 | PENDIENTE | Numemon |
| Mini 1.0 | PENDIENTE | MetalGreymon |
| Mini 1.0 | PENDIENTE | Triceramon |
| Mini 1.0 | PENDIENTE | WarGreymon |
| Mini 1.0 | PENDIENTE | Omegamon |
| Mini 2.0 | PENDIENTE | Babumon |
| Mini 2.0 | PENDIENTE | Motimon |
| Mini 2.0 | PENDIENTE | Tentomon |
| Mini 2.0 | PENDIENTE | Elecmon |
| Mini 2.0 | PENDIENTE | Kunemon |
| Mini 2.0 | PENDIENTE | Kabuterimon |
| Mini 2.0 | PENDIENTE | Kentarumon |
| Mini 2.0 | PENDIENTE | Tyranomon |
| Mini 2.0 | PENDIENTE | Sukamon |
| Mini 2.0 | PENDIENTE | AtlurKabuterimon |
| Mini 2.0 | PENDIENTE | WaruMonzaemon |
| Mini 2.0 | PENDIENTE | HeraclesKabuterimon |
| Mini 2.0 | PENDIENTE | TyrantKabuterimon |
| Mini 3.0 | PENDIENTE | Poyomon |
| Mini 3.0 | PENDIENTE | Tokomon |
| Mini 3.0 | PENDIENTE | Patamon |
| Mini 3.0 | PENDIENTE | PicoDevimon |
| Mini 3.0 | PENDIENTE | Ganimon |
| Mini 3.0 | PENDIENTE | Angemon |
| Mini 3.0 | PENDIENTE | Devimon |
| Mini 3.0 | PENDIENTE | Leomon |
| Mini 3.0 | PENDIENTE | Shellmon |
| Mini 3.0 | PENDIENTE | Coelamon |
| Mini 3.0 | PENDIENTE | Nanimon |
| Mini 3.0 | PENDIENTE | HolyAngemon |
| Mini 3.0 | PENDIENTE | Vamdemon |
| Mini 3.0 | PENDIENTE | Etemon |
| Mini 3.0 | PENDIENTE | Holydramon |
| Mini 3.0 | PENDIENTE | Piemon |
| Mini 3.0 | PENDIENTE | BanchouLeomon |

Fuente: https://lcd.withthewill.net/MiniProfiles

## Otras familias y limites

iC/Burst, Twin, Mini especiales, Pendulum Cycle, D-Cyber y Xros Mini:
no se dispone aun de un mapa completo de IDs verificado en este catalogo.
Los dispositivos infrarrojos o NFC necesitan interfaces adicionales; no se identifican solo por conectar dos contactos.
Los nuevos modelos/reediciones no se consideran cubiertos automaticamente por compartir nombre o carcasa.
