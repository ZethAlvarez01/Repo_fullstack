import unittest
from unittest.mock import AsyncMock, patch
from pathlib import Path

from fastapi import HTTPException

from web_app import (
    BattleProbabilityRequest,
    BattleRequest,
    battle,
    battle_probability,
    battle_probability_config,
    resolve_port,
    usb_bridge,
)


class WebBattleTests(unittest.IsolatedAsyncioTestCase):
    def test_mobile_webusb_bridge_is_exposed_in_the_interface(self):
        root = Path(__file__).parent
        html = (root / "web" / "index.html").read_text(encoding="utf-8")
        javascript = (root / "web" / "app.js").read_text(encoding="utf-8")
        bridge = (root / "web" / "webusb_bridge.js").read_text(encoding="utf-8")
        self.assertIn('id="usbBetaLinkButton"', html)
        self.assertIn('value = "webusb"', javascript)
        self.assertIn("WebUSBSerialPort.requestPort", bridge)
        self.assertIn("baudRate: 9600", bridge)
        self.assertIn("DigimonAlphaEventsSocket", bridge)
        self.assertIn('type: "usb-connect"', bridge)

    def test_webusb_port_requires_an_active_browser_bridge(self):
        original_server = usb_bridge.server
        original_port = usb_bridge.port
        try:
            usb_bridge.server = None
            usb_bridge.port = None
            with self.assertRaises(HTTPException):
                resolve_port("webusb")
        finally:
            usb_bridge.server = original_server
            usb_bridge.port = original_port

    def test_player_location_uses_realtime_browser_geolocation(self):
        javascript = (Path(__file__).parent / "web" / "app.js").read_text(encoding="utf-8")
        html = (Path(__file__).parent / "web" / "index.html").read_text(encoding="utf-8")
        css = (Path(__file__).parent / "web" / "styles.css").read_text(encoding="utf-8")

        self.assertIn("function startPlayerLocationTracking", javascript)
        self.assertIn("navigator.geolocation.watchPosition", javascript)
        self.assertIn("navigator.geolocation.clearWatch", javascript)
        self.assertIn('new CustomEvent("playerlocationchange"', javascript)
        self.assertIn("window.DigimonAlphaLocation", javascript)
        self.assertIn('id="playerLatitude"', html)
        self.assertIn('id="playerLongitude"', html)
        self.assertIn('id="playerAccuracy"', html)
        self.assertIn('id="playerLocationButton"', html)
        self.assertIn(".location-coordinates", css)

    def test_battle_ui_delays_result_and_includes_projectile_assets(self):
        root = Path(__file__).parent
        javascript = (root / "web" / "app.js").read_text(encoding="utf-8")
        html = (root / "web" / "index.html").read_text(encoding="utf-8")
        css = (root / "web" / "styles.css").read_text(encoding="utf-8")

        self.assertIn("BATTLE_REVEAL_DELAY_MS = 10000", javascript)
        self.assertIn("queueBattleOutcome(`GANADOR: ${winner}`, winner)", javascript)
        self.assertIn('.replace(/\\bbeelzebumon\\b/g, "beelzemon")', javascript)
        self.assertIn('.replace(/\\bx antibody\\b/g, "x")', javascript)
        self.assertIn('.replace(/\\s+/g, "")', javascript)
        self.assertIn("/assets/projectile-web.png", html)
        self.assertIn("/assets/projectile-vpet.png", html)
        self.assertIn(".combatant.winner", css)

    def test_general_reset_clears_the_complete_interface(self):
        root = Path(__file__).parent
        javascript = (root / "web" / "app.js").read_text(encoding="utf-8")
        html = (root / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn('id="resetAllButton"', html)
        self.assertIn("async function resetAll()", javascript)
        self.assertIn('resetCombatant("fighter", "Elige un Digimon")', javascript)
        self.assertIn('resetCombatant("vpet", "Esperando rival")', javascript)
        self.assertIn('await api("/api/reset"', javascript)
        self.assertNotIn('$("#modelSelect").value = "penx"', javascript)

    async def test_penx_battle_detects_vpet_before_calculating_result(self):
        request = BattleRequest(
            model="penx", port="COM9", wait=30,
            fighter="Gekomon",
        )

        with (
            patch("web_app.resolve_port", return_value="COM9"),
            patch("web_app.manager.start", new_callable=AsyncMock) as start,
        ):
            response = await battle(request)

        args, operation = start.await_args.args
        self.assertIn("--batalla-ponderada", args)
        self.assertIn("--rival-visual", args)
        self.assertIn("Gekomon", args)
        self.assertNotIn("--resultado-vpet", args)
        self.assertEqual(operation["fighter"], "Gekomon")
        self.assertEqual(response["fighter"], "Gekomon")
        self.assertNotIn("probability", response)

    async def test_dmx_supports_single_connection_battle(self):
        request = BattleRequest(model="dmx", port="COM9", fighter="Gekomon")

        with (
            patch("web_app.resolve_port", return_value="COM9"),
            patch("web_app.manager.start", new_callable=AsyncMock) as start,
        ):
            response = await battle(request)

        args = start.await_args.args[0]
        self.assertIn("--batalla-ponderada", args)
        self.assertEqual(response["model"], "dmx")

    async def test_mini_is_exposed_as_its_own_three_pin_model(self):
        request = BattleRequest(model="mini", port="COM9", fighter="Gekomon")
        with (
            patch("web_app.resolve_port", return_value="COM9"),
            patch("web_app.manager.start", new_callable=AsyncMock) as start,
        ):
            response = await battle(request)
        args = start.await_args.args[0]
        self.assertIn("mini", args)
        self.assertEqual(response["model"], "mini")

    async def test_xros_mini_and_complete_support_single_connection(self):
        for model in ("xrosmini", "dcomplete"):
            request = BattleRequest(model=model, port="COM9", fighter="Gekomon")
            with (
                patch("web_app.resolve_port", return_value="COM9"),
                patch("web_app.manager.start", new_callable=AsyncMock) as start,
            ):
                response = await battle(request)
            self.assertIn("--batalla-ponderada", start.await_args.args[0])
            self.assertEqual(response["model"], model)

    async def test_pen20_supports_native_mask_battle(self):
        request = BattleRequest(model="pen20", port="COM9", fighter="Gekomon")

        with (
            patch("web_app.resolve_port", return_value="COM9"),
            patch("web_app.manager.start", new_callable=AsyncMock) as start,
        ):
            response = await battle(request)

        args = start.await_args.args[0]
        self.assertIn("--pen20-proxy-id", args)
        self.assertEqual(response["model"], "pen20")
        self.assertEqual(response["protocol_fighter"]["level"], "Champion")

    async def test_color_family_supports_single_connection_battle(self):
        request = BattleRequest(model="dmc", port="COM9", fighter="Gekomon")

        with (
            patch("web_app.resolve_port", return_value="COM9"),
            patch("web_app.manager.start", new_callable=AsyncMock) as start,
        ):
            response = await battle(request)

        args = start.await_args.args[0]
        self.assertIn("dmc", args)
        self.assertIn("--dmc-proxy-id", args)
        self.assertIn("protocol_fighter", response)
        self.assertEqual(response["protocol_fighter"]["level"], "Champion")
        self.assertEqual(response["protocol_fighter"]["attribute"], "Virus")
        self.assertEqual(response["model"], "dmc")

    async def test_selected_burgamon_variant_is_passed_to_the_battle(self):
        request = BattleRequest(
            model="penx", port="COM9", fighter="Burgamon", fighter_variant=1,
        )

        with (
            patch("web_app.resolve_port", return_value="COM9"),
            patch("web_app.manager.start", new_callable=AsyncMock) as start,
        ):
            await battle(request)

        args = start.await_args.args[0]
        visual_index = args.index("--rival-visual") + 1
        variant_index = args.index("--rival-variante") + 1
        self.assertEqual(args[visual_index], "Burgamon")
        self.assertEqual(args[variant_index], "1")

    async def test_probability_endpoint_uses_weighted_engine(self):
        request = BattleProbabilityRequest(
            attackerLevel="Rookie",
            attackerAttribute="Vaccine",
            defenderLevel="Rookie",
            defenderAttribute="Virus",
        )

        result = await battle_probability(request)

        self.assertEqual(result["attackerWinProbability"], 0.65)

    async def test_probability_ui_reads_the_same_config_as_the_engine(self):
        config = await battle_probability_config()
        self.assertEqual(config["levelStep"], 0.10)
        self.assertEqual(config["levelDifferenceModifiers"]["3"], 0.40)
        self.assertEqual(config["attributeAdvantages"]["Vaccine"], "Virus")
        html = (Path(__file__).parent / "web" / "index.html").read_text(encoding="utf-8")
        javascript = (Path(__file__).parent / "web" / "app.js").read_text(encoding="utf-8")
        self.assertIn('data-panel="probability"', html)
        self.assertIn('/api/battle-probability/config', javascript)


if __name__ == "__main__":
    unittest.main()
