import unittest

from reference_book import (
    BOOK_PATH,
    find_profiles,
    image_path,
    load_reference_book,
    normalize_name,
    reference_names,
    reference_status,
)


@unittest.skipUnless(BOOK_PATH.is_file(), "El Reference Book externo no esta disponible")
class ReferenceBookTests(unittest.TestCase):
    def test_beelzebumon_blast_mode_alias_loads_english_reference_profile(self):
        profiles = find_profiles("Beelzebumon: Blast Mode")
        self.assertEqual(profiles[0]["name"], "Beelzemon: Blast Mode")
        self.assertTrue(profiles[0]["image_url"].endswith("beelzemon_blast_mode.jpg"))

    REPAIRED_PROFILES = (
        "Ebemon",
        "Aegisdramon",
        "Imperialdramon: Fighter Mode",
        "Imperialdramon: Paladin Mode",
        "Imperialdramon: Dragon Mode",
        "King Drasil_7D6",
        "UlforceVeedramon",
        "Alphamon: Ouryuken",
    )

    def test_alphamon_ouryuken_repairs_failed_source_row(self):
        profile = find_profiles("Alpha Ouryuken")[0]
        self.assertEqual(profile["level"], "Mega")
        self.assertEqual(profile["attribute"], "Vaccine")
        self.assertIn("Ultimate-Battle-Blade: Ouryuken", profile["attacks"])
        self.assertNotIn("ERROR", profile["description"])

    def test_all_failed_source_rows_are_repaired(self):
        for name in self.REPAIRED_PROFILES:
            with self.subTest(name=name):
                profile = find_profiles(name)[0]
                self.assertTrue(profile["level"])
                self.assertTrue(profile["type"])
                self.assertTrue(profile["attribute"])
                self.assertTrue(profile["attacks"])
                self.assertTrue(profile["description"])
                self.assertNotIn("ERROR:", profile["description"])

    def test_loaded_reference_has_no_scraping_error_profiles(self):
        error_profiles = [
            record["name"]
            for record in load_reference_book()["records"]
            if str(record["description"]).startswith("ERROR:")
        ]

        self.assertEqual(error_profiles, [])

    def test_numemon_contains_requested_fields_and_image(self):
        profiles = find_profiles("Numemon")

        self.assertEqual(len(profiles), 1)
        profile = profiles[0]
        self.assertEqual(profile["name"], "Numemon")
        self.assertEqual(profile["level"], "Champion")
        self.assertEqual(profile["type"], "Mollusk")
        self.assertEqual(profile["attribute"], "Virus")
        self.assertIn("Poop Toss", profile["attacks"])
        self.assertTrue(profile["description"])
        self.assertEqual(profile["image_url"], "/api/reference-image/numemon.jpg")
        self.assertTrue(image_path("numemon.jpg").is_file())

    def test_japanese_name_alias_finds_english_reference_entry(self):
        profiles = find_profiles("Omegamon")

        self.assertTrue(profiles)
        self.assertEqual(profiles[0]["name"], "Omnimon")

    def test_status_reports_loaded_rows(self):
        status = reference_status()

        self.assertTrue(status["available"])
        self.assertGreater(status["records"], 1_400)

    def test_selector_includes_gekomon(self):
        entries = reference_names()

        gekomon = next(entry for entry in entries if entry["name"] == "Gekomon")
        self.assertEqual(gekomon["level"], "Champion")
        self.assertEqual(gekomon["image_url"], "/api/reference-image/gekomon.jpg")

    def test_selector_preserves_both_burgamon_variants(self):
        variants = [entry for entry in reference_names() if entry["name"] == "Burgamon"]

        self.assertEqual([entry["level"] for entry in variants], ["Champion", "Rookie"])
        self.assertEqual([entry["variant_index"] for entry in variants], [0, 1])
        self.assertNotEqual(variants[0]["selector_label"], variants[1]["selector_label"])

    def test_image_path_rejects_directory_traversal(self):
        self.assertIsNone(image_path("../numemon.jpg"))


class ReferenceNameTests(unittest.TestCase):
    def test_normalizes_x_antibody_spelling(self):
        self.assertEqual(normalize_name("Agumon (X-Antibody)"), "agumonx")


if __name__ == "__main__":
    unittest.main()
