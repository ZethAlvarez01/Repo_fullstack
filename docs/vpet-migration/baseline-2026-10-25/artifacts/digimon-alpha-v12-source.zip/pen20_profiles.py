"""Seleccion de mascaras nativas para Pendulum Ver.20th."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from dmc_profiles import normalize_level


CATALOG_PATH = Path(__file__).with_name("data") / "pen20_battle_profiles.json"


def load_pen20_profiles(path: Path = CATALOG_PATH) -> list[dict]:
    return json.loads(path.read_text(encoding="utf-8"))["profiles"]


def choose_pen20_proxy(level: str, attribute: str, identity: str = "", path: Path = CATALOG_PATH) -> dict:
    wanted_level = normalize_level(level)
    wanted_attribute = str(attribute).strip().casefold()
    eligible = [item for item in load_pen20_profiles(path) if item["battle_eligible"]]
    matches = [item for item in eligible if item["level"] == wanted_level and item["attribute"].casefold() == wanted_attribute]
    if not matches:
        matches = [item for item in eligible if item["level"] == wanted_level]
    if not matches:
        raise ValueError(f"No hay un perfil Pendulum 20th para nivel {level!r}.")
    ordered = sorted(matches, key=lambda item: (item["index"], item["name"]))
    digest = hashlib.sha256(str(identity).strip().casefold().encode("utf-8")).digest()
    return ordered[int.from_bytes(digest[:4], "big") % len(ordered)]
