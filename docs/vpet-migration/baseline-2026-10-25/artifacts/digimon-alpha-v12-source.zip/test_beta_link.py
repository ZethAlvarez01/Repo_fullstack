import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory

from beta_link import (
    PERFILES,
    RESULTADOS_VERIFICADOS,
    analizar_intercambio,
    batalla_ponderada,
    crear_comando_pen20,
    extraer_consulta_alpha,
    main,
    resultado_pen20,
    resultado_dmc,
    resultado_decision_alpha,
    resultado_xrosmini,
    resolver_rival_detectado,
)
from catalogo import identificar
from unittest.mock import patch


class IntercambioTests(unittest.TestCase):
    def test_firmware_color_usa_digiroms_publicados_completos(self):
        firmware = (
            Path(__file__).parent
            / "firmware"
            / "digimon_alpha_dmcomm"
            / "digimon_alpha_dmcomm.ino"
        ).read_text(encoding="utf-8")

        self.assertIn("0x001E, 0x0003, 0x93AD", firmware)
        self.assertIn("0x00B4, 0x0003, 0x9452", firmware)
        self.assertIn("0x0014, 0x0003, 0x8BDE", firmware)
        self.assertIn("0x0003, 0x0000, 0x0000, 0x0000, 0x0000, 0x938A", firmware)
        self.assertIn("0x0003, 0x0006, 0x0000, 0x0000, 0x0000, 0x9390", firmware)
        self.assertNotIn("0x0003, 0x0011, 0x0000, 0x0000, 0x0000, 0x939B", firmware)
        self.assertNotIn("web_wins_ ? 0x00FF", firmware)
        self.assertIn("custom_profile_", firmware)
        self.assertIn("parseHexWord", firmware)

    def test_color_proxy_is_sent_before_contact_without_weighted_decision(self):
        class PuertoFalso:
            instancia = None

            def __init__(self, *args, **kwargs):
                self.buffer = bytearray()
                self.escritos = []
                self.baudrate = kwargs.get("baudrate", 9600)
                PuertoFalso.instancia = self

            def __enter__(self): return self
            def __exit__(self, *args): pass
            @property
            def in_waiting(self): return len(self.buffer)
            def reset_input_buffer(self): self.buffer.clear()
            def flush(self): pass
            def read(self, cantidad):
                datos = self.buffer[:cantidad]
                del self.buffer[:cantidad]
                return bytes(datos)
            def write(self, datos):
                self.escritos.append(datos)
                if datos.startswith(b"A4:"):
                    self.buffer.extend(
                        b"alpha:switch-baud:115200\r\n"
                        b"alpha:armed:family-battle-v3:4\r\n"
                        b"r:47444C4300000000000A0028000193BA "
                        b"s:47444C4300010002001100B400039452 "
                        b"r:47444C430002000F0000000000009398 "
                        b"s:47444C4300030000000000000000938A t\r\n"
                        b"alpha:done:default-mode\r\n"
                    )

        with TemporaryDirectory() as temporal:
            with (
                patch("beta_link.serial.Serial", PuertoFalso),
                patch("beta_link.time.sleep"),
                patch("beta_link.resolve_battle") as resolver,
            ):
                registro = Path(temporal) / "capturas.jsonl"
                salida = StringIO()
                with redirect_stdout(salida):
                    resultado = batalla_ponderada(
                        "COM9", 30, "dmc", registro, "Magnamon X", 0, 0,
                        "dmc-03-17",
                    )

                captura = __import__("json").loads(registro.read_text(encoding="utf-8"))

        self.assertEqual(resultado, 0)
        resolver.assert_not_called()
        self.assertEqual(
            PuertoFalso.instancia.escritos,
            [b"A4:0002:0011:00B4:0003\n"],
        )
        self.assertEqual(captura["rival_visual"], "Magnamon (X Antibody)")
        self.assertEqual(captura["rival_protocolo"], "Bancho Leomon")
        self.assertEqual(captura["resultado_vpet"], "pierde")
        self.assertTrue(captura["resultado_confirmado"])
        self.assertNotIn("probabilidad_rival", captura)

    def test_consulta_color_espera_el_bloque_serial_completo(self):
        parcial = "alpha:armed:family-battle-v2:4\nalpha:q:47444C4300000000000A0028"
        completa = parcial + "000193BA\n"

        self.assertIsNone(extraer_consulta_alpha(parcial, "dmc"))
        self.assertEqual(
            extraer_consulta_alpha(completa, "dmc"),
            "47444C4300000000000A0028000193BA",
        )
        self.assertEqual(extraer_consulta_alpha("alpha:q:0000000A\n", "dmc"), "0000000A")

    def test_consulta_dmx_responde_tras_dos_paquetes(self):
        self.assertIsNone(extraer_consulta_alpha("alpha:q:4B0E\n", "dmx"))
        self.assertEqual(extraer_consulta_alpha("alpha:q:4B0E-802E\n", "dmx"), "4B0E-802E")

    def test_batalla_ponderada_usa_el_rival_leido_del_com(self):
        calculo = {
            "attackerWinProbability": 0.10,
            "effectiveAttackerWinProbability": 0.12,
            "noiseModifier": 0.02,
            "winner": "defender",
            "breakdown": {
                "levelProbability": 0.30,
                "attributeModifier": -0.15,
                "xAntibodyModifier": -0.05,
                "statsModifier": 0,
            },
        }
        class PuertoFalso:
            instancia = None

            def __init__(self, *args, **kwargs):
                self.buffer = bytearray()
                self.escritos = []
                PuertoFalso.instancia = self

            def __enter__(self): return self
            def __exit__(self, *args): pass
            @property
            def in_waiting(self): return len(self.buffer)
            def reset_input_buffer(self): self.buffer.clear()
            def flush(self): pass
            def read(self, cantidad):
                datos = self.buffer[:cantidad]
                del self.buffer[:cantidad]
                return bytes(datos)
            def write(self, datos):
                self.escritos.append(datos)
                if datos == b"A1\n":
                    self.buffer.extend(b"alpha:armed:family-battle-v3:1\r\nalpha:q:1269\r\n")
                elif datos in (b"W\n", b"P\n"):
                    self.buffer.extend(
                        b"alpha:decision:vpet\r\ns:0159 r:1269 s:4379 r:4709 "
                        b"s:0009 r:5409 s:C009 r:31F9 \r\nalpha:done:default-mode\r\n"
                    )

        with TemporaryDirectory() as temporal:
            with (
                patch("beta_link.serial.Serial", PuertoFalso),
                patch("beta_link.time.sleep"),
                patch("beta_link.resolve_battle", return_value=calculo) as resolver,
            ):
                registro = Path(temporal) / "capturas.jsonl"
                salida = StringIO()
                with redirect_stdout(salida):
                    resultado = batalla_ponderada("COM9", 30, "penx", registro, "Burgamon", 1, 0)

        self.assertEqual(resultado, 0)
        self.assertEqual(salida.getvalue().count("Listo para la batalla. Conecta tu V-Pet."), 1)
        parametros = resolver.call_args.args[0]
        self.assertEqual(parametros["defenderLevel"], "Ultimate")
        self.assertTrue(parametros["defenderHasXAntibody"])
        self.assertEqual(PuertoFalso.instancia.escritos, [b"A1\n", b"P\n"])

    def test_intercambio_acepta_orden_receive_first_del_firmware_v2(self):
        linea = "r:1269 s:0159 r:4709 s:4379 r:5409 s:0009 r:31F9 s:C009"
        self.assertTrue(analizar_intercambio(linea, 4)["completo"])

    def test_complete_perfil_clasico_sin_desbloqueos(self):
        self.assertEqual(PERFILES["dcomplete"]["codigo"], "V1-FC03-FD02")
        self.assertEqual(PERFILES["dcomplete"]["paquetes"], 2)
        # Ejemplo sintetico: FB04 es el primer paquete observado por el usuario.
        self.assertTrue(analizar_intercambio("s:FC03 r:FB04 s:FD02 r:FE01", 2)["completo"])
        self.assertFalse(analizar_intercambio("s:FC03 r:FB04 s:FD02 t", 2)["completo"])

    def test_complete_no_asigna_especie_de_otro_modelo(self):
        with patch("catalogo_complete.candidatos", return_value=[]):
            datos = identificar("dcomplete", "FB04-FE01")[0]
        self.assertNotEqual(datos["estado"], "identificado")
        self.assertEqual(datos["nombres"], [])
        self.assertIn("slot=4", datos["nota"])
        self.assertIn("no cumple", identificar("dcomplete", "FB04-0000")[0]["nota"])

    def test_complete_cli_acepta_perfil_sin_catalogo(self):
        with patch("sys.argv", ["beta_link.py", "--intercambiar", "--modelo", "dcomplete", "--puerto", "COM5"]), patch("beta_link.intercambiar_vpet", return_value=0) as intercambio:
            self.assertEqual(main(), 0)
            self.assertEqual(intercambio.call_args.args[2], "dcomplete")

    def test_batalla_dmx_completa(self):
        linea = (
            "s:800E r:4B0E s:218E r:802E s:483E r:549E "
            "s:142E r:397E s:010E r:2D2E s:800E r:41FE"
        )
        resultado = analizar_intercambio(linea, 6)
        self.assertTrue(resultado["completo"])
        self.assertEqual(len(resultado["recibidos"]), 6)
        self.assertNotIn("218E", resultado["recibidos"])

    def test_batalla_penx_completa(self):
        linea = "s:0159 r:1269 s:4379 r:1239 s:0009 r:0049 s:C009 r:0009"
        resultado = analizar_intercambio(linea, 4)
        self.assertTrue(resultado["completo"])
        self.assertEqual(resultado["recibidos"], ["1269", "1239", "0049", "0009"])
        self.assertEqual(resultado["enviados"], ["0159", "4379", "0009", "C009"])

    def test_dmc_decodifica_resultado_del_segundo_bloque(self):
        gana = analizar_intercambio(
            "r:47444C4300000000000A0028000193BA s:47444C430001000200030019000193A7 "
            "r:47444C430002000F0001000000009399 s:47444C4300030000000000000000938A",
            2, 32,
        )
        pierde = analizar_intercambio(
            "r:47444C4300000000000A0028000193BA s:47444C4300010001001000AA00019444 "
            "r:47444C430002000F0000000000009398 s:47444C4300030000000000000000938A",
            2, 32,
        )
        self.assertEqual(resultado_dmc(gana), "gana")
        self.assertEqual(resultado_dmc(pierde), "pierde")

    def test_dmx_oculto_usa_etapa_atributo_y_x_para_probabilidad(self):
        with patch("beta_link.resolve_battle", return_value={"winner": "defender"}) as resolver:
            resolver_rival_detectado("dmx", "4A0E-802E", [{
                "name": "Koromon", "level": "In-Training II", "attribute": "Free", "antibody": False,
            }], 0, 0)
        params = resolver.call_args.args[0]
        self.assertEqual(params["defenderLevel"], "Mega")
        self.assertEqual(params["defenderAttribute"], "Virus")
        self.assertTrue(params["defenderHasXAntibody"])

    def test_firmware_dmx_envia_hits_cuando_gana_la_web(self):
        firmware = (
            Path(__file__).parent / "firmware" / "digimon_alpha_dmcomm" / "digimon_alpha_dmcomm.ino"
        ).read_text(encoding="utf-8")
        self.assertIn("bool proxy_hits = web_wins_", firmware)
        self.assertIn("packet = web_wins_ ? 0x3C2E : 0x022E", firmware)
        self.assertIn("packet = web_wins_ ? 0x2FFE : 0x001E", firmware)
        self.assertIn("digimon-alpha-family-battle-v12", firmware)
        self.assertIn("kAlphaDecisionTimeoutMillis = 1000", firmware)

    def test_accel_usa_batalla_x_de_tres_pines(self):
        self.assertEqual(PERFILES["accel"]["codigo"], "X1-0159-4379-0009-C009")
        self.assertEqual(PERFILES["accel"]["paquetes"], 4)

    def test_mini_es_una_opcion_separada_con_el_mismo_protocolo_x(self):
        self.assertEqual(PERFILES["mini"]["codigo"], PERFILES["accel"]["codigo"])
        self.assertEqual(PERFILES["mini"]["paquetes"], 4)

    def test_xros_mini_usa_su_protocolo_y(self):
        self.assertEqual(PERFILES["xrosmini"]["codigo"], "Y2-1017-0057-0007-@C^1^F7")
        self.assertEqual(PERFILES["xrosmini"]["paquetes"], 4)

    def test_xros_mini_lee_el_resultado_real_del_hitme_fisico(self):
        gana = analizar_intercambio(
            "r:2017 s:1017 r:0087 s:0057 r:2657 s:0007 r:C067 s:F197", 4,
        )
        pierde = analizar_intercambio(
            "r:2017 s:1017 r:0097 s:0057 r:1567 s:0007 r:A1D7 s:7027", 4,
        )
        self.assertEqual(resultado_xrosmini(gana), "gana")
        self.assertEqual(resultado_xrosmini(pierde), "pierde")

    def test_resultado_alpha_respeta_timeout_y_decision_real(self):
        self.assertEqual(resultado_decision_alpha("alpha:decision:web", "gana"), "pierde")
        self.assertEqual(resultado_decision_alpha("alpha:decision:vpet", "pierde"), "gana")
        self.assertEqual(resultado_decision_alpha("alpha:decision:timeout-vpet", "pierde"), "gana")
        self.assertEqual(resultado_decision_alpha("sin marcador", "pierde"), "pierde")

    def test_firmware_xros_usa_perfiles_de_poder_segun_la_tirada(self):
        firmware = (
            Path(__file__).parent / "firmware" / "digimon_alpha_dmcomm" / "digimon_alpha_dmcomm.ino"
        ).read_text(encoding="utf-8")
        self.assertIn("0x1017, 0x0057, 0x0007", firmware)
        self.assertIn("0x1107, 0x0747, 0x3FF7", firmware)
        self.assertIn("web_wins_ ? strong_packets", firmware)

    def test_pen20_decodifica_ganador_del_paquete_final(self):
        intercambio = analizar_intercambio(
            " ".join([
                "r:008E s:000E", "r:3A2E s:02E0", "r:064E s:000E", "r:04FE s:000E",
                "r:2E0E s:280E", "r:000E s:000E", "r:000E s:000E", "r:000E s:000E",
                "r:000E s:000E", "r:D0FE s:0F0E",
            ]),
            10,
        )
        self.assertTrue(intercambio["completo"])
        self.assertEqual(resultado_pen20(intercambio), "gana")

    def test_pen20_desempata_impactos_con_el_nivel_de_ataque(self):
        intercambio = analizar_intercambio(
            " ".join([
                "r:C00E s:400E", "r:3A2E s:02E0", "r:064E s:000E", "r:04FE s:000E",
                "r:2E0E s:280E", "r:000E s:000E", "r:000E s:000E", "r:000E s:000E",
                "r:000E s:000E", "r:BA5E s:95AE",
            ]),
            10,
        )
        self.assertEqual(resultado_pen20(intercambio), "gana")

    def test_comando_pen20_incluye_una_sacudida_virtual(self):
        perfil = {"index": 151, "base_power": 214, "attribute_word": 3}

        comando, ataque = crear_comando_pen20("A0", perfil, patron_ataque=11)

        self.assertEqual(ataque, 11)
        self.assertEqual(comando, "A0:B000:0097:00D6:0003")

    def test_penx_tiene_resultados_documentados_para_ambos_lados(self):
        resultados = RESULTADOS_VERIFICADOS["penx"]

        self.assertEqual(resultados["rival_protocolo"], "Kuwagamon X")
        self.assertEqual(resultados["vpet_gana"], "X1-0159-4379-0009-C009")
        self.assertEqual(resultados["vpet_pierde"], "X1-0159-4379-0009-C1F9")

    def test_accel_valida_trama_sin_inventar_identidad(self):
        datos = identificar("accel", "0159-4379-0009-C009")[0]
        self.assertEqual(datos["estado"], "no_identificable")
        self.assertIn("mapa verificado", datos["nota"])

    def test_repeticiones_no_forman_batalla_completa(self):
        linea = "s:0159 r:1269 t s:0159 r:1269 t s:0159 r:1269 t s:0159 r:1269 t"
        # Aunque sumen cuatro respuestas, los timeouts separan los intentos.
        self.assertFalse(analizar_intercambio(linea, 4)["completo"])

    def test_timeout_parcial(self):
        self.assertFalse(analizar_intercambio("s:0159 r:1269 s:4379 t", 4)["completo"])

    def test_error_al_recibir_no_es_completo(self):
        linea = "s:0159 r:1269 s:4379 r:1239 s:0009 r:0049 s:C009 r:0009 t:-1"
        self.assertFalse(analizar_intercambio(linea, 4)["completo"])


if __name__ == "__main__":
    unittest.main()
