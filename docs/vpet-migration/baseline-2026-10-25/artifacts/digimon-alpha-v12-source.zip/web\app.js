const $ = (selector) => document.querySelector(selector);
const BATTLE_REVEAL_DELAY_MS = 10000;
const state = {
  status: null,
  socket: null,
  profiles: [],
  referenceEntries: [],
  selectedFighter: null,
  displayedProfile: null,
  lastDetected: null,
  battleActive: false,
  baseProbability: null,
  effectiveProbability: null,
  battleRevealTimer: null,
  pendingOutcome: null,
  probabilityConfig: null,
  playerLocation: null,
  playerLocationError: null,
  playerLocationWatchId: null,
};

const PLAYER_LOCATION_OPTIONS = {
  enableHighAccuracy: true,
  maximumAge: 1000,
  timeout: 10000,
};

function renderPlayerLocation(location) {
  if (!document.getElementById("playerLocationStatus")) return;
  $("#playerLatitude").textContent = location.latitude.toFixed(6);
  $("#playerLongitude").textContent = location.longitude.toFixed(6);
  $("#playerAccuracy").textContent = `±${Math.round(location.accuracy)} m`;
  $("#playerLocationUpdated").textContent = `Actualizado ${new Date(location.timestamp).toLocaleTimeString("es-MX")}`;
  $("#playerLocationStatus").textContent = "EN VIVO";
  $("#playerLocationStatus").className = "live";
  $("#playerLocationButton").textContent = "Detener GPS";
  $("#playerLocationButton").classList.add("active");
}

function renderPlayerLocationError(error) {
  if (!document.getElementById("playerLocationStatus")) return;
  const messages = {
    1: "Permiso de ubicación denegado",
    2: "Ubicación no disponible",
    3: "El GPS tardó demasiado",
  };
  $("#playerLocationStatus").textContent = "ERROR";
  $("#playerLocationStatus").className = "error";
  $("#playerLocationUpdated").textContent = messages[error.code] || error.message;
}

function stopPlayerLocationTracking() {
  if (state.playerLocationWatchId === null) return;
  navigator.geolocation.clearWatch(state.playerLocationWatchId);
  state.playerLocationWatchId = null;
  if (document.getElementById("playerLocationStatus")) {
    $("#playerLocationStatus").textContent = "DETENIDO";
    $("#playerLocationStatus").className = "";
    $("#playerLocationButton").textContent = "Activar GPS";
    $("#playerLocationButton").classList.remove("active");
  }
}

function startPlayerLocationTracking({ onUpdate, onError, options = {} } = {}) {
  if (!window.isSecureContext) {
    const error = new Error("El GPS requiere HTTPS. Abre la direccion segura de Digimon Alpha.");
    state.playerLocationError = { code: 0, message: error.message };
    if (onError) onError(state.playerLocationError);
    throw error;
  }
  if (!navigator.geolocation) {
    const error = new Error("Este navegador no admite geolocalizacion.");
    state.playerLocationError = { code: 0, message: error.message };
    if (onError) onError(state.playerLocationError);
    throw error;
  }

  stopPlayerLocationTracking();
  state.playerLocationError = null;
  state.playerLocationWatchId = navigator.geolocation.watchPosition(
    position => {
      const { coords } = position;
      const location = {
        latitude: coords.latitude,
        longitude: coords.longitude,
        accuracy: coords.accuracy,
        altitude: coords.altitude,
        altitudeAccuracy: coords.altitudeAccuracy,
        heading: coords.heading,
        speed: coords.speed,
        timestamp: position.timestamp,
      };
      state.playerLocation = location;
      state.playerLocationError = null;
      renderPlayerLocation(location);
      window.dispatchEvent(new CustomEvent("playerlocationchange", { detail: location }));
      if (onUpdate) onUpdate(location);
    },
    geolocationError => {
      const error = {
        code: geolocationError.code,
        message: geolocationError.message,
      };
      state.playerLocationError = error;
      renderPlayerLocationError(error);
      window.dispatchEvent(new CustomEvent("playerlocationerror", { detail: error }));
      if (onError) onError(error);
    },
    { ...PLAYER_LOCATION_OPTIONS, ...options },
  );

  if (document.getElementById("playerLocationStatus")) {
    $("#playerLocationStatus").textContent = "BUSCANDO";
    $("#playerLocationStatus").className = "live";
    $("#playerLocationUpdated").textContent = "Esperando coordenadas…";
    $("#playerLocationButton").textContent = "Detener GPS";
    $("#playerLocationButton").classList.add("active");
  }

  return stopPlayerLocationTracking;
}

function togglePlayerLocationTracking() {
  if (state.playerLocationWatchId !== null) {
    stopPlayerLocationTracking();
    return;
  }
  try {
    startPlayerLocationTracking();
  } catch (error) {
    renderPlayerLocationError(state.playerLocationError || { code: 0, message: error.message });
  }
}

window.DigimonAlphaLocation = Object.freeze({
  start: startPlayerLocationTracking,
  stop: stopPlayerLocationTracking,
  getCurrent: () => state.playerLocation,
  getError: () => state.playerLocationError,
});

function toast(message) {
  const element = $("#toast");
  element.textContent = message;
  element.classList.add("show");
  clearTimeout(element.timer);
  element.timer = setTimeout(() => element.classList.remove("show"), 3500);
}

async function api(path, options = {}) {
  const response = await fetch(path, { headers: { "Content-Type": "application/json" }, ...options });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || `Error ${response.status}`);
  return data;
}

function selectedPort() { return $("#portSelect").value || null; }

function setUsbBetaLinkConnected(connected, detail = {}) {
  const select = $("#portSelect");
  let option = select.querySelector('option[value="webusb"]');
  if (connected && !option) {
    option = document.createElement("option");
    option.value = "webusb";
    option.textContent = "USB del celular · Beta Link";
    select.appendChild(option);
  }
  if (!connected && option) option.remove();
  if (connected) select.value = "webusb";
  $("#usbBetaLinkButton").textContent = connected ? "Desconectar Beta Link USB" : "Conectar Beta Link USB";
  $("#usbBetaLinkButton").classList.toggle("active", connected);
  if (connected) {
    $("#deviceStatus").textContent = "USB MÓVIL CONECTADO";
    $("#deviceDetail").textContent = `${detail.label || "CH340"} · 9600 baudios`;
    $("#statusDot").classList.add("ok");
  }
}

async function toggleUsbBetaLink() {
  try {
    if (!window.BetaLinkUsb) throw new Error("El controlador WebUSB todavía está cargando. Intenta otra vez.");
    if (window.BetaLinkUsb.isConnected()) await window.BetaLinkUsb.disconnect();
    else await window.BetaLinkUsb.connect();
  } catch (error) {
    $("#deviceStatus").textContent = "USB NO DISPONIBLE";
    $("#deviceDetail").textContent = error.message;
    toast(error.message);
  }
}

function setRunning(running, operation = null) {
  $("#battleButton").disabled = running;
  $("#listenButton").disabled = running;
  $("#probeButton").disabled = running;
  $("#cancelButton").disabled = !running;
  $("#statusDot").className = `dot ${running ? "busy" : ""}`;
  $("#statusText").textContent = running ? `${operation?.kind === "battle" ? "Batalla" : "Escucha"} activa` : "Listo para conectar";
}

function normalizeCombatantName(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/gi, " ")
    .trim()
    .toLocaleLowerCase("es")
    .replace(/\bbeelzebumon\b/g, "beelzemon")
    .replace(/\bx antibody\b/g, "x")
    .replace(/\s+/g, "");
}

function clearBattlePresentation() {
  clearTimeout(state.battleRevealTimer);
  state.battleRevealTimer = null;
  state.pendingOutcome = null;
  $("#battleMatch").classList.remove("battle-animating");
  document.querySelectorAll(".combatant.winner").forEach(card => card.classList.remove("winner"));
}

function highlightWinner(winner) {
  const target = normalizeCombatantName(winner);
  const fighter = normalizeCombatantName(state.selectedFighter?.name);
  const vpet = normalizeCombatantName($("#vpetName").textContent);
  if (target && fighter && (target === fighter || target.includes(fighter) || fighter.includes(target))) {
    $(".fighter-card").classList.add("winner");
  } else if (target && vpet && (target === vpet || target.includes(vpet) || vpet.includes(target))) {
    $(".vpet-card").classList.add("winner");
  }
}

function revealBattleOutcome() {
  const outcome = state.pendingOutcome;
  if (!outcome) return;
  state.pendingOutcome = null;
  state.battleRevealTimer = null;
  $("#battleMatch").classList.remove("battle-animating");
  $("#battleStage").textContent = "FINALIZADA";
  $("#battleResult").textContent = outcome.message;
  $("#battleResult").classList.remove("hidden");
  if (outcome.winner) highlightWinner(outcome.winner);
}

function queueBattleOutcome(message, winner = null) {
  clearTimeout(state.battleRevealTimer);
  state.pendingOutcome = { message, winner };
  $("#battleResult").classList.add("hidden");
  $("#battleStage").textContent = "BATALLA EN CURSO";
  $("#battleMatch").classList.add("battle-animating");
  state.battleRevealTimer = setTimeout(revealBattleOutcome, BATTLE_REVEAL_DELAY_MS);
}

function appendTerminal(text, detect = true) {
  const terminal = $("#terminal");
  if (terminal.textContent === "Esperando una operación…") terminal.textContent = "";
  terminal.textContent += `${text}\n`;
  terminal.scrollTop = terminal.scrollHeight;

  const identified = String(text).match(/^Digimon:\s*(.+?)\s*$/i);
  const detected = identified?.[1]?.trim();
  if (detect && detected && detected.toLocaleLowerCase("es") !== "no identificado" && detected !== state.lastDetected) {
    state.lastDetected = detected;
    $("#vpetName").textContent = detected;
    $("#battleStage").textContent = "RIVAL DETECTADO";
    loadVpetProfile(detected);
    if (!state.battleActive) showDigimon(detected, true);
  }

  const vpetData = String(text).match(/^Datos V-Pet:\s*(.+?)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*$/i);
  if (vpetData) {
    $("#vpetLevel").textContent = vpetData[1].trim();
    $("#vpetAttribute").textContent = vpetData[2].trim();
    $("#vpetType").textContent = vpetData[3].trim();
  }

  const winner = String(text).match(/^Ganador:\s*(.+?)\s*$/i)?.[1]?.trim();
  if (winner) {
    queueBattleOutcome(`GANADOR: ${winner}`, winner);
  }

  if (String(text).startsWith("Batalla completada. El resultado real")) {
    queueBattleOutcome("RESULTADO DETERMINADO POR EL V-PET COLOR");
  }

  const baseProbability = String(text).match(/^Probabilidad calculada del rival web:\s*(.+?)\s*$/i)?.[1]?.trim();
  if (baseProbability) state.baseProbability = baseProbability;
  const effectiveProbability = String(text).match(/^Probabilidad efectiva(?: con ruido)? del rival web:\s*(.+?)\s*$/i)?.[1]?.trim();
  if (effectiveProbability) state.effectiveProbability = effectiveProbability;
  if (baseProbability || effectiveProbability) {
    $("#battleResult").textContent = [
      state.baseProbability && `PROBABILIDAD BASE DEL RIVAL WEB: ${state.baseProbability}`,
      state.effectiveProbability && `EFECTIVA: ${state.effectiveProbability}`,
    ].filter(Boolean).join(" · ");
    $("#battleResult").classList.remove("hidden");
  }
  if (
    String(text).startsWith("Resultado enviado dentro de la misma conexion.")
    || String(text).startsWith("Perfil ponderado enviado;")
  ) $("#battleStage").textContent = "BATALLA EN CURSO";
}

function connectEvents() {
  const protocol = location.protocol === "https:" ? "wss" : "ws";
  const socket = new WebSocket(`${protocol}://${location.host}/api/events`);
  socket.binaryType = "arraybuffer";
  state.socket = socket;
  window.DigimonAlphaEventsSocket = socket;
  socket.onmessage = ({ data }) => {
    if (typeof data !== "string") {
      window.dispatchEvent(new CustomEvent("betalinkusb:serverdata", { detail: { data } }));
      return;
    }
    const event = JSON.parse(data);
    if (event.type === "bridge" && event.status === "ready") {
      window.dispatchEvent(new CustomEvent("betalinkusb:bridge-ready"));
    } else if (event.type === "usb-error") {
      window.dispatchEvent(new CustomEvent("betalinkusb:bridge-error", { detail: event }));
    } else if (event.type === "snapshot") {
      setRunning(event.running, event.operation);
      event.recent.forEach(item => item.type === "line" && appendTerminal(item.text, false));
    } else if (event.type === "line") {
      appendTerminal(event.text);
    } else if (event.type === "operation") {
      const running = event.status === "started";
      setRunning(running, event);
      if (event.kind === "battle" || state.battleActive) state.battleActive = running;
      if (event.status === "started" && event.kind === "battle") $("#battleStage").textContent = "DETECTANDO V-PET";
      if (event.status === "finished") {
        appendTerminal(`— operación terminada (código ${event.exit_code}) —`);
        loadCaptures();
      }
      if (event.status === "cancelled") appendTerminal("— operación cancelada —");
    }
  };
  socket.onclose = () => {
    if (window.DigimonAlphaEventsSocket === socket) window.DigimonAlphaEventsSocket = null;
    setTimeout(connectEvents, 1500);
  };
}

async function loadStatus() {
  const data = await api("/api/status");
  state.status = data;
  const ports = $("#portSelect");
  ports.innerHTML = '<option value="">Detección automática</option>' + data.ports.map(port =>
    `<option value="${port.device}">${port.device} · ${port.description}${port.is_beta_link ? " · Beta Link" : ""}</option>`
  ).join("");
  const models = $("#modelSelect");
  const previousModel = models.value || localStorage.getItem("digimon-alpha:model") || "penx";
  models.innerHTML = data.models.map(model => {
    const mode = model.result_mode === "native_proxy"
      ? " · perfil nativo Color"
      : model.result_mode === "experimental"
        ? " · batalla experimental"
        : model.real_battle ? " · batalla variable" : model.experimental ? " · experimental" : "";
    return `<option value="${model.key}">${model.name}${mode}</option>`;
  }).join("");
  models.value = data.models.some(model => model.key === previousModel) ? previousModel : "penx";
  setRunning(data.running, data.operation);
}

async function probe() {
  $("#deviceStatus").textContent = "CONSULTANDO…";
  try {
    const data = await api("/api/probe", { method: "POST", body: JSON.stringify({ port: selectedPort() }) });
    $("#deviceStatus").textContent = data.confirmed ? "DMCOMM ACTIVO" : "RESPUESTA DESCONOCIDA";
    $("#deviceDetail").textContent = `${data.port} · ${data.response || "sin información"}`;
    $("#statusDot").classList.toggle("ok", data.confirmed);
  } catch (error) {
    $("#deviceStatus").textContent = "NO DISPONIBLE";
    $("#deviceDetail").textContent = error.message;
    toast(error.message);
  }
}

async function startBattle() {
  const model = $("#modelSelect").value;
  localStorage.setItem("digimon-alpha:model", model);
  if (!state.selectedFighter) {
    toast("Elige primero un Digimon del Reference Book.");
    $("#fighterInput").focus();
    return;
  }
  const selectedModel = state.status?.models?.find(item => item.key === model);
  if (!selectedModel?.real_battle) {
    toast("Este modelo todavía no admite una batalla Alpha de una sola conexión.");
    return;
  }
  if (!selectedModel?.real_battle) {
    toast("Por ahora la detección automática está disponible para PenX.");
    return;
  }
  const body = {
    model,
    fighter: state.selectedFighter.name,
    fighter_variant: state.selectedFighter.variant_index || 0,
    fighter_stat_modifier: 0,
    port: selectedPort(),
    wait: 100,
  };
  try {
    clearBattlePresentation();
    state.lastDetected = null;
    state.baseProbability = null;
    state.effectiveProbability = null;
    $("#vpetName").textContent = "Esperando lectura del COM";
    $("#vpetLevel").textContent = "—";
    $("#vpetAttribute").textContent = "—";
    $("#vpetType").textContent = "—";
    $("#vpetAttacks").textContent = "—";
    $("#vpetImage").classList.add("hidden");
    $("#vpetImage").src = "";
    $("#vpetFallback").classList.remove("hidden");
    $("#vpetFallback").textContent = "?";
    $("#battleStage").textContent = "INICIANDO";
    $("#battleResult").classList.add("hidden");
    $("#terminal").textContent = "";
    const result = await api("/api/battle", { method: "POST", body: JSON.stringify(body) });
    if (result.protocol_fighter) {
      appendTerminal(
        `Máscara de protocolo: ${state.selectedFighter.name} → ${result.protocol_fighter.name} `
        + `(${result.protocol_fighter.level}, ${result.protocol_fighter.attribute}, poder ${result.protocol_fighter.base_power})`,
        false,
      );
    }
  } catch (error) { toast(error.message); }
}

async function startListen() {
  const signal = document.querySelector('input[name="signal"]:checked').value;
  try {
    $("#terminal").textContent = "";
    await api("/api/listen", { method: "POST", body: JSON.stringify({ signal_type: signal, port: selectedPort(), wait: Number($("#listenWait").value) }) });
  } catch (error) { toast(error.message); }
}

async function cancelOperation() {
  try { await api("/api/cancel", { method: "POST", body: "{}" }); }
  catch (error) { toast(error.message); }
}

function resetCombatant(prefix, name) {
  $(`#${prefix}Name`).textContent = name;
  $(`#${prefix}Level`).textContent = "—";
  $(`#${prefix}Attribute`).textContent = "—";
  $(`#${prefix}Type`).textContent = "—";
  $(`#${prefix}Attacks`).textContent = "—";
  const image = $(`#${prefix}Image`);
  image.classList.add("hidden");
  image.removeAttribute("src");
  image.alt = "";
  const fallback = $(`#${prefix}Fallback`);
  fallback.classList.remove("hidden");
  fallback.textContent = "?";
}

async function resetAll() {
  try {
    await api("/api/reset", { method: "POST", body: "{}" });
  } catch (_) {
    // La limpieza visual sigue siendo segura si la operacion ya termino.
  }

  clearBattlePresentation();
  stopPlayerLocationTracking();
  state.playerLocation = null;
  state.playerLocationError = null;
  state.profiles = [];
  state.selectedFighter = null;
  state.displayedProfile = null;
  state.lastDetected = null;
  state.battleActive = false;
  state.baseProbability = null;
  state.effectiveProbability = null;
  if (state.status) {
    state.status.running = false;
    state.status.operation = null;
  }

  setRunning(false);
  $("#statusDot").classList.remove("ok", "busy");
  $("#statusText").textContent = "Listo para conectar";
  $("#deviceStatus").textContent = "SIN COMPROBAR";
  $("#deviceDetail").textContent = "Selecciona un puerto y consulta el firmware.";
  $("#portSelect").value = "";
  $("#fighterInput").value = "";
  resetCombatant("fighter", "Elige un Digimon");
  resetCombatant("vpet", "Esperando rival");
  $("#battleStage").textContent = "PREPARANDO";
  $("#battleResult").textContent = "";
  $("#battleResult").classList.add("hidden");
  $("#terminal").textContent = "Esperando una operación…";
  $("#playerLatitude").textContent = "—";
  $("#playerLongitude").textContent = "—";
  $("#playerAccuracy").textContent = "—";
  $("#playerLocationStatus").textContent = "INACTIVO";
  $("#playerLocationStatus").className = "";
  $("#playerLocationUpdated").textContent = "Sin ubicación";
  $("#playerLocationButton").textContent = "Activar GPS";
  $("#playerLocationButton").classList.remove("active");

  $("#listenWait").value = "60";
  document.querySelector('input[name="signal"][value="V0"]').checked = true;
  $("#catalogQuery").value = "";
  $("#catalogModel").value = "";
  $("#catalogSummary").textContent = "";
  $("#catalogRows").innerHTML = "";
  $("#captureList").innerHTML = "";
  if (state.probabilityConfig) {
    $("#probAttackerLevel").value = "Rookie";
    $("#probDefenderLevel").value = "Rookie";
    $("#probAttackerAttribute").value = "Vaccine";
    $("#probDefenderAttribute").value = "Virus";
    $("#probAttackerX").checked = false;
    $("#probDefenderX").checked = false;
    updateProbability();
  }
  if ($("#digimonModal").open) $("#digimonModal").close();

  document.querySelector('[data-panel="battle"]').click();
  toast("Interfaz reiniciada.");
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"]/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[char]);
}

function percent(value, signed = false) {
  const amount = Math.round(Number(value || 0) * 100);
  return `${signed && amount > 0 ? "+" : ""}${amount}%`;
}

function matrixCellClass(value, neutral = 0.5) {
  return value > neutral ? "matrix-good" : value < neutral ? "matrix-bad" : "";
}

function renderProbabilityTables(config) {
  const levels = Object.entries(config.levelRanks);
  const nonCombatants = new Set(config.nonCombatantLevels || []);
  const clamp = value => Math.max(config.minimumProbability, Math.min(config.maximumProbability, value));
  const levelHead = levels.map(([name]) => `<th>${escapeHtml(name)}</th>`).join("");
  const levelRows = levels.map(([attacker, attackerRank]) => {
    const cells = levels.map(([defender, defenderRank]) => {
      const difference = attackerRank - defenderRank;
      const configured = config.levelDifferenceModifiers?.[Math.abs(difference)];
      const magnitude = configured ?? Math.abs(difference) * config.levelStep;
      let value = clamp(config.baseProbability + (difference >= 0 ? magnitude : -magnitude));
      if (nonCombatants.has(attacker) !== nonCombatants.has(defender)) {
        value = nonCombatants.has(attacker)
          ? config.nonCombatantWinProbability
          : 1 - config.nonCombatantWinProbability;
      }
      return `<td class="${matrixCellClass(value)}">${percent(value)}</td>`;
    }).join("");
    return `<tr><th>${escapeHtml(attacker)}</th>${cells}</tr>`;
  }).join("");
  $("#levelMatrix").innerHTML = `<table><thead><tr><th>WEB ↓ / V-PET →</th>${levelHead}</tr></thead><tbody>${levelRows}</tbody></table>`;

  const attributes = ["Vaccine", "Virus", "Data", "Free"];
  const modifier = (attacker, defender) => {
    if (attacker === "Free" || defender === "Free") return 0;
    if (config.attributeAdvantages[attacker] === defender) return config.attributeAdvantage;
    if (config.attributeAdvantages[defender] === attacker) return -config.attributeAdvantage;
    return 0;
  };
  const attributeRows = attributes.map(attacker => `<tr><th>${attacker}</th>${attributes.map(defender => {
    const value = modifier(attacker, defender);
    return `<td class="${matrixCellClass(value, 0)}">${percent(value, true)}</td>`;
  }).join("")}</tr>`).join("");
  $("#attributeMatrix").innerHTML = `<table><thead><tr><th>WEB ↓ / V-PET →</th>${attributes.map(value => `<th>${value}</th>`).join("")}</tr></thead><tbody>${attributeRows}</tbody></table>`;
}

async function updateProbability() {
  if (!state.probabilityConfig) return;
  try {
    const result = await api("/api/battle-probability", {
      method: "POST",
      body: JSON.stringify({
        attackerLevel: $("#probAttackerLevel").value,
        attackerAttribute: $("#probAttackerAttribute").value,
        attackerHasXAntibody: $("#probAttackerX").checked,
        attackerStatModifier: 0,
        defenderLevel: $("#probDefenderLevel").value,
        defenderAttribute: $("#probDefenderAttribute").value,
        defenderHasXAntibody: $("#probDefenderX").checked,
        defenderStatModifier: 0,
      }),
    });
    $("#probAttackerScore").textContent = percent(result.attackerWinProbability);
    $("#probDefenderScore").textContent = percent(result.defenderWinProbability);
    $("#probabilityFill").style.width = percent(result.attackerWinProbability);
    const breakdown = result.breakdown;
    $("#probabilityBreakdown").innerHTML = [
      ["Nivel", percent(breakdown.levelProbability)],
      ["Atributo", percent(breakdown.attributeModifier, true)],
      ["X-Antibody", percent(breakdown.xAntibodyModifier, true)],
      ["Estadísticas", percent(breakdown.statsModifier, true)],
    ].map(([label, value]) => `<span>${label}<b>${value}</b></span>`).join("");
  } catch (error) { toast(error.message); }
}

async function loadProbabilityPanel() {
  if (state.probabilityConfig) return updateProbability();
  const config = await api("/api/battle-probability/config");
  state.probabilityConfig = config;
  const levels = Object.keys(config.levelRanks);
  const attributes = [...Object.keys(config.attributeAdvantages), "Free", "Variable", "Unknown"];
  const fill = (selector, values, selected) => {
    $(selector).innerHTML = values.map(value => `<option value="${escapeHtml(value)}"${value === selected ? " selected" : ""}>${escapeHtml(value)}</option>`).join("");
  };
  fill("#probAttackerLevel", levels, "Rookie");
  fill("#probDefenderLevel", levels, "Rookie");
  fill("#probAttackerAttribute", attributes, "Vaccine");
  fill("#probDefenderAttribute", attributes, "Virus");
  renderProbabilityTables(config);
  updateProbability();
}

async function loadCatalog() {
  const query = encodeURIComponent($("#catalogQuery").value.trim());
  const model = encodeURIComponent($("#catalogModel").value);
  try {
    const data = await api(`/api/catalog?query=${query}&model=${model}`);
    const select = $("#catalogModel");
    if (select.options.length === 1) select.innerHTML += data.families.map(family => `<option value="${family.key}">${family.name} · ${family.mapped}/${family.total}</option>`).join("");
    $("#catalogSummary").textContent = `${data.total_matches} coincidencias${data.total_matches > 500 ? "; se muestran las primeras 500" : ""}.`;
    $("#catalogRows").innerHTML = data.entries.map(entry => `<tr><td>${escapeHtml(entry.family)}</td><td>${escapeHtml(entry.version)}</td><td>${entry.identificador ?? "PENDIENTE"}</td><td><button class="digi-link" data-digimon="${escapeHtml(entry.nombre)}">${escapeHtml(entry.nombre)}</button></td><td>${escapeHtml(entry.evidencia)}</td></tr>`).join("") || '<tr><td colspan="5">Sin resultados.</td></tr>';
  } catch (error) { toast(error.message); }
}

function renderProfile(index) {
  const profile = state.profiles[index];
  if (!profile) return;
  state.displayedProfile = { ...profile, variant_index: index };

  $("#digiName").textContent = profile.name;
  $("#digiKind").textContent = profile.kind || "Digimon";
  $("#digiLevel").textContent = profile.level || "—";
  $("#digiType").textContent = profile.type || "—";
  $("#digiAttribute").textContent = profile.attribute || "—";
  $("#digiDescription").textContent = profile.description || "El Reference Book no incluye una descripción para esta entrada.";
  $("#digiMoves").innerHTML = profile.attacks.length
    ? profile.attacks.map((move, moveIndex) => `<span><b>${String(moveIndex + 1).padStart(2, "0")}</b>${escapeHtml(move)}</span>`).join("")
    : '<p class="muted">No hay ataques registrados.</p>';

  const image = $("#digiImage");
  const fallback = $("#digiFallback");
  image.classList.toggle("hidden", !profile.image_url);
  fallback.classList.toggle("hidden", Boolean(profile.image_url));
  fallback.textContent = profile.name.charAt(0).toUpperCase() || "D";
  image.alt = profile.image_url ? `Ilustración de ${profile.name}` : "";
  image.src = profile.image_url || "";
}

function selectFighter(entry) {
  if (!entry) return;
  state.selectedFighter = entry;
  $("#fighterInput").value = entry.selector_label || entry.name;
  $("#fighterName").textContent = entry.level ? `${entry.name} · ${entry.level}` : entry.name;
  $("#fighterLevel").textContent = entry.level || "—";
  $("#fighterAttribute").textContent = entry.attribute || "—";
  $("#fighterType").textContent = entry.type || "—";
  $("#fighterAttacks").textContent = "—";
  $("#fighterFallback").textContent = entry.name.charAt(0).toUpperCase();
  const image = $("#fighterImage");
  image.classList.toggle("hidden", !entry.image_url);
  $("#fighterFallback").classList.toggle("hidden", Boolean(entry.image_url));
  image.src = entry.image_url || "";
  image.alt = entry.image_url ? `Ilustración de ${entry.name}` : "";
  loadFighterProfile(entry);
  if (state.probabilityConfig) {
    if ([...$("#probAttackerLevel").options].some(option => option.value === entry.level)) $("#probAttackerLevel").value = entry.level;
    if ([...$("#probAttackerAttribute").options].some(option => option.value === entry.attribute)) $("#probAttackerAttribute").value = entry.attribute;
    $("#probAttackerX").checked = Boolean(entry.antibody);
    updateProbability();
  }
}

function renderCombatantAttacks(selector, attacks) {
  const element = $(selector);
  const moves = Array.isArray(attacks) ? attacks.filter(Boolean) : [];
  element.innerHTML = moves.length
    ? moves.map(move => `<span>${escapeHtml(move)}</span>`).join("")
    : "—";
}

async function loadFighterProfile(entry) {
  try {
    const data = await api(`/api/reference/${encodeURIComponent(entry.name)}`);
    const profile = data.profiles?.[entry.variant_index || 0] || data.profiles?.[0];
    if (!profile || state.selectedFighter !== entry) return;
    renderCombatantAttacks("#fighterAttacks", profile.attacks);
  } catch (_) {
    renderCombatantAttacks("#fighterAttacks", []);
  }
}

async function loadVpetProfile(name) {
  try {
    const data = await api(`/api/reference/${encodeURIComponent(name)}`);
    const profile = data.profiles?.[0];
    if (!profile) return;
    $("#vpetName").textContent = profile.name;
    $("#vpetLevel").textContent = profile.level || "—";
    $("#vpetAttribute").textContent = profile.attribute || "—";
    $("#vpetType").textContent = profile.type || "—";
    renderCombatantAttacks("#vpetAttacks", profile.attacks);
    $("#vpetFallback").textContent = profile.name.charAt(0).toUpperCase() || "D";
    const image = $("#vpetImage");
    image.classList.toggle("hidden", !profile.image_url);
    $("#vpetFallback").classList.toggle("hidden", Boolean(profile.image_url));
    image.src = profile.image_url || "";
    image.alt = profile.image_url ? `Ilustración de ${profile.name}` : "";
  } catch (_) {}
}

function selectFighterByName(name) {
  const normalized = String(name || "").trim().toLocaleLowerCase("es");
  const entry = state.referenceEntries.find(item => (item.selector_label || item.name).toLocaleLowerCase("es") === normalized)
    || state.referenceEntries.find(item => item.name.toLocaleLowerCase("es") === normalized);
  selectFighter(entry);
}

async function loadReferenceList() {
  const data = await api("/api/reference-list");
  state.referenceEntries = data.entries || [];
  $("#fighterOptions").innerHTML = state.referenceEntries
    .map(entry => `<option value="${escapeHtml(entry.selector_label || entry.name)}">${escapeHtml([entry.level, entry.type, entry.kind].filter(Boolean).join(" · "))}</option>`)
    .join("");
}

async function showDigimon(name, automatic = false) {
  try {
    const data = await api(`/api/reference/${encodeURIComponent(name)}`);
    state.profiles = data.profiles || [];
    if (!state.profiles.length) return;

    const variant = $("#digiVariant");
    variant.innerHTML = state.profiles.map((profile, index) => {
      const details = [profile.level, profile.type, profile.attribute].filter(Boolean).join(" · ");
      return `<option value="${index}">${escapeHtml(profile.name)}${details ? ` · ${escapeHtml(details)}` : ""}</option>`;
    }).join("");
    $("#variantWrap").classList.toggle("hidden", state.profiles.length < 2);
    renderProfile(0);

    const modal = $("#digimonModal");
    if (!modal.open) modal.showModal();
  } catch (error) {
    if (!automatic) toast(error.message);
  }
}

async function loadCaptures() {
  try {
    const data = await api("/api/captures?limit=40");
    $("#captureList").innerHTML = data.captures.map(item => {
      const packets = (item.recibidos || []).join("-") || "Sin paquetes";
      return `<div class="capture"><div><b>${escapeHtml(item.modelo)}</b><br><small>${escapeHtml(item.fecha || "")}</small></div><code>${escapeHtml(packets)}</code><span class="badge ${item.completo ? "" : "partial"}">${item.completo ? "COMPLETA" : "PARCIAL"}</span></div>`;
    }).join("") || '<p class="muted">Todavía no hay capturas guardadas.</p>';
  } catch (error) { toast(error.message); }
}

document.addEventListener("DOMContentLoaded", async () => {
  document.querySelectorAll(".tab").forEach(tab => tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(item => item.classList.toggle("active", item === tab));
    document.querySelectorAll(".panel").forEach(panel => panel.classList.toggle("active", panel.id === `${tab.dataset.panel}Panel`));
    if (tab.dataset.panel === "catalog") loadCatalog();
    if (tab.dataset.panel === "captures") loadCaptures();
    if (tab.dataset.panel === "probability") loadProbabilityPanel();
  }));
  $("#probeButton").addEventListener("click", probe);
  $("#usbBetaLinkButton").addEventListener("click", toggleUsbBetaLink);
  window.addEventListener("betalinkusb:connected", event => setUsbBetaLinkConnected(true, event.detail));
  window.addEventListener("betalinkusb:disconnected", () => setUsbBetaLinkConnected(false));
  window.addEventListener("betalinkusb:error", event => {
    $("#deviceStatus").textContent = "ERROR USB";
    $("#deviceDetail").textContent = event.detail.message;
    toast(event.detail.message);
  });
  $("#modelSelect").addEventListener("change", event => localStorage.setItem("digimon-alpha:model", event.target.value));
  $("#battleButton").addEventListener("click", startBattle);
  $("#listenButton").addEventListener("click", startListen);
  $("#cancelButton").addEventListener("click", cancelOperation);
  $("#resetAllButton").addEventListener("click", resetAll);
  $("#playerLocationButton").addEventListener("click", togglePlayerLocationTracking);
  $("#fighterInput").addEventListener("change", event => selectFighterByName(event.target.value));
  $("#fighterInput").addEventListener("input", event => {
    if (state.selectedFighter && event.target.value !== (state.selectedFighter.selector_label || state.selectedFighter.name)) state.selectedFighter = null;
  });
  $("#catalogButton").addEventListener("click", loadCatalog);
  $("#catalogQuery").addEventListener("keydown", event => event.key === "Enter" && loadCatalog());
  $("#catalogRows").addEventListener("click", event => {
    const button = event.target.closest("[data-digimon]");
    if (button) showDigimon(button.dataset.digimon);
  });
  $("#closeDigimon").addEventListener("click", () => $("#digimonModal").close());
  $("#digimonModal").addEventListener("click", event => {
    if (event.target === $("#digimonModal")) $("#digimonModal").close();
  });
  $("#digiVariant").addEventListener("change", event => renderProfile(Number(event.target.value)));
  $("#selectFighterButton").addEventListener("click", () => {
    if (!state.displayedProfile) return;
    const selected = state.referenceEntries.find(entry =>
      entry.name === state.displayedProfile.name
      && entry.variant_index === (state.displayedProfile.variant_index || 0)
    ) || state.displayedProfile;
    selectFighter(selected);
    $("#digimonModal").close();
    document.querySelector('[data-panel="battle"]').click();
    $("#battleMatch").scrollIntoView({ behavior: "smooth", block: "center" });
  });
  $("#digiImage").addEventListener("error", () => {
    $("#digiImage").classList.add("hidden");
    $("#digiFallback").classList.remove("hidden");
  });
  $("#fighterImage").addEventListener("error", () => {
    $("#fighterImage").classList.add("hidden");
    $("#fighterFallback").classList.remove("hidden");
  });
  $("#vpetImage").addEventListener("error", () => {
    $("#vpetImage").classList.add("hidden");
    $("#vpetFallback").classList.remove("hidden");
  });
  $("#clearTerminal").addEventListener("click", () => { $("#terminal").textContent = ""; });
  ["#probAttackerLevel", "#probAttackerAttribute", "#probAttackerX", "#probDefenderLevel", "#probDefenderAttribute", "#probDefenderX"]
    .forEach(selector => $(selector).addEventListener("change", updateProbability));
  connectEvents();
  try { await Promise.all([loadStatus(), loadReferenceList()]); } catch (error) { toast(error.message); }
});
