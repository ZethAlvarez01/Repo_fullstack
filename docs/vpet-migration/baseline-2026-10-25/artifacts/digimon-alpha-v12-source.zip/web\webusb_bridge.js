import { WebUSBSerialPort } from "./vendor/esptool-js/webusb.js";

const CH340_VENDOR_ID = 0x1a86;
const CH340_PRODUCT_IDS = new Set([0x7523, 0x5523]);

let port = null;
let reader = null;
let writer = null;
let socket = null;
let readTask = null;
let writeChain = Promise.resolve();

function dispatch(name, detail = {}) {
  window.dispatchEvent(new CustomEvent(name, { detail }));
}

async function openBridgeSocket() {
  return new Promise((resolve, reject) => {
    const ws = window.DigimonAlphaEventsSocket;
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      reject(new Error("La conexión principal con el servidor todavía no está lista."));
      return;
    }
    const timeout = setTimeout(() => reject(new Error("El puente USB no respondió.")), 10000);
    const cleanup = () => {
      clearTimeout(timeout);
      window.removeEventListener("betalinkusb:bridge-ready", onReady);
      window.removeEventListener("betalinkusb:bridge-error", onError);
    };
    const onReady = () => {
      cleanup();
      resolve(ws);
    };
    const onError = event => {
      cleanup();
      reject(new Error(event.detail.message));
    };
    window.addEventListener("betalinkusb:bridge-ready", onReady);
    window.addEventListener("betalinkusb:bridge-error", onError);
    ws.send(JSON.stringify({ type: "usb-connect" }));
  });
}

window.addEventListener("betalinkusb:serverdata", event => {
  const bytes = new Uint8Array(event.detail.data);
  writeChain = writeChain.then(() => writer?.write(bytes));
});

async function pumpUsbToServer() {
  try {
    while (reader && socket?.readyState === WebSocket.OPEN) {
      const { value, done } = await reader.read();
      if (done) break;
      if (value?.byteLength && socket.readyState === WebSocket.OPEN) socket.send(value);
    }
  } catch (error) {
    if (port) dispatch("betalinkusb:error", { message: error.message });
  }
}

async function connect() {
  if (!window.isSecureContext) throw new Error("El Beta Link USB requiere la dirección HTTPS.");
  if (!navigator.usb) throw new Error("Este navegador no admite WebUSB. Usa Chrome en Android.");
  if (port) return;

  try {
    const selected = await WebUSBSerialPort.requestPort();
    const info = selected.getInfo();
    if (info.usbVendorId !== CH340_VENDOR_ID || !CH340_PRODUCT_IDS.has(info.usbProductId)) {
      throw new Error("El dispositivo elegido no es el CH340 del Beta Link.");
    }
    await selected.open({ baudRate: 9600 });
    port = selected;
    writer = port.writable.getWriter();
    reader = port.readable.getReader();
    socket = await openBridgeSocket();
    readTask = pumpUsbToServer();
    dispatch("betalinkusb:connected", {
      vendorId: info.usbVendorId,
      productId: info.usbProductId,
      label: `CH340 ${info.usbVendorId.toString(16)}:${info.usbProductId.toString(16)}`,
    });
  } catch (error) {
    await disconnect();
    throw error;
  }
}

async function disconnect() {
  const activeSocket = socket;
  socket = null;
  if (activeSocket?.readyState === WebSocket.OPEN) {
    activeSocket.send(JSON.stringify({ type: "usb-disconnect" }));
  }
  if (reader) {
    try { await reader.cancel(); } catch (_) { /* El USB puede haberse retirado. */ }
    try { reader.releaseLock(); } catch (_) { /* Ya liberado. */ }
    reader = null;
  }
  if (writer) {
    try { writer.releaseLock(); } catch (_) { /* Ya liberado. */ }
    writer = null;
  }
  if (readTask) {
    try { await readTask; } catch (_) { /* Finalización del lector. */ }
    readTask = null;
  }
  if (port) {
    try { await port.close(); } catch (_) { /* El cable pudo desconectarse. */ }
    port = null;
  }
  dispatch("betalinkusb:disconnected");
}

window.BetaLinkUsb = Object.freeze({
  connect,
  disconnect,
  isConnected: () => Boolean(port && socket?.readyState === WebSocket.OPEN),
});

navigator.usb?.addEventListener("disconnect", event => {
  if (port?.usbDevice === event.device) disconnect();
});
