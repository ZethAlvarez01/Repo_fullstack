# Firmware Digimon Alpha

`digimon_alpha_dmcomm` conserva DMComm Arduino Library v0.4.4 como modo
predeterminado. Los comandos originales siguen en `SerialFollower`. Un comando
Alpha activa una sola batalla y despues regresa al comportamiento normal.

El comando historico `1` conserva el flujo Pendulum X v1. Los perfiles Alpha
mantienen toda la batalla dentro de una sola conexion:

- `A0`: Pendulum Ver.20th Single Battle con mascara nativa.
- `A1`: Pendulum X.
- `A2`: Digital Monster X; Beta Link inicia para respetar el rol del protocolo.
- `A3`: Pendulum Z.
- `A4`: Digital Monster Color.
- `A5`: Pendulum Color.
- `A6`: Digital Monster Color Monster Hunter.
- `A7`: Digital Monster Color Godzilla.
- `A8`: Digital Monster Color Xros Wars.
- `A9`: Pendulum Color Godzilla.
- `B0`: Digivice Ver. Complete.
- `B1`: Digimon Xros Wars Mini con timing Y.

El firmware escribe `alpha:q:...` cuando ha recibido los campos de identidad.
En Color transmite solo versión+especie (8 dígitos) para responder dentro de la
ventana física de 100 ms; la captura completa sigue apareciendo al finalizar.
Los comandos Alpha Color `A4`–`A9` negocian temporalmente 115200 baudios con el
servidor y regresan a los 9600 baudios estándar al terminar. Los comandos DMComm
normales y las familias Alpha clásicas no cambian de velocidad.
Como el V-Pet inicia la batalla Alpha, los DigiROMs enviados usan los códigos de
rol respondedor (`0001` en el primer bloque y `0003` en el segundo), no los
códigos de iniciador `0000`/`0002` usados por un comando `C1` normal.
En los perfiles clasicos el host debe responder antes de 1000 ms con:

- `W`: gana el rival web; el V-Pet recibe una derrota.
- `P`: gana el V-Pet.

Si no hay respuesta valida, `P` es el resultado seguro. Un reinicio tambien
vuelve siempre al DMComm normal.

Las familias DMC compatibles tambien aceptan un perfil autentico preparado en
el propio comando, por ejemplo `A4:0002:0011:00B4:0003` para BanchoLeomon. Los
campos son version, slot, potencia y atributo. En este modo el firmware responde
inmediatamente y no espera `W`/`P`; el Color calcula la batalla con esos datos.

DMX y Pendulum Z materializan el resultado mediante los cinco bits de impactos
del sexto paquete y recalculan su checksum. DMX invierte esos impactos por el
rol del respondedor, comportamiento comprobado con una captura fisica; PenZ
conserva la interpretacion documentada. Los perfiles DMC dinamicos se limitan
a versiones, slots, potencias base y atributos publicados en el catalogo local.
En Digital Monster Color, la web lee la bandera de resultado devuelta en el
segundo bloque para mostrar el mismo ganador que el aparato.
Pendulum Color conserva los DigiROMs completos conocidos mientras se crea su
catalogo especifico.

## Respaldo

El firmware y la EEPROM originales estan en
`backups/dmcomm-v0.4.4-original-2026-10-24`. La placa comprobada es un Arduino
Nano ATmega328P con bootloader a 115200 baudios.

## Compilacion

```powershell
& 'C:\Program Files\Arduino CLI\arduino-cli.exe' compile `
  --fqbn arduino:avr:nano:cpu=atmega328 `
  --build-property 'build.extra_flags=-DSERIAL_RX_BUFFER_SIZE=128' `
  --library .\firmware\dmcomm-arduino-lib `
  --output-dir .\firmware\build\nano `
  .\firmware\digimon_alpha_dmcomm
```
