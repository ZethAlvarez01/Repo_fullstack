"""Construye el catalogo de identidad desde tablas publicas, sin inventar IDs.

No se copian estadisticas: solo familia/version, identificador, nombre y fuente.
Ejecutar: python tools/actualizar_catalogo.py
"""

import hashlib
import json
import re
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from html import unescape
from pathlib import Path
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[1]
MODERNOS = {
    "dm20": "Digital Monster Ver.20th",
    "pen20": "Pendulum Ver.20th",
    "dmx": "Digital Monster X",
    "penz": "Pendulum Z",
    "dmc": "Digital Monster Color",
    "penc": "Pendulum Color",
    "dmh": "Digital Monster Color Monster Hunter",
    "dmgz": "Digital Monster Color Godzilla",
    "dmxw": "Digital Monster Color Xros Wars",
    "pengz": "Pendulum Color Godzilla",
}
ANTIGUOS = {
    "dmog": ("Digital Monster original", "VpetProfiles"),
    "penog": ("Pendulum original", "PenProfiles"),
    "penprog": ("Pendulum Progress", "ProgProfiles"),
    "penx": ("Pendulum X", "PenxProfiles"),
    "accel": ("Digimon Accel", "AccelIntro"),
    "mini": ("Digimon Mini", "MiniProfiles"),
}
DMX_CLASSES = {"verXK": "XA", "verXW": "XB", "verXR": "XC", "verXP": "XD", "verXY": "XE", "verXB": "XF"}
FUENTE_SLOTS = "https://dmcomm.github.io/orig_battle/"
FUENTE_CODIGOS = "https://docs.google.com/document/d/16F4Lo-wBos1I_EgVhXyXpebCMQOIUWjsBG8dzscLTys/edit"


def texto(html):
    return " ".join(unescape(re.sub(r"<[^>]*>", " ", html)).split())


def descargar(url):
    req = Request(url, headers={"User-Agent": "DigimonAlpha-Catalogo/1.0"})
    with urlopen(req, timeout=25) as respuesta:
        datos = respuesta.read()
    return datos.decode("utf-8", errors="replace"), hashlib.sha256(datos).hexdigest()


def entrada(version, indice, nombre, fuente, evidencia="tabla_publica", **extra):
    return {"version": version, "identificador": indice, "nombre": nombre,
            "evidencia": evidencia, "fuente": fuente, **extra}


def parsear_moderno(modelo, pagina, fuente):
    entradas = []
    for fila in re.findall(r'<tr\b[^>]*class="digimon_row[^>]*>.*?</tr>', pagina, re.S):
        celdas = {}
        for clase, contenido in re.findall(r'<td\b[^>]*class="([^"]+)"[^>]*>(.*?)</td>', fila, re.S):
            celdas.setdefault(clase, texto(contenido))
        nombre = celdas.get("list_name", "")
        codigo = celdas.get("list_number", "")
        if not nombre or not codigo:
            continue
        if modelo == "dmx":
            indice = int(re.search(r"\d+$", codigo).group())
            clases = re.search(r'class="([^"]+)"', fila).group(1).split()
            versiones = [DMX_CLASSES[c] for c in clases if c in DMX_CLASSES]
        elif modelo in ("dm20", "pen20", "dmh", "dmgz", "dmxw", "pengz"):
            indice = int(codigo.rstrip("+"))
            versiones = ["comun"]
        else:
            # El prefijo de estos IDs es el espacio de nombres del catalogo
            # publicado. No se presume que sea el campo de version del cable.
            match = re.fullmatch(r"([A-Za-z0-9]+)-(\d+)(\+?)", codigo)
            if not match:
                raise ValueError(f"ID no reconocido en {modelo}: {codigo}")
            versiones = [match.group(1)]
            indice = int(match.group(2))
        for version in versiones:
            entradas.append(entrada(version, indice, nombre, fuente, id_fuente=codigo))
    if not entradas:
        raise ValueError(f"No se encontraron identidades en {modelo}")
    return entradas


def parsear_antiguo(modelo, pagina, fuente):
    entradas = []
    # Cada seccion es una version; la posicion NO se usa como ID salvo en
    # DMOG V1..5: sus 12 slots de combate siguen el esquema publicado por DMComm.
    secciones = re.findall(r'<h4[^>]*>(.*?)</h4>(.*?)(?=<h4|$)', pagina, re.S)
    for titulo, bloque in secciones:
        titulo = texto(titulo)
        tabla = re.search(r'<table\b[^>]*class="wikka"[^>]*>(.*?)</table>', bloque, re.S)
        if not tabla:
            continue
        nombres = []
        for fila in re.findall(r"<tr\b[^>]*>(.*?)</tr>", tabla.group(1), re.S):
            celdas = re.findall(r"<td\b[^>]*>(.*?)</td>", fila, re.S)
            if celdas:
                nombre = texto(celdas[0])
                if nombre:
                    nombres.append(nombre)
        if modelo == "dmog":
            match = re.fullmatch(r"Version ([1-5])", titulo)
            if not match or len(nombres) != 14:
                raise ValueError(f"Roster DMOG no previsto: {titulo}, {len(nombres)}")
            for pos, nombre in enumerate(nombres):
                # Babies no combaten: no tienen un slot observable por batalla.
                indice = pos + 1 if pos >= 2 else None
                entradas.append(entrada(match.group(1), indice, nombre, fuente,
                    evidencia="slot_documentado" if indice is not None else "sin_slot_de_batalla",
                    fuente_protocolo=FUENTE_SLOTS))
        else:
            for nombre in nombres:
                entradas.append(entrada(titulo, None, nombre, fuente, "indice_pendiente"))
    if not entradas:
        raise ValueError(f"Roster antiguo vacio: {modelo}")
    return entradas


def parsear_accel(pagina, fuente):
    """Extrae el roster por Genome sin convertir su orden en IDs de batalla."""
    listado = re.search(r"<h4>Digimon Listing</h4>(.*?)(?=</div>\s*</td>)", pagina, re.S | re.I)
    if not listado:
        raise ValueError("No se encontro Digimon Listing en AccelIntro")
    entradas = []
    esperadas = {"Justice Genome": 30, "Evil Genome": 30, "Nature Genome": 30, "Ultimate Genome": 32}
    versiones_vistas = set()
    for titulo, bloque in re.findall(r"<h5>(.*?)</h5>(.*?)(?=<h5>|$)", listado.group(1), re.S | re.I):
        version = texto(titulo)
        nombres = [texto(fragmento) for fragmento in re.split(r"<br\s*/?>", bloque, flags=re.I)]
        nombres = [nombre for nombre in nombres if nombre]
        if version not in esperadas or len(nombres) != esperadas[version]:
            raise ValueError(f"Roster Accel no previsto: {version}, {len(nombres)}")
        versiones_vistas.add(version)
        entradas.extend(entrada(version, None, nombre, fuente, "indice_pendiente") for nombre in nombres)
    if versiones_vistas != set(esperadas):
        raise ValueError("Faltan versiones del Digimon Accel")
    return entradas


def incorporar_verificados(familias):
    penx = familias["penx"]["entradas"]
    referencias = [
        ("1.0/1.5", 21, "Kuwagamon X", FUENTE_CODIGOS, "codigo_documentado"),
        ("1.0/1.5", 36, "Okuwamon X", FUENTE_CODIGOS, "codigo_documentado_y_prueba_local"),
        ("2.0/2.5", 38, "Triceramon X", "capturas.jsonl", "confirmado_por_usuario"),
    ]
    for version, indice, nombre, fuente, evidencia in referencias:
        encontrados = [e for e in penx if e["nombre"] == nombre and version in e["version"]]
        if len(encontrados) != 1:
            raise ValueError(f"Referencia PenX sin fila unica: {nombre}")
        encontrados[0].update(identificador=indice, evidencia=evidencia,
                              fuente_identificador=fuente, version_comunicacion="0" if version.startswith("1") else "1")


def parsear_pendulum_original(pagina, fuente):
    """Usa el campo Slot publicado, nunca el ID de la tabla Pen20 reciclada."""
    entradas = []
    for slug, bloque in re.findall(r'<div class="details[^\"]*" id="([^\"]+)_card">(.*?)(?=<div class="details|$)', pagina, re.S):
        match = re.search(r"pen([0-5]|ZERO)$", slug)
        nombre = re.search(r'<p class="sub">([^<]+)</p>', bloque)
        slot = re.search(r"Slot:\s*([^<]+)", bloque)
        if not match or not nombre or not slot or slug.startswith("digitama_"):
            continue
        numero = "0" if match.group(1) == "ZERO" else match.group(1)
        version = "ZERO" if numero == "0" else f"{numero}.0/{numero}.5"
        wire_version = "5" if numero == "0" else str(int(numero)-1)
        label = texto(slot.group(1))
        if not label:
            continue
        indice = None
        valor = re.fullmatch(r"(Vaccine|Data|Virus) (Child|Adult|Perfect|Ultimate)(?: ([12]))?", label)
        if valor:
            atributo, etapa, posicion = valor.groups()
            attr = ("Vaccine", "Data", "Virus").index(atributo)
            indice = {"Child": 3+attr, "Adult": 6+2*attr,
                      "Perfect": 12+2*attr, "Ultimate": 18+attr}[etapa]
            indice += int(posicion or "1")-1
        evidencia = "slot_publicado" if indice is not None else "sin_slot_de_batalla" if "Baby" in label else "indice_pendiente"
        entradas.append(entrada(version, indice, texto(nombre.group(1)), fuente, evidencia,
            slot_fuente=label, version_comunicacion=wire_version,
            fuente_protocolo="https://wiki.humulos.com/wiki/PenOG_Battle_DigiROM_format"))
    if len(entradas) < 100:
        raise ValueError("No se extrajo el roster Pendulum original completo")
    return entradas


def generar_markdown(catalogo):
    lineas = ["# Catalogo de identidad Digimon", "",
        "Solo identificador y nombre; no contiene estadisticas de combate.", "",
        "La clave completa es familia + version/espacio de nombres + identificador.",
        "Un numero de album o el orden de una lista no se convierte automaticamente en un ID del cable.",
        "PENDIENTE significa que existe el roster pero falta una correspondencia verificada.", "",
        "## Cobertura", "", "| Familia | Con ID | Sin ID |", "| --- | ---: | ---: |"]
    for familia in catalogo["familias"].values():
        entradas = familia["entradas"]
        n = sum(e["identificador"] is not None for e in entradas)
        lineas.append(f"| {familia['nombre']} | {n} | {len(entradas)-n} |")
    lineas += ["", "La cobertura de IDs no implica soporte USB ni prueba fisica de todos los modelos.",
        "Los Color requieren firmware y circuito compatibles; no se actualiza firmware automaticamente.",
        "DMX puede ocultar su indice. OTHER transmite slots compartidos y no identifica la especie moderna.", ""]
    for clave, familia in catalogo["familias"].items():
        lineas += [f"## {familia['nombre']} ({clave})", "", familia["nota"], "",
                   "| Version | Identificador | Digimon |", "| --- | --- | --- |"]
        for e in familia["entradas"]:
            ident = "PENDIENTE" if e["identificador"] is None else f"{e['identificador']} (0x{e['identificador']:02X})"
            if e["evidencia"] == "sin_slot_de_batalla":
                ident = "No combate"
            lineas.append(f"| {e['version']} | {ident} | {e['nombre'].replace('|', '/')} |")
        lineas += ["", f"Fuente: {familia['fuente']}", ""]
    lineas += ["## Otras familias y limites", "",
        "iC/Burst, Twin, Mini especiales, Pendulum Cycle, D-Cyber y Xros Mini:",
        "no se dispone aun de un mapa completo de IDs verificado en este catalogo.",
        "Los dispositivos infrarrojos o NFC necesitan interfaces adicionales; no se identifican solo por conectar dos contactos.",
        "Los nuevos modelos/reediciones no se consideran cubiertos automaticamente por compartir nombre o carcasa.", ""]
    return "\n".join(lineas)


def main():
    fuentes = {m: f"https://humulos.com/digimon/{m}/list/" for m in MODERNOS}
    fuentes.update({m: f"https://lcd.withthewill.net/{pagina}" for m, (_, pagina) in ANTIGUOS.items()})
    fuentes["penog"] = "https://humulos.com/digimon/pen/"
    familias = {}
    # No modifica el catalogo existente si falla alguna descarga o validacion.
    with ThreadPoolExecutor(max_workers=4) as pool:
        descargas = {m: pool.submit(descargar, url) for m, url in fuentes.items()}
        for modelo, futuro in descargas.items():
            pagina, sha = futuro.result()
            if modelo in MODERNOS:
                entradas = parsear_moderno(modelo, pagina, fuentes[modelo])
                nombre = MODERNOS[modelo]
                nota = "IDs de la tabla publica; las versiones son los prefijos de esa fuente."
                if modelo in ("dm20", "pen20"):
                    nota = "Indice global de especie; comun a los colores/versiones compatibles del modelo."
                if modelo == "dmx":
                    nota = "XA-XF; el indice puede venir oculto como 0. No se infiere una especie a partir de estadisticas."
            elif modelo == "penog":
                entradas = parsear_pendulum_original(pagina, fuentes[modelo])
                nombre = ANTIGUOS[modelo][0]
                nota = "Slots de batalla publicados por familia. Las versiones .0 y .5 comparten version y slots; pueden existir dos candidatos."
            elif modelo == "accel":
                entradas = parsear_accel(pagina, fuentes[modelo])
                nombre = ANTIGUOS[modelo][0]
                nota = "Roster por Genome; IDs de batalla pendientes. Usa tres pines y timing X; no usa infrarrojo."
            else:
                entradas = parsear_antiguo(modelo, pagina, fuentes[modelo])
                nombre = ANTIGUOS[modelo][0]
                nota = "Roster publicado; IDs sin documentar marcados como pendientes, sin deducirlos por el orden."
                if modelo == "dmog":
                    nota = "Versiones originales 1-5. Slots 3-14; selecciona la version fisica porque V1 puede repetir la version del rival. Babies no combaten."
            familias[modelo] = {"nombre": nombre, "nota": nota, "fuente": fuentes[modelo],
                                "sha256_fuente": sha, "entradas": entradas}
            print(f"{modelo}: {len(entradas)} entradas")
    incorporar_verificados(familias)
    catalogo = {"schema": 1, "generado_utc": datetime.now(timezone.utc).isoformat(),
                "familias": familias}
    destino = ROOT / "data" / "catalogo.json"
    destino.parent.mkdir(exist_ok=True)
    destino.write_text(json.dumps(catalogo, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (ROOT / "CATALOGO.md").write_text(generar_markdown(catalogo), encoding="utf-8")
    print("Catalogo generado: data/catalogo.json y CATALOGO.md")


if __name__ == "__main__":
    main()
