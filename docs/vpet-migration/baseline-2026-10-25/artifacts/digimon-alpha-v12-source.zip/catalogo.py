"""Identificacion por familia/version/ID; sin inferencia por estadisticas."""

import argparse
import json
import re
from functools import lru_cache
from pathlib import Path


RUTA_CATALOGO = Path(__file__).resolve().parent / "data" / "catalogo.json"

XROS_MINI_NAMES = {
    # El slot pertenece a la version: no se puede reutilizar el roster Red
    # para Blue/Black. Red procede de DMComm; Blue/01 fue confirmado con el
    # aparato fisico del proyecto.
    (1, 0x01): ("Shoutmon", "dmcomm_xros_mini_protocol"),
    (1, 0x0B): ("Guilmon", "dmcomm_xros_mini_protocol"),
    (1, 0x0C): ("Agumon", "dmcomm_xros_mini_protocol"),
    (1, 0x0D): ("V-Mon", "dmcomm_xros_mini_protocol"),
    (1, 0x10): ("Shoutmon X4", "dmcomm_xros_mini_protocol"),
    (2, 0x01): ("Greymon (2010 Anime Version)", "confirmado_por_usuario"),
}

DMX_STAGES = {
    0: "In-Training II",
    1: "Rookie",
    2: "Champion",
    3: "Ultimate",
    4: "Mega",
    5: "Mega",
}

MODERN_ATTRIBUTES = {0: "Vaccine", 1: "Data", 2: "Virus", 3: "Free"}

# Algunos DMX ocultan el indice de especie durante la batalla. Estas huellas
# usan solamente campos observados estables y requieren confirmacion fisica.
DMX_HIDDEN_FINGERPRINTS = {
    ("XA", (0x802E, 0x18AE, 0x393E, 0x2C4E)): (
        "Beelzebumon X", "confirmado_por_usuario",
    ),
    ("XB", (0x802E, 0x549E, 0x397E, 0x2D2E)): (
        "Beel Starmon X", "huella_y_estadisticas_de_roster",
    ),
}


@lru_cache(maxsize=1)
def cargar_catalogo():
    return json.loads(RUTA_CATALOGO.read_text(encoding="utf-8"))


def buscar(modelo, version, indice):
    familias = cargar_catalogo()["familias"]
    if modelo not in familias:
        return []
    entradas = familias[modelo]["entradas"]
    return [e for e in entradas if e["identificador"] == indice and (
        e["version"] == "comun" or e["version"].casefold() == version.casefold()
        or e.get("version_comunicacion") == version
    )]


def resultado(modelo, version, indice, nota=""):
    coincidencias = buscar(modelo, version, indice)
    nombres = sorted({e["nombre"] for e in coincidencias})
    return {"modelo": modelo, "version": version, "identificador": indice,
            "nombres": nombres, "estado": "identificado" if len(nombres) == 1 else "ambiguo" if nombres else "sin_correspondencia",
            "evidencia": sorted({e["evidencia"] for e in coincidencias}), "nota": nota}


def no_identificado(modelo, razon):
    return {"modelo": modelo, "version": None, "identificador": None,
            "nombres": [], "estado": "no_identificable", "evidencia": [], "nota": razon}


def identificar_xros_mini(paquete, nota=""):
    texto = str(paquete).strip()
    if not re.fullmatch(r"[0-9A-Fa-f]{4}", texto) or int(texto, 16) & 15 != 7:
        return no_identificado("xrosmini", "El primer paquete Xros Mini no es valido.")
    word = int(texto, 16)
    version = (word >> 12) & 15
    indice = (word >> 4) & 255
    entrada = XROS_MINI_NAMES.get((version, indice))
    if not entrada:
        return no_identificado(
            "xrosmini",
            f"Version {version}, slot {indice}: el protocolo es valido, pero el slot no esta documentado.",
        )
    nombre, evidencia = entrada
    return {
        "modelo": "xrosmini", "version": str(version), "identificador": indice,
        "nombres": [nombre], "estado": "identificado",
        "evidencia": [evidencia],
        "nota": nota or "Version y slot leidos del primer paquete Xros Mini.",
    }


def identificar_mini(paquete, nota=""):
    """Identifica slots del Digimon Mini confirmados por capturas fisicas."""
    texto = str(paquete).strip()
    if not re.fullmatch(r"[0-9A-Fa-f]{4}", texto) or int(texto, 16) & 15 != 9:
        return no_identificado("mini", "El primer paquete Digimon Mini no es valido.")
    word = int(texto, 16)
    version = str((word >> 12) & 15)
    indice = (word >> 4) & 255
    identidad = resultado(
        "mini", version, indice,
        nota or "Version y slot leidos del primer paquete Digimon Mini.",
    )
    if identidad["estado"] != "identificado":
        return no_identificado(
            "mini",
            f"Version {version}, slot {indice}: captura valida, pero este slot aun no esta documentado.",
        )
    return identidad


def datos_batalla_dmx(words):
    """Extrae campos publicos aun cuando DMX oculte el indice de especie."""
    packet = words[1]
    stage = (packet >> 13) & 7
    attribute = (packet >> 4) & 3
    return {
        "nivel": DMX_STAGES.get(stage),
        "atributo": MODERN_ATTRIBUTES.get(attribute, "Unknown"),
        "x_antibody": True,
    }


def identificar_dmx_oculto(modelo, namespace, words, nota):
    if modelo == "dmx" and len(words) >= 5:
        confirmado = DMX_HIDDEN_FINGERPRINTS.get((namespace, tuple(words[1:5])))
        if confirmado:
            nombre, evidencia = confirmado
            identificado = {
                "modelo": modelo,
                "version": namespace,
                "identificador": None,
                "nombres": [nombre],
                "estado": "identificado",
                "evidencia": [evidencia],
                "nota": "Especie reconocida por una huella de batalla confirmada con el aparato fisico.",
            }
            identificado.update(datos_batalla_dmx(words))
            return identificado
    oculto = no_identificado(modelo, nota)
    oculto.update(datos_batalla_dmx(words))
    oculto["version"] = namespace
    return oculto


def identificar_paquete_inicial_penx(paquete):
    """Extrae la identidad preliminar del primer paquete recibido de un PenX.

    El primer paquete contiene version e ID. El checksum solo puede validarse al
    terminar los cuatro paquetes, por eso esta lectura se marca como preliminar.
    """
    texto = str(paquete).strip()
    if not re.fullmatch(r"[0-9A-Fa-f]{4}", texto):
        return no_identificado("penx", "El primer paquete PenX debe tener cuatro digitos hexadecimales.")
    word = int(texto, 16)
    if word & 15 != 9:
        return no_identificado("penx", "El paquete no tiene la terminacion 9 esperada por PenX.")
    version = str((word >> 12) & 15)
    indice = (word >> 4) & 255
    return resultado(
        "penx", version, indice,
        "Identidad preliminar obtenida del primer paquete; el intercambio completo valida el checksum.",
    )


def identificar_inicio_batalla(modelo, codigo):
    """Identifica al rival fisico antes de terminar una batalla interactiva.

    Solo valida los campos que ya llegaron por COM. La captura completa sigue
    pasando por :func:`identificar`, que comprueba todos los paquetes y el
    checksum final del intercambio.
    """
    if modelo == "penx":
        return identificar_paquete_inicial_penx(codigo)
    if modelo == "mini":
        return identificar_mini(codigo)
    if modelo == "accel":
        texto = str(codigo).strip()
        if not re.fullmatch(r"[0-9A-Fa-f]{4}", texto) or int(texto, 16) & 15 != 9:
            return no_identificado(modelo, "El primer paquete X de tres pines no es valido.")
        return no_identificado(modelo, "Senal X valida; el mapa de identidad de esta familia sigue pendiente.")
    if modelo == "xrosmini":
        return identificar_xros_mini(codigo)
    if modelo == "dcomplete":
        texto = str(codigo).strip()
        if not re.fullmatch(r"[0-9A-Fa-f]{4}", texto):
            return no_identificado(modelo, "El primer paquete Ver. Complete no es valido.")
        return no_identificado(modelo, "Batalla clasica valida; la identidad exclusiva sigue pendiente.")

    familias_color = ("dmc", "penc", "dmh", "dmgz", "dmxw", "pengz")
    compacto = re.fullmatch(r"([0-9A-Fa-f]{4})([0-9A-Fa-f]{4})", codigo.strip())
    if modelo in familias_color and compacto:
        version = int(compacto.group(1), 16) + 1
        identificador = int(compacto.group(2), 16)
        namespace = f"{version:02d}" if modelo == "dmc" else str(version) if modelo == "penc" else "comun"
        return resultado(
            modelo, namespace, identificador,
            "Identidad obtenida de la consulta Color compacta del firmware.",
        )

    try:
        w = palabras(codigo)
    except ValueError as error:
        return no_identificado(modelo, str(error))

    if modelo in ("dmx", "penz"):
        if len(w) < 2 or any(p & 15 != 14 for p in w[:2]):
            return no_identificado(modelo, "Se necesitan los dos primeros paquetes DMX/PenZ.")
        version = (w[0] >> 4) & 15
        if modelo == "dmx":
            if version > 5:
                return no_identificado(modelo, "La version recibida no pertenece a DMX.")
            namespace = ("XA", "XB", "XC", "XD", "XE", "XF")[version]
        else:
            if version not in range(6, 12):
                return no_identificado(modelo, "La version recibida no pertenece a Pendulum Z.")
            namespace = "Z1" if version < 9 else "Z2"
        indice = (w[1] >> 6) & 127
        if indice == 0:
            return identificar_dmx_oculto(
                modelo, namespace, w,
                f"Version {namespace}: el aparato oculto su indice en esta batalla.",
            )
        return resultado(
            modelo, namespace, indice,
            "Identidad preliminar; el intercambio completo valida hits y checksum.",
        )

    if modelo == "pen20":
        if len(w) != 2 or any(packet & 15 != 14 for packet in w):
            return no_identificado(modelo, "Se necesitan los dos primeros paquetes Pendulum 20th.")
        operacion = (w[0] >> 8) & 3
        if operacion != 0:
            return no_identificado(modelo, "La conexion Pendulum 20th no es una batalla individual.")
        return resultado(
            modelo, "comun", (w[1] >> 6) & 255,
            "Identidad preliminar; los diez paquetes validan resultado y checksum.",
        )

    if modelo in familias_color:
        if len(w) != 8:
            return no_identificado(modelo, "Se necesita el primer bloque Color completo.")
        firma = (0x4744, 0x4470) if modelo in ("penc", "pengz") else (0x4744, 0x4C43)
        if tuple(w[:2]) != firma or (sum(w[:7]) & 65535) != w[7]:
            return no_identificado(modelo, "El primer bloque Color tiene firma o checksum incorrecto.")
        op_base = 0x10 if modelo in ("penc", "pengz") else 0
        if w[2] not in (op_base, op_base + 1):
            return no_identificado(modelo, "El bloque Color no contiene identidad de jugador.")
        if modelo in ("dmc", "penc"):
            numero = w[3] + 1
            namespace = f"{numero:02d}" if modelo == "dmc" else str(numero)
        else:
            namespace = "comun"
        return resultado(
            modelo, namespace, w[4],
            "Identidad preliminar obtenida del primer bloque Color.",
        )

    return no_identificado(modelo, "Esta familia no admite deteccion durante una batalla Alpha.")


def palabras(codigo):
    """Admite codigo hex o salida serial; ignora s: al interpretar una lectura."""
    if re.search(r"(?:^|\s)[rs]:", codigo):
        partes = re.findall(r"(?:^|\s)r:([0-9A-Fa-f]+)(?=\s|$)", codigo)
    else:
        limpio = re.sub(r"^(?:[VXYC][012]|DMX-X[A-F])-", "", codigo.strip(), flags=re.I)
        partes = re.split(r"[-\s]+", limpio)
    if not partes or any(not re.fullmatch(r"(?:[0-9A-Fa-f]{4})+", p) for p in partes):
        raise ValueError("El codigo debe contener paquetes hexadecimales completos; no plantillas @ o ^.")
    return [int(p[i:i+4], 16) for p in partes for i in range(0, len(p), 4)]


def checksum_correcto(words, objetivo):
    return sum(int(digito, 16) for w in words for digito in f"{w:04X}") % 16 == objetivo


def identificar(modelo, codigo, version=None):
    w = palabras(codigo)
    if modelo == "dcomplete":
        from catalogo_complete import candidatos, campos
        try:
            v, slot = campos(w)
        except ValueError:
            return [no_identificado(modelo, "La captura no cumple el formato clasico esperado: dos paquetes con bytes complementarios. Perfil experimental.")]
        nombres = candidatos(v, slot)
        return [{"modelo": modelo, "version": v, "identificador": slot,
                 "nombres": nombres, "estado": "candidato_local" if nombres else "sin_correspondencia",
                 "evidencia": ["confirmacion_manual_usuario"] if nombres else [],
                 "nota": "Catalogo local experimental: solo personajes observados, no identidad exclusiva verificada. "
                 "No se usa el catalogo del V-Pet original. "
                 + ("Registra el personaje seleccionado con catalogo_complete.py --nombre. " if not nombres else "")
                 + f"Campos crudos: slot={slot}, mejora={(w[0] >> 4) & 15}, version de comunicacion={v}, resultado={w[1] & 15}."}]
    if modelo in ("dmx", "penz"):
        if len(w) != 6 or any(p & 15 != 14 for p in w):
            return [no_identificado(modelo, "Se requieren los seis paquetes completos de batalla.")]
        if not checksum_correcto(w, 8):
            return [no_identificado(modelo, "Checksum DMX/PenZ incorrecto.")]
        v = (w[0] >> 4) & 15
        if modelo == "dmx":
            if v > 5:
                return [no_identificado(modelo, "La version recibida no es DMX XA-XF.")]
            namespace = ("XA", "XB", "XC", "XD", "XE", "XF")[v]
        else:
            if v not in range(6, 12):
                return [no_identificado(modelo, "Version Pendulum Z no reconocida.")]
            namespace = "Z1" if v < 9 else "Z2"
        indice = (w[1] >> 6) & 127
        if indice == 0:
            return [identificar_dmx_oculto(
                modelo, namespace, w,
                f"Version {namespace}: el indice llego como 0; no identifica a la especie en esta batalla.",
            )]
        if version and version.upper() != namespace:
            return [no_identificado(modelo, f"La version recibida ({namespace}) difiere de --version {version}.")]
        return [resultado(modelo, namespace, indice)]
    if modelo == "penx":
        if len(w) != 4 or any(p & 15 != 9 for p in w):
            return [no_identificado(modelo, "Se requieren cuatro paquetes completos de batalla PenX.")]
        if not checksum_correcto(w, 4):
            return [no_identificado(modelo, "Checksum PenX incorrecto.")]
        v = str((w[0] >> 12) & 15)
        indice = (w[0] >> 4) & 255
        return [resultado(modelo, v, indice, "Version interna del protocolo. Los IDs documentados son parciales; no se deducen por orden del roster.")]
    if modelo in ("accel", "mini"):
        if len(w) != 4 or any(p & 15 != 9 for p in w):
            return [no_identificado(modelo, "Se requieren cuatro paquetes completos de batalla X de tres pines.")]
        if not checksum_correcto(w, 4):
            return [no_identificado(modelo, "Checksum de batalla X incorrecto.")]
        if modelo == "mini":
            return [identificar_mini(
                f"{w[0]:04X}",
                "Identidad validada con los cuatro paquetes Digimon Mini.",
            )]
        return [no_identificado(modelo, "Captura X valida; el mapa verificado entre campos de batalla e identidad aun esta pendiente.")]
    if modelo == "xrosmini":
        if len(w) != 4 or any(p & 15 != 7 for p in w):
            return [no_identificado(modelo, "Se requieren cuatro paquetes completos Xros Mini.")]
        if not checksum_correcto(w, 12):
            return [no_identificado(modelo, "Checksum Xros Mini incorrecto.")]
        return [identificar_xros_mini(f"{w[0]:04X}", "Identidad validada con los cuatro paquetes Xros Mini.")]
    if modelo in ("dm20", "pen20"):
        if len(w) != 10:
            return [no_identificado(modelo, "Se requieren 10 paquetes. Una lectura de 9 puede estar desplazada: no se adivina el indice.")]
        if not checksum_correcto(w, 0 if modelo == "dm20" else 12):
            return [no_identificado(modelo, "Checksum de la captura incorrecto.")]
        offset = 2 if modelo == "dm20" else 0
        if any(p & 15 != 14 for p in w[offset:]):
            return [no_identificado(modelo, "Terminaciones de paquete incompatibles con este modelo.")]
        header = w[offset]
        operacion = (header >> 8) & 3
        if operacion not in (0, 2):
            return [no_identificado(modelo, "Este decodificador admite batalla, no copia ni Jogress.")]
        izquierdo = (w[offset + 1] >> 6) & 255
        resultados = [resultado(modelo, "comun", izquierdo)]
        if operacion == 2:
            derecha = offset + 4 if modelo == "dm20" else 5
            if modelo == "pen20" and w[derecha] >> 14 == 2:
                resultados.append(no_identificado(modelo, "El segundo Digimon es Copy Exclusive; necesita el mapa de esa base de Copymon."))
            else:
                resultados.append(resultado(modelo, "comun", (w[derecha] >> 6) & 255))
        return resultados
    if modelo == "dmog":
        if len(w) != 2 or any(((p >> 8) ^ (p & 255)) != 255 for p in w):
            return [no_identificado(modelo, "Se requieren dos paquetes DMOG con bits espejo validos.")]
        if version not in ("1", "2", "3", "4", "5"):
            return [no_identificado(modelo, "Indica la version fisica con --version 1..5. OTHER de un modelo moderno no usa esta tabla.")]
        return [resultado(modelo, version, w[0] & 15)]
    if modelo == "penog":
        if len(w) != 4 or any(p & 15 != 15 for p in w):
            return [no_identificado(modelo, "Se requieren cuatro paquetes de batalla Pendulum original.")]
        if not checksum_correcto(w, 11):
            return [no_identificado(modelo, "Checksum Pendulum original incorrecto.")]
        if (w[0] >> 10) & 1:
            return [no_identificado(modelo, "La operacion es Jogress, no batalla.")]
        return [resultado(modelo, str((w[0] >> 12) & 7), (w[0] >> 4) & 31,
                          "Las revisiones .0/.5 comparten slots; si hay dos nombres se muestran ambos.")]
    if modelo in ("dmc", "penc", "dmh", "dmgz", "dmxw", "pengz"):
        firma = (0x4744, 0x4470) if modelo in ("penc", "pengz") else (0x4744, 0x4C43)
        if len(w) != 16 or tuple(w[:2]) != firma or tuple(w[8:10]) != firma:
            return [no_identificado(modelo, "Se requieren dos bloques Color completos de 32 digitos cada uno con la firma correcta.")]
        if any((sum(w[i:i+7]) & 65535) != w[i+7] for i in (0, 8)):
            return [no_identificado(modelo, "Checksum Color incorrecto.")]
        op_base = 0x10 if modelo in ("penc", "pengz") else 0
        if w[2] not in (op_base, op_base+1):
            return [no_identificado(modelo, "El primer bloque Color no contiene identidad de jugador.")]
        if w[10] != w[2] + 2:
            return [no_identificado(modelo, "Los dos bloques Color no corresponden al mismo jugador/operacion.")]
        if modelo in ("dmc", "penc"):
            numero = w[3] + 1
            namespace = f"{numero:02d}" if modelo == "dmc" else str(numero)
        else:
            namespace = "comun"
        return [resultado(modelo, namespace, w[4])]
    return [no_identificado(modelo, "Roster disponible; el mapa de IDs de esta familia aun esta pendiente.")]


def mostrar(resultados):
    for r in resultados:
        if r["nombres"]:
            etiqueta = "Candidatos locales (no verificados)" if r["estado"] == "candidato_local" else "Digimon" if len(r["nombres"]) == 1 else "Candidatos"
            print(f"{etiqueta}: {', '.join(r['nombres'])}")
        else:
            print("Digimon: no identificado")
        if r["identificador"] is not None:
            print(f"Identificador: {r['modelo']}/{r['version']}/{r['identificador']}")
        if r["nota"]:
            print(r["nota"])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--modelo", choices=sorted(set(cargar_catalogo()["familias"]) | {"dcomplete"}), required=True)
    p.add_argument("--codigo", help="Paquetes recibidos, separados por guiones.")
    p.add_argument("--version", help="Version o prefijo del catalogo. Obligatorio para DMOG.")
    p.add_argument("--id", type=lambda s: int(s, 0), help="Consulta directa de ID decimal o 0xHEX.")
    a = p.parse_args()
    if bool(a.codigo) == (a.id is not None):
        p.error("Usa --codigo o --id, uno de los dos.")
    try:
        datos = identificar(a.modelo, a.codigo, a.version) if a.codigo else [resultado(a.modelo, a.version or "comun", a.id)]
        mostrar(datos)
        return 0 if all(r["estado"] == "identificado" for r in datos) else 1
    except ValueError as e:
        p.error(str(e))


if __name__ == "__main__":
    raise SystemExit(main())
