import unittest

from pen20_profiles import choose_pen20_proxy, load_pen20_profiles


class Pen20ProfilesTest(unittest.TestCase):
    def test_catalog_has_battle_profiles(self):
        profiles = load_pen20_profiles()
        self.assertEqual(len(profiles), 263)
        self.assertEqual(sum(item["battle_eligible"] for item in profiles), 223)

    def test_exact_level_and_attribute_are_preferred(self):
        profile = choose_pen20_proxy("Mega", "Vaccine", "Magnamon X")
        self.assertEqual((profile["level"], profile["attribute"]), ("Mega", "Vaccine"))
        self.assertLessEqual(profile["index"], 255)


if __name__ == "__main__":
    unittest.main()
