"""Genera perfiles de batalla autenticos para Pendulum Ver.20th."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen

from actualizar_perfiles_dmc import DmcListParser


SOURCE_URL = "https://humulos.com/digimon/pen20/list/"
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "data" / "pen20_battle_profiles.json"
ATTRIBUTE_WORDS = {"Vaccine": 0, "Data": 1, "Virus": 2, "Free": 3}
LEVELS = {"III": "Rookie", "IV": "Champion", "V": "Ultimate", "VI": "Mega", "VI+": "Mega", "Armor": "Champion"}


def build(html: str) -> dict:
    parser = DmcListParser()
    parser.feed(html)
    profiles = []
    for row in parser.rows:
        number = int(row["list_number"])
        stage = str(row.get("list_level") or "")
        attribute = str(row.get("row_attribute") or row.get("list_attribute") or "Free")
        power_text = str(row.get("list_strength") or "")
        power = int(power_text) if power_text.isdigit() else None
        eligible = number <= 255 and power is not None and stage in LEVELS
        profiles.append({
            "id": f"pen20-{number:03d}",
            "name": row["list_name"],
            "index": number,
            "stage": stage,
            "level": LEVELS.get(stage, stage),
            "attribute": attribute,
            "attribute_word": ATTRIBUTE_WORDS.get(attribute, 3),
            "base_power": power,
            "battle_eligible": eligible,
            "sprite_url": row.get("sprite_url", ""),
            "artwork_url": row.get("artwork_url", ""),
        })
    return {
        "schema_version": 1,
        "family": "pen20",
        "source": SOURCE_URL,
        "source_sha256": hashlib.sha256(html.encode("utf-8")).hexdigest(),
        "attribute_words": ATTRIBUTE_WORDS,
        "profiles": profiles,
    }


def main() -> None:
    request = Request(SOURCE_URL, headers={"User-Agent": "Digimon-Alpha catalog builder"})
    with urlopen(request, timeout=30) as response:
        html = response.read().decode("utf-8")
    catalog = build(html)
    OUTPUT.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    usable = sum(item["battle_eligible"] for item in catalog["profiles"])
    print(f"{len(catalog['profiles'])} perfiles Pen20; {usable} aptos para batalla.")


if __name__ == "__main__":
    main()
