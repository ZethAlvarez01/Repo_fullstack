"""Carga y consulta los perfiles autenticos del Digital Monster Color."""

from __future__ import annotations

import json
import hashlib
from pathlib import Path


CATALOG_PATH = Path(__file__).with_name("data") / "dmc_battle_profiles.json"

LEVEL_ALIASES = {
    "in-training Ⅰ": "Rookie",
    "in-training ⅰ": "Rookie",
    "in-training Ⅱ": "Rookie",
    "in-training ⅱ": "Rookie",
    "child": "Rookie",
    "rookie": "Rookie",
    "rookie(xros wars)": "Rookie",
    "adult": "Champion",
    "champion": "Champion",
    "champion(xros wars)": "Champion",
    "armor": "Champion",
    "hybrid": "Champion",
    "standard": "Champion",
    "perfect": "Ultimate",
    "ultimate": "Ultimate",
    "ultimate(xros wars)": "Ultimate",
    "mega": "Mega",
    "mega(xros wars)": "Mega",
    "super": "Mega",
    "god": "Mega",
    "super ultimate": "Mega",
    "ultra": "Mega",
    "unknown": "Champion",
    "－": "Champion",
}


def load_dmc_profiles(path: Path = CATALOG_PATH) -> list[dict]:
    return json.loads(path.read_text(encoding="utf-8"))["profiles"]


def normalize_level(level: str) -> str:
    raw = str(level).strip()
    key = raw.casefold().replace("(xros wars)", "")
    return LEVEL_ALIASES.get(key, raw)


def find_dmc_proxies(level: str, attribute: str, path: Path = CATALOG_PATH) -> list[dict]:
    """Devuelve perfiles enviables, priorizando nivel y atributo exactos."""
    wanted_level = normalize_level(level)
    wanted_attribute = str(attribute).strip().casefold()
    eligible = [profile for profile in load_dmc_profiles(path) if profile["battle_eligible"]]
    exact = [
        profile for profile in eligible
        if profile["level"] == wanted_level
        and str(profile["attribute"]).casefold() == wanted_attribute
    ]
    if exact:
        return exact
    return [profile for profile in eligible if profile["level"] == wanted_level]


def choose_dmc_proxy(level: str, attribute: str, identity: str = "", path: Path = CATALOG_PATH) -> dict:
    """Elige establemente una especie DMC que pueda representar a una mascara web."""
    matches = find_dmc_proxies(level, attribute, path)
    if not matches:
        raise ValueError(f"No hay un perfil DMC combatible para nivel {level!r}.")
    ordered = sorted(matches, key=lambda item: (item["version"], item["slot"], item["name"]))
    digest = hashlib.sha256(str(identity).strip().casefold().encode("utf-8")).digest()
    return ordered[int.from_bytes(digest[:4], "big") % len(ordered)]
