"""Motor ponderado y configurable de probabilidades para batallas V-Pet."""

import json
import math
import random
from functools import lru_cache
from pathlib import Path


CONFIG_PATH = Path(__file__).resolve().parent / "data" / "battle_probability.json"


@lru_cache(maxsize=1)
def load_battle_config():
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def _clamp(value, minimum, maximum):
    return max(minimum, min(maximum, value))


def _number(value, field):
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field} debe ser numerico.") from error
    if not math.isfinite(result):
        raise ValueError(f"{field} debe ser finito.")
    return result


def _boolean(value):
    if isinstance(value, str):
        return value.strip().casefold() in {"1", "true", "yes", "si", "sí"}
    return bool(value)


def _normalize(value, aliases, fallback):
    text = str(value or "").strip()
    if text in aliases:
        return aliases[text]
    folded = text.casefold()
    for original, normalized in aliases.items():
        if original.casefold() == folded:
            return normalized
    return text or fallback


def _non_combatant_sides(attacker_level, defender_level, config):
    aliases = config["levelAliases"]
    attacker = _normalize(attacker_level, aliases, "Sin dato").casefold()
    defender = _normalize(defender_level, aliases, "Sin dato").casefold()
    non_combatants = {
        level.casefold() for level in config.get("nonCombatantLevels", [])
    }
    return attacker in non_combatants, defender in non_combatants


def _level_probability(attacker_level, defender_level, config):
    aliases = config["levelAliases"]
    ranks = config["levelRanks"]
    attacker = _normalize(attacker_level, aliases, "Sin dato")
    defender = _normalize(defender_level, aliases, "Sin dato")
    normalized_ranks = {name.casefold(): rank for name, rank in ranks.items()}
    attacker_rank = normalized_ranks.get(attacker.casefold())
    defender_rank = normalized_ranks.get(defender.casefold())
    if attacker_rank is None or defender_rank is None:
        return config["baseProbability"]
    attacker_non_combatant, defender_non_combatant = _non_combatant_sides(
        attacker, defender, config
    )
    if attacker_non_combatant != defender_non_combatant:
        non_combatant_probability = config.get(
            "nonCombatantWinProbability", config["minimumProbability"]
        )
        return (
            non_combatant_probability
            if attacker_non_combatant
            else 1 - non_combatant_probability
        )
    difference = attacker_rank - defender_rank
    configured = config.get("levelDifferenceModifiers", {})
    magnitude = configured.get(str(abs(difference)))
    if magnitude is None:
        magnitude = abs(difference) * config["levelStep"]
    probability = config["baseProbability"] + (magnitude if difference >= 0 else -magnitude)
    return _clamp(
        probability,
        config["minimumProbability"],
        config["maximumProbability"],
    )


def _attribute_modifier(attacker_attribute, defender_attribute, config):
    aliases = config["attributeAliases"]
    attacker = _normalize(attacker_attribute, aliases, "Sin dato")
    defender = _normalize(defender_attribute, aliases, "Sin dato")
    neutral = {value.casefold() for value in config["neutralAttributes"]}
    if attacker.casefold() in neutral or defender.casefold() in neutral:
        return 0.0
    advantages = {
        key.casefold(): value.casefold()
        for key, value in config["attributeAdvantages"].items()
    }
    if advantages.get(attacker.casefold()) == defender.casefold():
        return config["attributeAdvantage"]
    if advantages.get(defender.casefold()) == attacker.casefold():
        return -config["attributeAdvantage"]
    return 0.0


def calculate_battle_probability(params, config=None):
    """Calcula la probabilidad base; no realiza ninguna tirada aleatoria."""
    config = config or load_battle_config()
    level_probability = _level_probability(
        params.get("attackerLevel"), params.get("defenderLevel"), config
    )
    attribute_modifier = _attribute_modifier(
        params.get("attackerAttribute"), params.get("defenderAttribute"), config
    )
    attacker_non_combatant, defender_non_combatant = _non_combatant_sides(
        params.get("attackerLevel"), params.get("defenderLevel"), config
    )
    mixed_non_combatant_matchup = attacker_non_combatant != defender_non_combatant
    attacker_x = _boolean(params.get("attackerHasXAntibody", False))
    defender_x = _boolean(params.get("defenderHasXAntibody", False))
    x_modifier = 0.0
    if attacker_x != defender_x:
        x_modifier = config["xAntibodyBonus"] if attacker_x else -config["xAntibodyBonus"]
    attacker_stats = _number(params.get("attackerStatModifier", 0), "attackerStatModifier")
    defender_stats = _number(params.get("defenderStatModifier", 0), "defenderStatModifier")
    stats_modifier = attacker_stats - defender_stats
    if mixed_non_combatant_matchup:
        attribute_modifier = 0.0
        x_modifier = 0.0
        stats_modifier = 0.0
    attacker_probability = _clamp(
        level_probability + attribute_modifier + x_modifier + stats_modifier,
        config["minimumProbability"],
        config["maximumProbability"],
    )
    # Evita residuos como 0.6500000000000001 en la API y en los registros.
    attacker_probability = round(attacker_probability, 12)
    return {
        "attackerWinProbability": attacker_probability,
        "defenderWinProbability": round(1 - attacker_probability, 12),
        "breakdown": {
            "levelProbability": round(level_probability, 12),
            "attributeModifier": round(attribute_modifier, 12),
            "xAntibodyModifier": round(x_modifier, 12),
            "statsModifier": round(stats_modifier, 12),
        },
    }


def resolve_battle(params, *, include_noise=None, rng=None, config=None):
    """Aplica ruido opcional, hace la tirada y devuelve un ganador reproducible."""
    config = config or load_battle_config()
    calculation = calculate_battle_probability(params, config)
    noise_config = config.get("noise", {})
    if include_noise is None:
        include_noise = bool(noise_config.get("enabled", False))
    attacker_non_combatant, defender_non_combatant = _non_combatant_sides(
        params.get("attackerLevel"), params.get("defenderLevel"), config
    )
    if attacker_non_combatant != defender_non_combatant:
        include_noise = False
    generator = rng or random.random
    amplitude = _number(noise_config.get("amplitude", 0), "noise.amplitude")
    noise_modifier = (generator() * 2 - 1) * amplitude if include_noise else 0.0
    effective_probability = _clamp(
        calculation["attackerWinProbability"] + noise_modifier,
        config["minimumProbability"],
        config["maximumProbability"],
    )
    roll = generator()
    return {
        **calculation,
        "effectiveAttackerWinProbability": round(effective_probability, 12),
        "noiseModifier": round(noise_modifier, 12),
        "roll": round(roll, 12),
        "winner": "attacker" if roll <= effective_probability else "defender",
    }


# Alias compatible con la interfaz solicitada y clientes que usan camelCase.
calculateBattleProbability = calculate_battle_probability
