"""Genera el catalogo de combatientes del Digital Monster Color.

La fuente publica contiene numero de version/slot, etapa, atributo y potencia
base. El archivo generado mantiene esos datos separados de la logica de
batalla para que el firmware pueda usar solamente perfiles DMC autenticos.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from html.parser import HTMLParser
from pathlib import Path
from urllib.request import Request, urlopen


SOURCE_URL = "https://humulos.com/digimon/dmc/list/"
ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "data" / "dmc_battle_profiles.json"

ATTRIBUTE_WORDS = {"Free": 0, "Virus": 1, "Data": 2, "Vaccine": 3}
LEVEL_NAMES = {
    "I": "Baby I",
    "II": "Baby II",
    "III": "Rookie",
    "IV": "Champion",
    "V": "Ultimate",
    "VI": "Mega",
    "VI+": "Ultra",
}
STRENGTH_BONUS = {"III": 5, "IV": 8, "V": 15, "VI": 25, "VI+": 25}


class DmcListParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[dict[str, object]] = []
        self.row: dict[str, object] | None = None
        self.cell_class: str | None = None
        self.cell_text: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        classes = (values.get("class") or "").split()
        if tag == "tr" and "digimon_row" in classes:
            self.row = {
                "row_attribute": values.get("attribute"),
                "row_stage": values.get("stage"),
            }
        elif self.row is not None and tag == "td":
            self.cell_class = next((item for item in classes if item.startswith("list_")), None)
            self.cell_text = []
        elif self.row is not None and tag == "img":
            src = values.get("src") or ""
            if src.startswith("//"):
                src = "https:" + src
            if "list_dot" in classes:
                self.row["sprite_url"] = src
            elif "list_art" in classes:
                self.row["artwork_url"] = src

    def handle_data(self, data: str) -> None:
        if self.row is not None and self.cell_class:
            self.cell_text.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "td" and self.row is not None and self.cell_class:
            value = " ".join("".join(self.cell_text).split())
            self.row[self.cell_class] = value
            self.cell_class = None
            self.cell_text = []
        elif tag == "tr" and self.row is not None:
            if self.row.get("list_number") and self.row.get("list_name"):
                self.rows.append(self.row)
            self.row = None
            self.cell_class = None


def checksum(words: list[int]) -> int:
    return sum(words) & 0xFFFF


def responder_block(version_word: int, slot: int, power: int, attribute_word: int) -> str:
    words = [0x4744, 0x4C43, 0x0001, version_word, slot, power, attribute_word]
    words.append(checksum(words))
    return "".join(f"{word:04X}" for word in words)


def parse_profiles(html: str) -> list[dict[str, object]]:
    parser = DmcListParser()
    parser.feed(html)
    profiles: list[dict[str, object]] = []

    for row in parser.rows:
        display_id = str(row["list_number"])
        version_text, slot_text = display_id.split("-", 1)
        version_number = int(version_text)
        slot = int(slot_text)
        stage = str(row.get("list_level") or row.get("row_stage") or "")
        attribute = str(row.get("row_attribute") or row.get("list_attribute") or "Free")
        power_text = str(row.get("list_attribute") or "")
        base_power = int(power_text) if power_text.isdigit() else None
        protocol_ready = 1 <= version_number <= 5
        battle_eligible = protocol_ready and stage in STRENGTH_BONUS and base_power is not None
        version_word = version_number - 1 if protocol_ready else None
        attribute_word = ATTRIBUTE_WORDS[attribute]
        bonus = STRENGTH_BONUS.get(stage)

        profile: dict[str, object] = {
            "id": f"dmc-{display_id}",
            "name": row["list_name"],
            "display_id": display_id,
            "version": version_number,
            "slot": slot,
            "stage": stage,
            "level": LEVEL_NAMES.get(stage, stage),
            "attribute": attribute,
            "base_power": base_power,
            "full_strength_power": base_power + bonus if base_power is not None and bonus else None,
            "maximum_power": base_power + (2 * bonus) if base_power is not None and bonus else None,
            "version_word": version_word,
            "slot_word": slot if protocol_ready else None,
            "attribute_word": attribute_word,
            "battle_eligible": battle_eligible,
            "protocol_ready": protocol_ready,
            "sprite_url": row.get("sprite_url", ""),
            "artwork_url": row.get("artwork_url", ""),
        }
        profile["responder_first_block"] = (
            responder_block(version_word, slot, base_power, attribute_word)
            if battle_eligible and version_word is not None and base_power is not None
            else None
        )
        profiles.append(profile)

    return profiles


def build_catalog(html: str) -> dict[str, object]:
    profiles = parse_profiles(html)
    return {
        "schema_version": 1,
        "family": "dmc",
        "name": "Digital Monster Color",
        "source": SOURCE_URL,
        "source_sha256": hashlib.sha256(html.encode("utf-8")).hexdigest(),
        "attribute_words": ATTRIBUTE_WORDS,
        "notes": [
            "version_word is zero-based for DMC Ver.1 through Ver.5.",
            "Baby I and Baby II are catalogued but cannot enter a connection battle.",
            "Cross-version Jogress rows are preserved but protocol_ready is false until their wire identity is verified.",
            "responder_first_block uses role 0001 and the published base power.",
        ],
        "profiles": profiles,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", help="HTML local; si se omite se descarga la fuente publica.")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    if args.source:
        html = Path(args.source).read_text(encoding="utf-8")
    else:
        request = Request(SOURCE_URL, headers={"User-Agent": "Digimon-Alpha catalog builder"})
        with urlopen(request, timeout=30) as response:
            html = response.read().decode("utf-8")

    catalog = build_catalog(html)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    eligible = sum(bool(item["battle_eligible"]) for item in catalog["profiles"])
    print(f"{len(catalog['profiles'])} perfiles guardados; {eligible} aptos para batalla.")


if __name__ == "__main__":
    main()
