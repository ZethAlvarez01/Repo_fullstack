"""Consulta local del Digimon Reference Book usado por la interfaz web."""

import os
import re
import unicodedata
from functools import lru_cache
from pathlib import Path

import openpyxl


DEFAULT_BOOK = Path(r"C:\Users\zetha\OneDrive\Desktop\Proyectos\Digimon_Game\outputs\appmon\reference_book_2_with_images_and_appmon.xlsx")
DEFAULT_IMAGES = Path(r"C:\Users\zetha\OneDrive\Desktop\Proyectos\Digimon_Game\img")
BOOK_PATH = Path(os.environ.get("DIGIMON_REFERENCE_BOOK", DEFAULT_BOOK))
IMAGE_DIR = Path(os.environ.get("DIGIMON_IMAGE_DIR", DEFAULT_IMAGES))
OVERRIDES_PATH = Path(__file__).resolve().parent / "data" / "reference_overrides.json"


ALIASES = {
    "alphaouryuken": "alphamonouryuken",
    "alforcevdramon": "ulforceveedramon",
    "alforcevdramonx": "ulforceveedramonx",
    "atlurkabuterimon": "megakabuterimon",
    "beelzebumon": "beelzemon",
    "beelzebumonblastmode": "beelzemonblastmode",
    "beelzebumonx": "beelzemonx",
    "chimeramon": "kimeramon",
    "deathxdorugamon": "dexdorugamon",
    "deathxdorugoramon": "dexdorugoramon",
    "deathxdorugremon": "dexdorugreymon",
    "deathxmon": "dexmon",
    "dukemon": "gallantmon",
    "dukemonx": "gallantmonx",
    "fantomon": "phantomon",
    "holyangemon": "magnaangemon",
    "holydramon": "magnadramon",
    "hououmon": "phoenixmon",
    "mugendramon": "machinedramon",
    "omegamon": "omnimon",
    "omegamonx": "omnimonx",
    "piemon": "piedmon",
    "tailmon": "gatomon",
    "vamdemon": "myotismon",
    "venomvamdemon": "venommyotismon",
    "voltobautamon": "boltboutamon",
}


def normalize_name(value):
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = "".join(character for character in text if not unicodedata.combining(character)).casefold()
    text = re.sub(r"\(\s*x[- ]?antibody\s*\)", " x", text)
    text = re.sub(r"\bx[- ]?antibody\b", "x", text)
    return re.sub(r"[^a-z0-9]+", "", text)


def _cell(record, *names):
    for name in names:
        value = record.get(name)
        if value not in (None, ""):
            return value
    return None


def _record(sheet_name, headers, row):
    raw = dict(zip(headers, row))
    attacks = [raw.get(f"Special Move {number}") for number in range(1, 9)]
    attacks = [str(attack).strip() for attack in attacks if attack not in (None, "")]
    image = _cell(raw, "Image File", "Image File 1", "Image File 2")
    return {
        "name": str(raw.get("Name") or "").strip(),
        "kind": "Appmon" if sheet_name == "Appmon" else "Digimon",
        "level": _cell(raw, "Level", "Grade"),
        "type": _cell(raw, "Type", "App Name"),
        "attribute": raw.get("Attribute"),
        "attacks": attacks,
        "description": raw.get("Profile") or "",
        "antibody": bool(raw.get("antibody")),
        "appmon_id": raw.get("Appmon ID"),
        "image": Path(str(image)).name if image else None,
        "source_url": raw.get("Source URL"),
    }


def _load_overrides():
    if not OVERRIDES_PATH.is_file():
        return {}
    import json
    return json.loads(OVERRIDES_PATH.read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def load_reference_book():
    if not BOOK_PATH.is_file():
        return {"by_name": {}, "records": [], "available": False}
    workbook = openpyxl.load_workbook(BOOK_PATH, read_only=True, data_only=True)
    records = []
    try:
        for sheet in workbook.worksheets:
            rows = sheet.iter_rows(values_only=True)
            headers = [str(value or "").strip() for value in next(rows)]
            for row in rows:
                if row and row[0]:
                    records.append(_record(sheet.title, headers, row))
    finally:
        workbook.close()
    overrides = _load_overrides()
    for record in records:
        override = overrides.get(normalize_name(record["name"]))
        if override:
            record.update(override)
    by_name = {}
    for record in records:
        key = normalize_name(record["name"])
        by_name.setdefault(key, []).append(record)
        if key.endswith("xantibody"):
            by_name.setdefault(key.removesuffix("antibody"), []).append(record)
    return {"by_name": by_name, "records": records, "available": True}


def image_path(filename):
    if not filename or Path(filename).name != filename:
        return None
    candidate = (IMAGE_DIR / filename).resolve()
    root = IMAGE_DIR.resolve()
    if root not in candidate.parents or candidate.suffix.casefold() not in {".jpg", ".jpeg", ".png", ".webp"}:
        return None
    return candidate if candidate.is_file() else None


def find_profiles(name):
    data = load_reference_book()
    requested = normalize_name(name)
    key = ALIASES.get(requested, requested)
    return [
        {
            **profile,
            "image_url": f"/api/reference-image/{profile['image']}" if profile.get("image") and image_path(profile["image"]) else None,
        }
        for profile in data["by_name"].get(key, [])
    ]


def reference_names():
    """Lista ligera que conserva variantes homonimas para el selector."""
    data = load_reference_book()
    counts = {}
    for record in data["records"]:
        key = normalize_name(record["name"])
        counts[key] = counts.get(key, 0) + 1

    positions = {}
    entries = []
    for record in data["records"]:
        key = normalize_name(record["name"])
        variant_index = positions.get(key, 0)
        positions[key] = variant_index + 1
        details = [record["level"], record["type"]]
        details = [str(value) for value in details if value]
        selector_label = record["name"]
        if counts[key] > 1:
            selector_label += " — " + " · ".join(details or [f"Variante {variant_index + 1}"])
        entries.append({
            "name": record["name"],
            "kind": record["kind"],
            "level": record["level"],
            "type": record["type"],
            "attribute": record["attribute"],
            "antibody": record["antibody"],
            "variant_index": variant_index,
            "selector_label": selector_label,
            "image_url": (
                f"/api/reference-image/{record['image']}"
                if record.get("image") and image_path(record["image"])
                else None
            ),
        })
    return sorted(entries, key=lambda item: (item["name"].casefold(), item["variant_index"]))


def reference_status():
    data = load_reference_book()
    return {
        "available": data["available"],
        "records": len(data["records"]),
        "workbook": BOOK_PATH.name,
        "images_available": IMAGE_DIR.is_dir(),
    }
