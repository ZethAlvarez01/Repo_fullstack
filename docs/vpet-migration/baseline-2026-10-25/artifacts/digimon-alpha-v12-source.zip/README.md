# Beta Link: conexion, escucha e intercambio

## Interfaz web local

La consola web permite controlar las batallas, escuchar senales, consultar el
catalogo y revisar capturas desde el navegador. Escucha en `0.0.0.0:8000` para
que otros dispositivos de la misma red puedan abrirla.

Instala las dependencias y arranca el servidor:

```powershell
python -m pip install -r requirements.txt
python .\web_app.py
```

Abre `http://127.0.0.1:8000`. La terminal de la pagina muestra la salida serial
en vivo. Solo puede existir una operacion a la vez; al cancelar, el servidor
detiene el proceso y envia al firmware el comando pasivo correspondiente.

En Android Chrome tambien puede conectarse el CH340 del Beta Link directamente
por USB OTG. La pagina debe servirse por HTTPS: pulsa `Conectar Beta Link USB`,
autoriza el dispositivo `1A86:7523` y selecciona el puerto `USB del celular`.
El navegador transporta los bytes al mismo motor Python mediante el WebSocket
`/api/usb-serial`; el modo COM de escritorio permanece disponible.

La API local expone `/api/status`, `/api/probe`, `/api/battle`, `/api/listen`,
`/api/cancel`, `/api/catalog`, `/api/captures` y los WebSockets `/api/events`
y `/api/usb-serial`.
El frontend esta en `web/` y no requiere un proceso de compilacion.

### Fichas del Digimon Reference Book

Cuando la terminal recibe una linea como `Digimon: Numemon`, la interfaz abre
automaticamente una ficha con nombre, nivel, tipo, atributo, ataques, perfil e
imagen. Los nombres del catalogo tambien son botones para abrir la ficha sin
conectar el aparato. Si el Reference Book contiene varias entradas con el mismo
nombre, aparece un selector de variantes.

Por defecto se consulta, en modo de solo lectura:

- `C:\Users\zetha\OneDrive\Desktop\Proyectos\Digimon_Game\outputs\appmon\reference_book_2_with_images_and_appmon.xlsx`
- `C:\Users\zetha\OneDrive\Desktop\Proyectos\Digimon_Game\img`

Para mover esos recursos, define `DIGIMON_REFERENCE_BOOK` y
`DIGIMON_IMAGE_DIR` antes de arrancar el servidor. El endpoint
`/api/reference/{nombre}` devuelve la ficha y `/api/reference-image/{archivo}`
sirve solamente imagenes validas dentro de la carpeta configurada.

### Batalla con rival del Reference Book

En la pestaña Batalla eliges solamente el personaje del Reference Book que será
el rival web. La detección automática con resultado variable está habilitada
primero para Pendulum X. El programa lee el primer paquete del V-Pet por COM,
busca su ID verificado en el catálogo y carga sus datos del Reference Book; el
Digimon físico nunca se selecciona manualmente en la interfaz.

Con ambos perfiles disponibles, el motor calcula la probabilidad usando nivel,
atributo, X-Antibody y el ajuste estadístico del rival web. Luego aplica un ruido
uniforme configurable de hasta tres puntos porcentuales, realiza la tirada y
elige el código ganar/perder verificado correspondiente. El firmware Alpha
opcional informa el primer paquete al servidor, recibe la decisión y continúa
la misma batalla sin desconectar el Pendulum X. El
resultado queda registrado en el V-Pet y en `capturas.jsonl` junto con el rival
visual, el representante de protocolo, las probabilidades y los paquetes. El
balance se puede editar en `data/battle_probability.json`. No se generan codigos
hexadecimales arbitrarios. Todos los comandos originales de DMComm permanecen
activos por defecto; solamente una línea exacta `1` habilita una batalla Alpha y
al terminar vuelve al modo normal. Accel y los demás modelos conservan temporalmente sus
perfiles de prueba hasta contar con un mapa de identidad y flujo verificados.

## Catalogo de identidad

El catalogo legible esta en [CATALOGO.md](CATALOGO.md) y la version para programas
en [data/catalogo.json](data/catalogo.json). Solo contienen identidad
(familia/version/ID/nombre), evidencia y fuentes; no incluyen estadisticas.
La clave no es un numero aislado: siempre se necesita la familia y, cuando
corresponde, la version o base de indices.

Ver cobertura actual y familias:

```powershell
python .\beta_link.py --catalogo
```

Las capturas completas de `--intercambiar` ahora consultan el catalogo
automaticamente y guardan el resultado junto a los paquetes originales.

Para comprobar una captura anterior sin conectar ni iniciar una batalla:

```powershell
python .\beta_link.py --identificar --modelo penx --codigo 0249-E589-0009-F1F9
python .\beta_link.py --identificar --modelo pen20 --codigo 008E-3A2E-064E-04FE-2E0E-000E-000E-000E-000E-D0FE
```

Consulta directa de un ID (acepta decimal y 0xhex):

```powershell
python .\catalogo.py --modelo pen20 --id 232
python .\catalogo.py --modelo dmx --version XA --id 6
```

DMX con indice 0 no se identifica por nombre: el dispositivo puede ocultar
su identidad en ese intercambio. Este lector no usa estadisticas para adivinarla.
Una captura incompleta o con checksum incorrecto tampoco se etiqueta como exacta.
En Pen20, nueve paquetes pueden indicar que se perdio el encabezado/otro paquete;
se conservan como captura parcial y no se desplazan automaticamente.

Pendulum original .0/.5 puede compartir slot entre distintas especies. Se muestran
los candidatos en vez de elegir uno. PenX tiene por ahora solo tres IDs verificados
(Kuwagamon X, Okuwamon X y Triceramon X); el resto del roster se marca PENDIENTE.
Progress, Mini y Accel tienen roster. En Mini, Koromon 1.0 ya tiene un slot
observado localmente; los demas IDs de Mini y los de Accel permanecen pendientes.
Accel tambien tiene un perfil de batalla X de tres pines. Las otras familias
sin mapa verificado se enumeran al final del catalogo.
No se afirma cobertura universal de todos los V-Pets/reediciones.

Reconstruir desde las fuentes publicas (requiere internet):

```powershell
python .\tools\actualizar_catalogo.py
```

El generador comprueba el formato de las tablas y conserva fuente y SHA-256.
Las referencias verificadas con tus aparatos se incorporan explicitamente;
no se generan IDs a partir del orden de los perfiles antiguos. En DMOG se usa
el esquema documentado de slots y en Pendulum original el campo Slot publicado.

Requiere Python y `python -m pip install -r requirements.txt`.

Consultar firmware:

```powershell
python .\beta_link.py
```

Escuchar sin responder:

```powershell
python .\beta_link.py --recibir --tipo V0
python .\beta_link.py --recibir --tipo X0
```

V0 usa tiempos de dos contactos, X0 los del Pendulum X de tres pines.
El adaptador fisico debe corresponder al aparato.

Intercambio activo de batalla (puede modificar el record del V-Pet):

```powershell
python .\beta_link.py --intercambiar --modelo dmx
python .\beta_link.py --intercambiar --modelo penx
python .\beta_link.py --intercambiar --modelo accel
python .\beta_link.py --intercambiar --modelo pen20
python .\beta_link.py --intercambiar --modelo dm20
python .\beta_link.py --intercambiar --modelo penz
python .\beta_link.py --intercambiar --modelo penog
python .\beta_link.py --intercambiar --modelo dmog --version 1
```

Batalla ponderada con detección automática del Pendulum X:

```powershell
python .\beta_link.py --batalla-ponderada --modelo penx --rival-visual Gekomon
```

Ejecuta solo una prueba a la vez. En DMX usa CONNECT > X; en Pendulum X
selecciona batalla y completa su preparacion. El Beta Link inicia automaticamente
con un rival de prueba. Une los contactos cuando el aparato este listo para
conectar. Mantenerlos hasta terminar el intercambio.

En Digimon Accel selecciona CONNECT > BATTLE > X (segunda opcion). Usa su
conector de tres pines con timing X; no es una conexion infrarroja. El rival de
prueba PenX tambien es compatible con Accel, Mini e iC. La captura se valida y
se conserva. En Mini 1.0, el slot observado de Koromon ya se identifica; los
demas slots esperan una captura comprobada antes de asignar una especie.

En Pendulum 20th, selecciona la batalla de Ver.20th individual (SINGLE),
elige un Digimon y completa las sacudidas. Los modos Pendulum Original/OLD,
OTHER, TAG y Jogress usan otros intercambios; no son el objetivo de pen20.

El perfil dmx espera seis paquetes recibidos y seis enviados. Los perfiles penx
y accel esperan cuatro de cada lado. El perfil pen20 espera diez de cada lado y usa
el sondeo de Single Battle del conversor de Humulos. Se comprueba cantidad y
alternancia; el decodificador comprueba formato y checksum antes de identificar.

El timing por si solo no determina la familia: otros V-Pets requieren perfiles
distintos. Los perfiles activos cubren DMOG 1-5, Pendulum original, DM20,
Pendulum 20th, DMX, Pendulum Z/X y Digimon Accel. Los perfiles agregados fuera de los tres
modelos que probaste todavia no se han validado fisicamente aqui.

### Digivice Ver. Complete (experimental)

```powershell
python .\beta_link.py --intercambiar --modelo dcomplete --puerto COM5 --espera 120
```

Selecciona CONNECT y el personaje para batalla. Manten los contactos unidos y
deja al Digivice esperando: Beta Link inicia, no pulses OK simultaneamente.
El sondeo intenta una batalla clasica de dos paquetes usando el rival
`V1-FC03-FD02`, publicado en los [codigos de DMComm](https://github.com/dmcomm/dmcomm-project/blob/main/codes.txt).
Esta eleccion es una prueba de compatibilidad, no un intercambio nativo del
Ver. Complete ya verificado fisicamente. Si solo llega `FB04`, es parcial.
Se guardan los datos en `capturas.jsonl`, sin mezclarlos entre intentos.
Aunque lleguen dos paquetes, aun no hay mapa publico verificado para identificar al
personaje: NO se aplica el catalogo del V-Pet original. Se muestran los campos
crudos del formato clasico solo si ambos paquetes tienen bytes complementarios.
Puede cambiar el record de batallas. No envia codigos de emblemas, reseteo ni
desbloqueos. No se actualiza el firmware.

Referencia del [formato clasico](https://dmcomm.github.io/orig_battle/).
La implementacion [F-Com](https://github.com/TylerWilley/flipper-f-com#overview)
incluye Ver. Complete entre sus aparatos probados, pero eso no valida este
sondeo concreto ni el circuito de nuestro Beta Link.

#### Catalogo local del Ver. Complete

`data/complete_local.json` guarda observaciones confirmadas manualmente. Empieza
sin nombres asignados: no se deducen IDs del orden de una lista de personajes.
Para anotar el personaje que seleccionaste en la ultima captura completa:

```powershell
python .\catalogo_complete.py --nombre "NOMBRE QUE SELECCIONASTE"
```

Tambien puedes elegir una captura concreta que ya exista en `capturas.jsonl`:

```powershell
python .\catalogo_complete.py --nombre "NOMBRE QUE SELECCIONASTE" --codigo FB04-2ED1
```

El registro conserva el codigo y la fecha de captura. Las siguientes lecturas
consultan automaticamente los candidatos locales por version de comunicacion y
slot, sin confundir mejora ni resultado de batalla con identidad. Un solo nombre
observado no demuestra que el slot sea exclusivo: siempre se etiqueta como
candidato local. Si dos personajes comparten clave, se conservan ambos.
Este archivo es independiente del catalogo publico y no se borra al regenerarlo
con `tools/actualizar_catalogo.py`. No modifica capturas previas ni el Digivice.

Consulta una captura de nuevo sin conectar hardware:

```powershell
python .\beta_link.py --identificar --modelo dcomplete --codigo FB04-2ED1
```

### Color (experimental)

```powershell
python .\beta_link.py --intercambiar --modelo dmc
python .\beta_link.py --intercambiar --modelo penc
```

Tambien hay perfiles de prueba para `dmh`, `dmgz`, `dmxw` y `pengz`.
Se reciben dos bloques de 128 bits (32 digitos hex) por lado. Requieren
firmware DMComm y circuito compatibles con Color; el hecho de que tu Beta Link
lea V/X no confirma que soporte C. No se flashea firmware automaticamente.
Consulta los requisitos en la [pagina de DigiROMs DMC](https://humulos.com/digimon/dmc/digirom/).
El identificador puede consultarse offline aunque no dispongas de ese hardware.

Cada intento con datos recibidos se agrega a `capturas.jsonl`: fecha, modelo,
comando, linea cruda, paquetes recibidos, enviados y estado completo/parcial.
Los intentos parciales se conservan separados; no se concatenan como si fueran
una sola batalla. Al terminar o cancelar se vuelve al modo pasivo.

Opciones comunes: `--puerto COM5`, `--espera 60`, `--registro capturas.jsonl`.
En intercambio, `--modelo` determina automaticamente el timing; `--tipo` solo
se usa con `--recibir`.

Fuentes de los rivales y protocolo:

- [DMX: Agumon X de prueba](https://humulos.com/digimon/dmx/digirom/)
- [Pendulum X: Kuwagamon X de prueba](https://github.com/dmcomm/dmcomm-project/blob/main/codes.txt)
- [Pen20: sondeo Single Battle](https://humulos.com/digimon/0NL1NE/converter/)
- [Formato Pen20 de diez paquetes](https://wiki.humulos.com/wiki/Pen20th_battle_DigiROM_format)
- [Comandos DMComm y significado de r:/s:](https://github.com/dmcomm/dmcomm-project)

## Batallas Alpha por familia

El firmware Alpha v2 realiza deteccion, calculo ponderado y respuesta dentro de
una sola conexion para `penx`, `dmx`, `penz`, `dmc`, `penc`, `dmh`, `dmgz`,
`dmxw` y `pengz`. El Digimon fisico se obtiene siempre de los paquetes del COM;
solo se elige manualmente el luchador web.

```powershell
python .\beta_link.py --batalla-ponderada --modelo dmx --rival-visual Gekomon
python .\beta_link.py --batalla-ponderada --modelo dmc --rival-visual Gekomon
```

DMX, Pendulum Z y Pendulum X usan sus campos documentados de resultado. DMC,
Monster Hunter Color, Godzilla Color y Xros Wars Color eligen automaticamente
un combatiente real del catalogo DMC con el mismo nivel y atributo que la
mascara del Reference Book. El firmware envia su version, slot, potencia base y
atributo antes de que comience el contacto; el aparato Color resuelve la batalla.
Pendulum Color conserva temporalmente su perfil Color propio experimental.
