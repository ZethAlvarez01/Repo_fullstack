"""Interfaz web local para controlar Beta Link desde el navegador."""

import asyncio
import json
import sys
import time
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path

import serial
import uvicorn
from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from serial.tools import list_ports

from beta_link import BATALLAS_ALPHA, PERFILES, abrir_serial, encontrar_puerto, leer_beta_link
from battle_probability import calculate_battle_probability, load_battle_config
from catalogo import cargar_catalogo
from dmc_profiles import choose_dmc_proxy
from pen20_profiles import choose_pen20_proxy
from reference_book import find_profiles, image_path, reference_names, reference_status


ROOT = Path(__file__).resolve().parent
CAPTURAS = ROOT / "capturas.jsonl"
WEB = ROOT / "web"
DMC_PROXY_MODELS = {"dmc", "dmh", "dmgz", "dmxw"}


class BattleRequest(BaseModel):
    model: str
    port: str | None = None
    wait: float = Field(default=60, gt=0, le=600)
    version: str | None = None
    fighter: str | None = Field(default=None, max_length=120)
    fighter_variant: int = Field(default=0, ge=0)
    fighter_stat_modifier: float = Field(default=0, ge=-1, le=1)


class BattleProbabilityRequest(BaseModel):
    attackerLevel: str | None = None
    attackerAttribute: str | None = None
    attackerHasXAntibody: bool = False
    attackerStatModifier: float = 0
    defenderLevel: str | None = None
    defenderAttribute: str | None = None
    defenderHasXAntibody: bool = False
    defenderStatModifier: float = 0


class ListenRequest(BaseModel):
    signal_type: str = "V0"
    port: str | None = None
    wait: float = Field(default=60, gt=0, le=600)


class ProbeRequest(BaseModel):
    port: str | None = None


class OperationManager:
    def __init__(self):
        self.process: asyncio.subprocess.Process | None = None
        self.task: asyncio.Task | None = None
        self.operation: dict | None = None
        self.listeners: set[asyncio.Queue] = set()
        self.recent = deque(maxlen=250)
        self.lock = asyncio.Lock()

    @property
    def running(self):
        return self.process is not None and self.process.returncode is None

    def snapshot(self):
        return {"running": self.running, "operation": self.operation, "recent": list(self.recent)}

    async def emit(self, event):
        self.recent.append(event)
        for queue in tuple(self.listeners):
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                pass

    async def start(self, args, operation):
        async with self.lock:
            if self.running:
                raise HTTPException(409, "Ya hay una operacion activa.")
            self.recent.clear()
            self.operation = operation
            self.process = await asyncio.create_subprocess_exec(
                sys.executable,
                "-u",
                str(ROOT / "beta_link.py"),
                *args,
                cwd=str(ROOT),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            await self.emit({"type": "operation", "status": "started", **operation})
            self.task = asyncio.create_task(self._pump())

    async def _pump(self):
        process = self.process
        try:
            while process and process.stdout:
                raw = await process.stdout.readline()
                if not raw:
                    break
                await self.emit({"type": "line", "text": raw.decode("utf-8", errors="replace").rstrip()})
            code = await process.wait() if process else 1
            await self.emit({"type": "operation", "status": "finished", "exit_code": code})
        finally:
            self.process = None
            self.operation = None

    async def cancel(self):
        async with self.lock:
            if not self.running:
                return False
            process = self.process
            operation = dict(self.operation or {})
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=3)
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
            await self.emit({"type": "operation", "status": "cancelled"})
            if operation.get("stop") and operation.get("port"):
                await asyncio.to_thread(_send_stop, operation["port"], operation["stop"])
            return True


class UsbSerialBridge:
    """Puente binario entre WebUSB del navegador y pyserial por TCP local."""

    def __init__(self):
        self.websocket: WebSocket | None = None
        self.server: asyncio.AbstractServer | None = None
        self.serial_writer: asyncio.StreamWriter | None = None
        self.send_lock = asyncio.Lock()
        self.port: int | None = None
        self.channel_send_json = None
        self.channel_send_bytes = None

    @property
    def connected(self):
        return self.websocket is not None and self.server is not None

    @property
    def serial_url(self):
        if not self.connected or self.port is None:
            raise RuntimeError("Conecta primero el Beta Link USB desde este navegador.")
        return f"socket://127.0.0.1:{self.port}"

    async def _send_json(self, payload):
        if self.websocket is None:
            return
        if self.channel_send_json is not None:
            await self.channel_send_json(payload)
            return
        async with self.send_lock:
            await self.websocket.send_json(payload)

    async def _send_bytes(self, payload):
        if self.websocket is None:
            return
        if self.channel_send_bytes is not None:
            await self.channel_send_bytes(payload)
            return
        async with self.send_lock:
            await self.websocket.send_bytes(payload)

    async def _handle_serial(self, reader, writer):
        if self.serial_writer is not None:
            writer.close()
            await writer.wait_closed()
            return
        self.serial_writer = writer
        try:
            await self._send_json({"type": "serial", "status": "open"})
            while data := await reader.read(4096):
                await self._send_bytes(data)
        except (ConnectionError, RuntimeError, WebSocketDisconnect):
            pass
        finally:
            if self.serial_writer is writer:
                self.serial_writer = None
            writer.close()
            try:
                await writer.wait_closed()
            except ConnectionError:
                pass

    async def open_channel(self, websocket, send_json=None, send_bytes=None):
        if self.connected:
            raise RuntimeError("Otro navegador ya controla el Beta Link USB.")
        self.websocket = websocket
        self.channel_send_json = send_json
        self.channel_send_bytes = send_bytes
        self.server = await asyncio.start_server(self._handle_serial, "127.0.0.1", 0)
        self.port = self.server.sockets[0].getsockname()[1]
        await self._send_json({"type": "bridge", "status": "ready"})

    async def receive_bytes(self, payload):
        if payload and self.serial_writer is not None:
            self.serial_writer.write(payload)
            await self.serial_writer.drain()

    async def attach(self, websocket):
        await websocket.accept()
        try:
            await self.open_channel(websocket)
        except RuntimeError as error:
            await websocket.send_json({"type": "error", "message": str(error)})
            await websocket.close(code=1013)
            return
        try:
            while True:
                message = await websocket.receive()
                if message["type"] == "websocket.disconnect":
                    break
                payload = message.get("bytes")
                await self.receive_bytes(payload)
        except (ConnectionError, RuntimeError, WebSocketDisconnect):
            pass
        finally:
            await self.close()

    async def close(self):
        writer, self.serial_writer = self.serial_writer, None
        if writer is not None:
            writer.close()
            try:
                await writer.wait_closed()
            except ConnectionError:
                pass
        server, self.server = self.server, None
        if server is not None:
            server.close()
            await server.wait_closed()
        self.websocket = None
        self.port = None
        self.channel_send_json = None
        self.channel_send_bytes = None


def _send_stop(port, command):
    try:
        with abrir_serial(port, baudrate=9600, timeout=0.2) as connection:
            time.sleep(2.2)
            connection.write((command + "\n").encode("ascii"))
            connection.flush()
    except (serial.SerialException, OSError):
        pass


def available_ports():
    return [
        {
            "device": item.device,
            "description": item.description,
            "vid": item.vid,
            "pid": item.pid,
            "is_beta_link": item.vid == 0x1A86 and item.pid in (0x7523, 0x5523),
        }
        for item in list_ports.comports()
    ]


def resolve_port(port):
    if port == "webusb":
        try:
            return usb_bridge.serial_url
        except RuntimeError as error:
            raise HTTPException(400, str(error)) from error
    if port:
        return port
    try:
        return encontrar_puerto()
    except RuntimeError as error:
        raise HTTPException(400, str(error)) from error


manager = OperationManager()
usb_bridge = UsbSerialBridge()


@asynccontextmanager
async def lifespan(_app):
    yield
    if manager.running:
        await manager.cancel()
    await usb_bridge.close()


app = FastAPI(title="Digimon Alpha — Beta Link", lifespan=lifespan)


@app.get("/api/status")
async def status():
    catalog = cargar_catalogo()["familias"]
    models = []
    for key, profile in PERFILES.items():
        family = catalog.get(key, {})
        models.append({
            "key": key,
            "name": family.get("nombre", profile["nombre"]),
            "packets": profile["paquetes"],
            "experimental": "experimental" in profile["nombre"].casefold(),
            "real_battle": key in BATALLAS_ALPHA,
            "result_mode": (
                "native_proxy" if key in DMC_PROXY_MODELS or key == "pen20"
                else "experimental" if key in ("penc", "pengz")
                else "verified"
            ),
        })
    return {
        "ports": available_ports(),
        "usb_bridge": {"connected": usb_bridge.connected},
        "models": models,
        "reference_book": reference_status(),
        **manager.snapshot(),
    }


@app.websocket("/api/usb-serial")
async def usb_serial(websocket: WebSocket):
    await usb_bridge.attach(websocket)


@app.post("/api/probe")
async def probe(request: ProbeRequest):
    port = resolve_port(request.port)
    if manager.running:
        raise HTTPException(409, "Termina la operacion activa antes de consultar el firmware.")
    try:
        response = await asyncio.to_thread(leer_beta_link, port)
    except (serial.SerialException, RuntimeError, OSError) as error:
        raise HTTPException(400, str(error)) from error
    return {"port": port, "response": response, "confirmed": "dmcomm" in response.casefold()}


@app.post("/api/battle", status_code=202)
async def battle(request: BattleRequest):
    if request.model not in PERFILES:
        raise HTTPException(400, "Modelo sin perfil de intercambio.")
    port = resolve_port(request.port)
    profile = PERFILES[request.model]
    if request.model not in BATALLAS_ALPHA:
        raise HTTPException(400, "Este modelo aun no admite una batalla Alpha de una sola conexion.")
    if not request.fighter:
        raise HTTPException(400, "Elige el rival web en el Reference Book.")
    profiles = find_profiles(request.fighter)
    if not profiles:
        raise HTTPException(400, "El rival elegido no existe en el Reference Book.")
    if request.fighter_variant >= len(profiles):
        raise HTTPException(400, "La variante elegida no existe en el Reference Book.")
    selected_fighter = profiles[request.fighter_variant]
    proxy = None
    args = [
        "--batalla-ponderada", "--modelo", request.model,
        "--puerto", port, "--espera", str(request.wait),
        "--registro", str(CAPTURAS),
        "--rival-visual", request.fighter,
        "--rival-variante", str(request.fighter_variant),
        "--modificador-rival", str(request.fighter_stat_modifier),
    ]
    if request.model in DMC_PROXY_MODELS:
        try:
            proxy = choose_dmc_proxy(
                selected_fighter.get("level") or "Unknown",
                selected_fighter.get("attribute") or "Free",
                selected_fighter.get("name") or request.fighter,
            )
        except ValueError as error:
            raise HTTPException(400, str(error)) from error
        args.extend(["--dmc-proxy-id", proxy["id"]])
    elif request.model == "pen20":
        try:
            proxy = choose_pen20_proxy(
                selected_fighter.get("level") or "Unknown",
                selected_fighter.get("attribute") or "Free",
                selected_fighter.get("name") or request.fighter,
            )
        except ValueError as error:
            raise HTTPException(400, str(error)) from error
        args.extend(["--pen20-proxy-id", proxy["id"]])
    await manager.start(args, {
        "kind": "battle",
        "model": request.model,
        "port": port,
        "stop": "0",
        "fighter": request.fighter,
        "fighter_variant": request.fighter_variant,
        "protocol_fighter": proxy["name"] if proxy else None,
    })
    response = {
        "started": True,
        "model": request.model,
        "port": port,
        "fighter": request.fighter,
    }
    if proxy:
        response["protocol_fighter"] = {
            key: proxy[key]
            for key in ("id", "name", "level", "attribute", "base_power")
        }
    return response


@app.post("/api/battle-probability")
async def battle_probability(request: BattleProbabilityRequest):
    try:
        return calculate_battle_probability(request.model_dump())
    except ValueError as error:
        raise HTTPException(400, str(error)) from error


@app.get("/api/battle-probability/config")
async def battle_probability_config():
    config = load_battle_config()
    return {
        "baseProbability": config["baseProbability"],
        "levelStep": config["levelStep"],
        "levelDifferenceModifiers": config.get("levelDifferenceModifiers", {}),
        "attributeAdvantage": config["attributeAdvantage"],
        "xAntibodyBonus": config["xAntibodyBonus"],
        "minimumProbability": config["minimumProbability"],
        "maximumProbability": config["maximumProbability"],
        "nonCombatantLevels": config.get("nonCombatantLevels", []),
        "nonCombatantWinProbability": config.get(
            "nonCombatantWinProbability", config["minimumProbability"]
        ),
        "levelRanks": config["levelRanks"],
        "attributeAdvantages": config["attributeAdvantages"],
        "neutralAttributes": config["neutralAttributes"],
        "noise": config.get("noise", {}),
    }


@app.post("/api/listen", status_code=202)
async def listen(request: ListenRequest):
    signal_type = request.signal_type.upper()
    if signal_type not in ("V0", "X0", "C0"):
        raise HTTPException(400, "El tipo debe ser V0, X0 o C0.")
    port = resolve_port(request.port)
    args = ["--recibir", "--tipo", signal_type, "--puerto", port, "--espera", str(request.wait)]
    await manager.start(args, {"kind": "listen", "signal_type": signal_type, "port": port, "stop": signal_type})
    return {"started": True, "signal_type": signal_type, "port": port}


@app.post("/api/cancel")
async def cancel():
    return {"cancelled": await manager.cancel()}


@app.post("/api/reset")
async def reset_interface():
    """Cancela la operacion y descarta el historial efimero de la consola."""
    cancelled = await manager.cancel()
    async with manager.lock:
        manager.recent.clear()
    return {"reset": True, "cancelled": cancelled}


@app.get("/api/catalog")
async def catalog(query: str = Query(default="", max_length=80), model: str = Query(default="", max_length=20)):
    families = cargar_catalogo()["familias"]
    needle = query.strip().casefold()
    rows = []
    for key, family in families.items():
        if model and key != model:
            continue
        for entry in family["entradas"]:
            if needle and needle not in entry["nombre"].casefold():
                continue
            rows.append({"model": key, "family": family["nombre"], **entry})
    summaries = [
        {
            "key": key,
            "name": family["nombre"],
            "total": len(family["entradas"]),
            "mapped": sum(entry["identificador"] is not None for entry in family["entradas"]),
        }
        for key, family in families.items()
    ]
    return {"families": summaries, "entries": rows[:500], "total_matches": len(rows)}


@app.get("/api/captures")
async def captures(limit: int = Query(default=50, ge=1, le=500)):
    if not CAPTURAS.exists():
        return {"captures": []}
    parsed = []
    for number, line in enumerate(CAPTURAS.read_text(encoding="utf-8").splitlines(), 1):
        try:
            item = json.loads(line)
            item["line"] = number
            parsed.append(item)
        except json.JSONDecodeError:
            continue
    return {"captures": list(reversed(parsed[-limit:]))}


@app.get("/api/reference/{name}")
async def reference_profile(name: str):
    profiles = find_profiles(name)
    if not profiles:
        raise HTTPException(404, f"No hay ficha del Reference Book para {name}.")
    return {"requested": name, "profiles": profiles}


@app.get("/api/reference-list")
async def reference_list():
    return {"entries": reference_names()}


@app.get("/api/reference-image/{filename}")
async def reference_image(filename: str):
    path = image_path(filename)
    if not path:
        raise HTTPException(404, "Imagen no disponible.")
    return FileResponse(path)


@app.websocket("/api/events")
async def events(websocket: WebSocket):
    await websocket.accept()
    queue = asyncio.Queue(maxsize=300)
    send_lock = asyncio.Lock()

    async def send_json(payload):
        async with send_lock:
            await websocket.send_json(payload)

    async def send_bytes(payload):
        async with send_lock:
            await websocket.send_bytes(payload)

    manager.listeners.add(queue)
    try:
        await send_json({"type": "snapshot", **manager.snapshot()})
        while True:
            event_task = asyncio.create_task(queue.get())
            receive_task = asyncio.create_task(websocket.receive())
            done, pending = await asyncio.wait(
                (event_task, receive_task), return_when=asyncio.FIRST_COMPLETED
            )
            for task in pending:
                task.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
            if receive_task in done:
                message = receive_task.result()
                if message["type"] == "websocket.disconnect":
                    break
                if message.get("bytes") is not None:
                    await usb_bridge.receive_bytes(message["bytes"])
                elif message.get("text"):
                    command = json.loads(message["text"])
                    if command.get("type") == "usb-connect":
                        try:
                            await usb_bridge.open_channel(websocket, send_json, send_bytes)
                        except RuntimeError as error:
                            await send_json({"type": "usb-error", "message": str(error)})
                    elif command.get("type") == "usb-disconnect" and usb_bridge.websocket is websocket:
                        await usb_bridge.close()
            if event_task in done:
                await send_json(event_task.result())
    except WebSocketDisconnect:
        pass
    finally:
        manager.listeners.discard(queue)
        if usb_bridge.websocket is websocket:
            await usb_bridge.close()


app.mount("/", StaticFiles(directory=WEB, html=True), name="web")


if __name__ == "__main__":
    # Escucha en todas las interfaces para permitir el acceso desde otro
    # dispositivo de la misma red (por ejemplo, un telefono por Wi-Fi).
    uvicorn.run("web_app:app", host="0.0.0.0", port=8000, reload=False)
