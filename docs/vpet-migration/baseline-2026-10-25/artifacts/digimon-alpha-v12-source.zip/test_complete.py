import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from catalogo import identificar
from catalogo_complete import candidatos, registrar


class CompleteTests(unittest.TestCase):
    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporal.cleanup)
        self.ruta = Path(self.temporal.name) / "complete.json"
        self.captura = {"modelo": "dcomplete", "completo": True,
                        "recibidos": ["FB04", "2ED1"], "fecha": "prueba", "comando": "V1-FC03-FD02"}

    def test_confirmacion_no_se_convierte_en_identidad_verificada(self):
        # Nombre sintetico: no es un mapeo real de este slot.
        registrar("Personaje de prueba", self.captura, self.ruta)
        with patch("catalogo_complete.RUTA", self.ruta):
            datos = identificar("dcomplete", "FB04-2ED1")[0]
        self.assertEqual(datos["nombres"], ["Personaje de prueba"])
        self.assertEqual(datos["estado"], "candidato_local")
        self.assertEqual(datos["version"], "13")

    def test_colision_conserva_ambos_nombres(self):
        registrar("Personaje A", self.captura, self.ruta)
        registrar("Personaje B", self.captura, self.ruta)
        self.assertEqual(candidatos("13", 4, self.ruta), ["Personaje A", "Personaje B"])
        self.assertEqual(candidatos("12", 4, self.ruta), [])
        self.assertEqual(candidatos("13", 3, self.ruta), [])

    def test_mejora_y_resultado_no_cambian_clave(self):
        registrar("Personaje A", self.captura, self.ruta)
        with patch("catalogo_complete.RUTA", self.ruta):
            datos = identificar("dcomplete", "EB14-2DD2")[0]
        self.assertEqual(datos["nombres"], ["Personaje A"])

    def test_registro_duplicado_no_duplica_observacion(self):
        registrar("Personaje A", self.captura, self.ruta)
        registrar("Personaje A", self.captura, self.ruta)
        datos = json.loads(self.ruta.read_text(encoding="utf-8"))
        self.assertEqual(len(datos["observaciones"]), 1)

    def test_rechaza_capturas_invalidas_y_parciales(self):
        for cambios in ({"completo": False}, {"modelo": "dmog"}, {"recibidos": ["FB04"]}, {"recibidos": ["FB04", "0000"]}):
            with self.assertRaises(ValueError):
                registrar("Personaje A", {**self.captura, **cambios}, self.ruta)
        self.assertFalse(self.ruta.exists())


if __name__ == "__main__":
    unittest.main()
