import unittest

from beta_link import analizar_intercambio
from catalogo import (
    buscar,
    cargar_catalogo,
    identificar,
    identificar_inicio_batalla,
    identificar_paquete_inicial_penx,
    palabras,
)


class IdentidadTests(unittest.TestCase):
    def nombre(self, modelo, codigo, esperado, version=None):
        datos = identificar(modelo, codigo, version)
        self.assertEqual(datos[0]["nombres"], [esperado])

    def test_captura_real_okuwa(self):
        self.nombre("penx", "0249-E589-0009-F1F9", "Okuwamon X")

    def test_confirmacion_local_triceramon(self):
        self.nombre("penx", "1269-4709-5409-31F9", "Triceramon X")

    def test_primer_paquete_penx_identifica_triceramon(self):
        datos = identificar_paquete_inicial_penx("1269")
        self.assertEqual(datos["estado"], "identificado")
        self.assertEqual(datos["nombres"], ["Triceramon X"])

    def test_captura_real_voltobautamon(self):
        self.nombre("pen20", "008E-3A2E-064E-04FE-2E0E-000E-000E-000E-000E-D0FE", "Voltobautamon")

    def test_pen20_desplazado_no_inventa_identidad(self):
        datos = identificar("pen20", "3A6E-024E-010E-4F8E-000E-000E-000E-000E-C0FE")
        self.assertEqual(datos[0]["estado"], "no_identificable")

    def test_pen20_se_identifica_con_dos_paquetes_iniciales(self):
        datos = identificar_inicio_batalla("pen20", "008E-3A2E")
        self.assertEqual(datos["nombres"], ["Voltobautamon"])

    def test_dmx_huella_confirmada_identifica_beelzebumon_x(self):
        datos = identificar("dmx", "4B0E-802E-18AE-393E-2C4E-71FE")
        self.assertEqual(datos[0]["nombres"], ["Beelzebumon X"])
        self.assertEqual(datos[0]["evidencia"], ["confirmado_por_usuario"])
        self.assertEqual(datos[0]["nivel"], "Mega")
        self.assertEqual(datos[0]["atributo"], "Virus")
        self.assertTrue(datos[0]["x_antibody"])

    def test_dmx_xb_huella_identifica_beel_starmon_x(self):
        datos = identificar("dmx", "4A1E-802E-549E-397E-2D2E-500E")
        self.assertEqual(datos[0]["nombres"], ["Beel Starmon X"])
        self.assertEqual(datos[0]["version"], "XB")
        self.assertEqual(datos[0]["nivel"], "Mega")
        self.assertEqual(datos[0]["atributo"], "Virus")

    def test_xros_mini_identifica_por_version_y_slot(self):
        inicial = identificar_inicio_batalla("xrosmini", "1017")
        completa = identificar("xrosmini", "1017-0097-1567-B1D7")[0]
        self.assertEqual(inicial["nombres"], ["Shoutmon"])
        self.assertEqual(completa["nombres"], ["Shoutmon"])
        blue = identificar_inicio_batalla("xrosmini", "2017")
        self.assertEqual(blue["nombres"], ["Greymon (2010 Anime Version)"])
        self.assertEqual(blue["evidencia"], ["confirmado_por_usuario"])

    def test_mini_identifica_koromon_por_captura_real(self):
        inicial = identificar_inicio_batalla("mini", "0019")
        completa = identificar("mini", "0019-1109-FFF9-E029")[0]
        self.assertEqual(inicial["nombres"], ["Koromon"])
        self.assertEqual(inicial["version"], "0")
        self.assertEqual(inicial["identificador"], 1)
        self.assertEqual(completa["nombres"], ["Koromon"])
        self.assertEqual(completa["evidencia"], ["captura_local_y_slot_roster"])

    def test_agumon_x_documentado(self):
        self.nombre("dmx", "800E-218E-483E-142E-010E-A00E", "Agumon X")

    def test_dmx_se_identifica_con_los_dos_primeros_paquetes(self):
        datos = identificar_inicio_batalla("dmx", "800E-218E")
        self.assertEqual(datos["nombres"], ["Agumon X"])

    def test_mismo_id_distinta_version_no_se_mezcla(self):
        xa = {e["nombre"] for e in buscar("dmx", "XA", 6)}
        xb = {e["nombre"] for e in buscar("dmx", "XB", 6)}
        self.assertIn("Agumon X", xa)
        self.assertNotEqual(xa, xb)

    def test_dmog_requiere_version_fisica(self):
        self.nombre("dmog", "FC03-FD02", "Agumon", "1")
        self.assertEqual(identificar("dmog", "FC03-FD02")[0]["nombres"], [])

    def test_slots_pendulum_documentados(self):
        self.nombre("penog", "211F-000F-080F-EABF", "Fantomon")
        self.assertIn("Ikkakumon", {e["nombre"] for e in buscar("penog", "1", 6)})

    def test_pendulum_medio_comparte_slot(self):
        nombres = {e["nombre"] for e in buscar("penog", "0", 7)}
        self.assertEqual(nombres, {"Tortamon", "Tailmon"})

    def test_dmc_documentado_y_checksum(self):
        codigo = "C1-47444C4300000000000B007300019406-47444C4300020002000000000000938B"
        self.nombre("dmc", codigo, "Metal Greymon (Virus)")
        malo = codigo.replace("9406", "9407")
        self.assertEqual(identificar("dmc", malo)[0]["estado"], "no_identificable")

    def test_penc_documentado(self):
        self.nombre("penc", "C1-47444470001000000002001400038BDD-47444470001200390000000000028C01", "Tentomon")

    def test_color_se_identifica_con_el_primer_bloque(self):
        dmc = identificar_inicio_batalla("dmc", "47444C4300000000000B007300019406")
        penc = identificar_inicio_batalla("penc", "47444470001000000002001400038BDD")
        self.assertEqual(dmc["nombres"], ["Metal Greymon (Virus)"])
        self.assertEqual(penc["nombres"], ["Tentomon"])

    def test_color_se_identifica_con_consulta_compacta_del_firmware(self):
        dmc = identificar_inicio_batalla("dmc", "0000000A")
        self.assertEqual(dmc["estado"], "identificado")
        self.assertEqual(dmc["nombres"], ["Numemon"])

    def test_salida_serial_no_mezcla_enviados_con_recibidos(self):
        self.assertEqual(palabras("s:0159 r:0249 s:4379 r:E589 t"), [0x0249, 0xE589])
        with self.assertRaises(ValueError):
            palabras("800E-218E-483E-142E-010E-@800E")

    def test_trama_color_no_se_cuenta_como_ocho_paquetes(self):
        a = "47444C4300000000000B007300019406"
        b = "47444C4300020002000000000000938B"
        datos = analizar_intercambio(f"s:{a} r:{a} s:{b} r:{b}", 2, 32)
        self.assertTrue(datos["completo"])
        self.assertEqual(len(datos["recibidos"]), 2)

    def test_catalogo_con_fuentes_y_sin_estadisticas(self):
        catalogo = cargar_catalogo()
        for modelo, familia in catalogo["familias"].items():
            self.assertTrue(familia["entradas"], modelo)
            for e in familia["entradas"]:
                self.assertTrue(e["nombre"].strip(), modelo)
                self.assertTrue(e["fuente"], modelo)
                self.assertFalse({"hp", "power", "base_hp", "base_power", "ataque", "nivel"} & e.keys())
                self.assertTrue(e["identificador"] is None or isinstance(e["identificador"], int))


if __name__ == "__main__":
    unittest.main()
