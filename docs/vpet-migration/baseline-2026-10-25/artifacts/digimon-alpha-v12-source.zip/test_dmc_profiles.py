import json
import unittest

from dmc_profiles import CATALOG_PATH, choose_dmc_proxy, find_dmc_proxies, load_dmc_profiles


class DmcProfilesTest(unittest.TestCase):
    def test_catalog_shape(self):
        catalog = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
        self.assertEqual(catalog["family"], "dmc")
        self.assertEqual(len(catalog["profiles"]), 90)
        self.assertEqual(sum(item["battle_eligible"] for item in catalog["profiles"]), 76)

    def test_known_wire_profiles(self):
        profiles = {item["display_id"]: item for item in load_dmc_profiles()}
        numemon = profiles["01-10"]
        self.assertEqual((numemon["level"], numemon["attribute"], numemon["base_power"]), ("Champion", "Virus", 40))
        self.assertEqual(numemon["responder_first_block"], "47444C4300010000000A0028000193BB")

        bancholeomon = profiles["03-17"]
        self.assertEqual((bancholeomon["level"], bancholeomon["attribute"], bancholeomon["base_power"]), ("Mega", "Vaccine", 180))
        self.assertEqual(bancholeomon["responder_first_block"], "47444C4300010002001100B400039452")

    def test_babies_and_cross_version_profiles_are_not_selectable(self):
        profiles = {item["display_id"]: item for item in load_dmc_profiles()}
        self.assertFalse(profiles["01-00"]["battle_eligible"])
        self.assertFalse(profiles["17-17"]["protocol_ready"])

    def test_finds_matching_mask(self):
        matches = find_dmc_proxies("Mega", "Vaccine")
        self.assertTrue(matches)
        self.assertTrue(all(item["level"] == "Mega" for item in matches))
        self.assertTrue(all(item["attribute"] == "Vaccine" for item in matches))
        self.assertIn("Bancho Leomon", {item["name"] for item in matches})

    def test_proxy_choice_is_stable_and_normalizes_special_levels(self):
        first = choose_dmc_proxy("Mega", "Vaccine", "Magnamon (X Antibody)")
        second = choose_dmc_proxy("Mega", "Vaccine", "Magnamon (X Antibody)")
        self.assertEqual(first["id"], second["id"])
        self.assertEqual((first["level"], first["attribute"]), ("Mega", "Vaccine"))
        self.assertEqual(choose_dmc_proxy("Armor", "Data", "Mask")["level"], "Champion")


if __name__ == "__main__":
    unittest.main()
