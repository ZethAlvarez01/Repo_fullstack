// DMComm v0.4.4 compatible firmware with opt-in Digimon Alpha battles.
// Normal V/X/Y/C, info and prong-test commands remain handled by the
// upstream SerialFollower. "1" preserves the original PenX Alpha mode.
// A0..A9 and B0..B1 select the interactive family profiles.

#if defined(ARDUINO_ARCH_AVR) && !defined(USB_PID) && (SERIAL_RX_BUFFER_SIZE < 128)
#error : require SERIAL_RX_BUFFER_SIZE=128
#endif

#define DMCOMM_BUILD_INFO F("name = \"dmcomm-arduino\"\r\nversion = \"v0.4.4\"\r\nboard = \"nano\"\r\nextension = \"digimon-alpha-family-battle-v12\"")
#include <DMComm.h>

using namespace DMComm;

// Un puente WebUSB remoto agrega dos tramos HTTPS. La lectura termina apenas
// llega W/P; este limite amplio solo evita elegir V-Pet antes de tiempo.
const uint16_t kAlphaDecisionTimeoutMillis = 1000;
const uint32_t kDefaultSerialBaud = 9600;
const uint32_t kColorAlphaSerialBaud = 115200;
const char kWebWinsDecision = 'W';
const char kVPetWinsDecision = 'P';

LED_Indicator led = LED_Indicator(13);
DComOutput output = DComOutput(A2, A1);
AnalogProngInput input = AnalogProngInput(A3, 5000, 10);
ProngTester prong_tester = ProngTester(output, input, input);
ClassicCommunicator classic_comm = ClassicCommunicator(output, input);
ColorCommunicator color_comm = ColorCommunicator(output, input);
Controller controller = Controller();
SerialFollower serial_follower = SerialFollower(controller, Serial);

bool readDecision(Stream& serial, bool announce=true) {
    uint32_t started = millis();
    while (millis() - started < kAlphaDecisionTimeoutMillis) {
        if (serial.available() == 0) continue;
        int value = serial.read();
        if (value == kWebWinsDecision || value == 'w') {
            if (announce) serial.println(F("alpha:decision:web"));
            return true;
        }
        if (value == kVPetWinsDecision || value == 'p') {
            if (announce) serial.println(F("alpha:decision:vpet"));
            return false;
        }
    }
    if (announce) serial.println(F("alpha:decision:timeout-vpet"));
    return false;
}

class AlphaClassicDigiROM : public BaseDigiROM {
public:
    AlphaClassicDigiROM(Stream& serial) : serial_(serial) { base_core_ = &core_; }

    void configure(char profile, bool legacy_turn_one=false, bool custom_pen20=false, const uint16_t custom_words[]=0) {
        profile_ = profile;
        legacy_turn_one_ = legacy_turn_one;
        custom_pen20_ = custom_pen20;
        if (custom_pen20 && custom_words) {
            for (uint8_t i = 0; i < 4; i ++) custom_words_[i] = custom_words[i];
        }
    }

    SignalType signal_type() {
        if (profile_ == '1') return kSignalTypeX;
        if (profile_ == 'M') return kSignalTypeY;
        return kSignalTypeV;
    }
    uint8_t turn() { return legacy_turn_one_ ? 1 : 2; }

    void prepare() {
        core_.prepare();
        packet_index_ = 0;
        response_count_ = 0;
        web_wins_ = false;
        physical_final_ = 0;
    }

    int16_t next(uint16_t buffer[], uint16_t buffer_size) {
        uint8_t count = profile_ == '0' ? 10
            : (profile_ == '1' || profile_ == 'M' ? 4
            : (profile_ == 'C' ? 2 : 6));
        if (buffer_size < 1 || packet_index_ >= count) return 0;

        uint16_t packet = 0;
        if (profile_ == '0' && custom_pen20_) {
            if (packet_index_ == 0) packet = custom_words_[0] & 0xFFF0;
            else if (packet_index_ == 1) packet = ((custom_words_[1] & 0xFF) << 6) | ((custom_words_[3] & 3) << 4);
            else if (packet_index_ == 4) packet = (custom_words_[2] & 0xFF) << 4;
            else if (packet_index_ == 9) {
                uint8_t physical_dodges = (physical_final_ >> 8) & 0x0F;
                uint8_t physical_hits = (physical_final_ >> 4) & 0x0F;
                packet = ((uint16_t)(~physical_dodges & 0x0F) << 8)
                    | ((uint16_t)(~physical_hits & 0x0F) << 4) | 0x000E;
                buffer[0] = core_.next(packet, 0, 0, 12, 12);
                packet_index_ ++;
                return 1;
            }
            packet |= 0x000E;
            buffer[0] = core_.next(packet);
        } else if (profile_ == '1') {
            static const uint16_t packets[3] = {0x0159, 0x4379, 0x0009};
            packet = packet_index_ < 3 ? packets[packet_index_] : (web_wins_ ? 0xC1F9 : 0xC009);
            buffer[0] = core_.next(packet);
        } else if (profile_ == 'M') {
            static const uint16_t weak_packets[3] = {0x1017, 0x0057, 0x0007};
            static const uint16_t strong_packets[3] = {0x1107, 0x0747, 0x3FF7};
            if (packet_index_ < 3) {
                buffer[0] = core_.next(web_wins_ ? strong_packets[packet_index_] : weak_packets[packet_index_]);
            }
            else buffer[0] = core_.next(0x0007, 0x0E00, 0x01F0, 12, 12);
        } else if (profile_ == 'C') {
            packet = packet_index_ == 0 ? 0xFC03 : (web_wins_ ? 0xFE01 : 0xFD02);
            buffer[0] = core_.next(packet);
        } else {
            static const uint16_t dmx_packets[3] = {0x800E, 0x218E, 0x483E};
            static const uint16_t penz_packets[5] = {0x836E, 0x212E, 0x288E, 0x182E, 0x018E};
            if (packet_index_ < 5) {
                if (profile_ == '2') {
                    if (packet_index_ < 3) packet = dmx_packets[packet_index_];
                    // DMX resolves the winner by remaining HP, not hit count
                    // alone. Use complete strong/weak profiles to avoid a
                    // high-HP opponent winning despite receiving five hits.
                    else if (packet_index_ == 3) packet = web_wins_ ? 0x3C2E : 0x022E;
                    else packet = web_wins_ ? 0x2FFE : 0x001E;
                } else packet = penz_packets[packet_index_];
                buffer[0] = core_.next(packet);
            } else {
                // Packet 6 carries the five hit bits; the top nibble is the
                // calculated check digit needed to reach remainder eight.
                // The weighted result controls the proxy's final hit pattern;
                // packets 4 and 5 above keep the remaining-HP result aligned.
                bool proxy_hits = web_wins_;
                packet = proxy_hits ? 0x01FE : 0x000E;
                buffer[0] = core_.next(packet, 0, 0, 8, 12);
            }
        }
        packet_index_ ++;
        return 1;
    }

    void store(uint16_t data[], ReceiveOutcome outcome) {
        core_.store(data, outcome);
        if (outcome.status != kStatusReceived) return;
        if (response_count_ < 2) identity_[response_count_] = data[0];
        response_count_ ++;
        if (profile_ == '0' && response_count_ == 10) physical_final_ = data[0];
        uint8_t identity_count = (profile_ == '1' || profile_ == 'M' || profile_ == 'C') ? 1 : 2;
        if (response_count_ != identity_count) return;

        serial_.print(F("alpha:q:"));
        for (uint8_t i = 0; i < identity_count; i ++) {
            if (i) serial_.print('-');
            printHex(serial_, identity_[i], 4);
        }
        serial_.println();
        serial_.flush();
        if (!custom_pen20_) web_wins_ = readDecision(serial_);
    }

private:
    Stream& serial_;
    ClassicCore core_;
    char profile_ = '1';
    bool legacy_turn_one_ = false;
    bool web_wins_ = false;
    bool custom_pen20_ = false;
    uint8_t packet_index_ = 0;
    uint8_t response_count_ = 0;
    uint16_t identity_[2] = {0, 0};
    uint16_t custom_words_[4] = {0, 0, 0, 0};
    uint16_t physical_final_ = 0;
};

class AlphaColorDigiROM : public BaseDigiROM {
public:
    AlphaColorDigiROM(Stream& serial) : serial_(serial) { base_core_ = &core_; }

    void configure(char profile, bool custom_profile=false, const uint16_t custom_words[]=0) {
        profile_ = profile;
        custom_profile_ = custom_profile;
        if (custom_profile && custom_words) {
            for (uint8_t i = 0; i < 4; i ++) custom_words_[i] = custom_words[i];
        }
    }
    SignalType signal_type() { return kSignalTypeC; }
    uint8_t turn() { return 2; }

    void prepare() {
        core_.prepare();
        block_index_ = 0;
        receive_count_ = 0;
        web_wins_ = false;
    }

    int16_t next(uint16_t buffer[], uint16_t buffer_size) {
        if (buffer_size < 8 || block_index_ >= 2) return 0;
        bool pendulum = profile_ == '5' || profile_ == '9';
        if (custom_profile_) {
            if (block_index_ == 0) {
                buffer[0] = 0x4744;
                buffer[1] = 0x4C43;
                buffer[2] = 0x0001;
                buffer[3] = custom_words_[0]; // DMC version, zero based
                buffer[4] = custom_words_[1]; // roster slot
                buffer[5] = custom_words_[2]; // published base power
                buffer[6] = custom_words_[3]; // attribute
            } else {
                buffer[0] = 0x4744;
                buffer[1] = 0x4C43;
                buffer[2] = 0x0003;
                buffer[3] = 0x0000;
                buffer[4] = 0x0000;
                buffer[5] = 0x0000;
                buffer[6] = 0x0000;
            }
            uint16_t sum = 0;
            for (uint8_t i = 0; i < 7; i ++) sum += buffer[i];
            buffer[7] = sum;
            core_.store_sent(buffer, 8);
            block_index_ ++;
            return 8;
        }
        // Color validates the complete profile, not just its additive checksum.
        // Use published DigiROM pairs instead of synthesizing power values.
        static const uint16_t dmc_weak[2][8] = {
            {0x4744, 0x4C43, 0x0001, 0x0002, 0x0002, 0x001E, 0x0003, 0x93AD}, // Andromon responder, power 30
            {0x4744, 0x4C43, 0x0003, 0x0000, 0x0000, 0x0000, 0x0000, 0x938A},
        };
        static const uint16_t dmc_strong[2][8] = {
            {0x4744, 0x4C43, 0x0001, 0x0002, 0x0011, 0x00B4, 0x0003, 0x9452}, // BanchoLeomon responder, power 180
            {0x4744, 0x4C43, 0x0003, 0x0006, 0x0000, 0x0000, 0x0000, 0x9390},
        };
        static const uint16_t penc_weak[2][8] = {
            {0x4744, 0x4470, 0x0011, 0x0000, 0x0002, 0x0014, 0x0003, 0x8BDE}, // Gottsumon responder, power 20
            {0x4744, 0x4470, 0x0013, 0x0039, 0x0000, 0x0000, 0x0002, 0x8C02},
        };
        const uint16_t (*response)[8] = web_wins_ ? dmc_strong : (pendulum ? penc_weak : dmc_weak);
        for (uint8_t i = 0; i < 8; i ++) buffer[i] = response[block_index_][i];
        core_.store_sent(buffer, 8);
        block_index_ ++;
        return 8;
    }

    void store(uint16_t data[], ReceiveOutcome outcome) {
        core_.store_received(data, outcome);
        if (outcome.status != kStatusReceived || outcome.result_length != 8) return;
        receive_count_ ++;
        if (receive_count_ != 1) return;

        // A native proxy is already loaded before contact. Reply immediately;
        // reporting over Serial here would only consume the Color timing window.
        if (custom_profile_) return;

        // Color only needs version and species for the probability lookup.
        // Keeping this query compact saves about 25 ms at 9600 baud, inside
        // the device's 100 ms reply window.
        serial_.print(F("alpha:q:"));
        printHex(serial_, data[3], 4);
        printHex(serial_, data[4], 4);
        serial_.println();
        serial_.flush();
        // Do not transmit diagnostics while the timing-sensitive reply starts.
        if (!custom_profile_) web_wins_ = readDecision(serial_, false);
    }

private:
    Stream& serial_;
    WordsCore core_;
    char profile_ = '4';
    bool web_wins_ = false;
    bool custom_profile_ = false;
    uint8_t block_index_ = 0;
    uint8_t receive_count_ = 0;
    uint16_t custom_words_[4] = {0, 0, 0, 0};
};

AlphaClassicDigiROM alpha_classic = AlphaClassicDigiROM(Serial);
AlphaColorDigiROM alpha_color = AlphaColorDigiROM(Serial);

bool alphaCommandPending() {
    if (Serial.available() == 0) return false;
    int value = Serial.peek();
    return value == '1' || value == 'A' || value == 'a' || value == 'B' || value == 'b';
}

int8_t hexNibble(char value) {
    if (value >= '0' && value <= '9') return value - '0';
    if (value >= 'A' && value <= 'F') return value - 'A' + 10;
    if (value >= 'a' && value <= 'f') return value - 'a' + 10;
    return -1;
}

bool parseHexWord(const char* text, uint16_t& result) {
    result = 0;
    for (uint8_t i = 0; i < 4; i ++) {
        int8_t nibble = hexNibble(text[i]);
        if (nibble < 0) return false;
        result = (result << 4) | nibble;
    }
    return true;
}

char consumeAlphaCommand(bool& legacy, bool& custom_color, uint16_t custom_words[]) {
    legacy = false;
    custom_color = false;
    char profile = 0;
    char command[28];
    uint8_t length = 0;
    uint32_t started = millis();
    while (millis() - started < 100) {
        if (Serial.available() == 0) continue;
        int value = Serial.read();
        if (value == '\r' || value == '\n') break;
        if (length < sizeof(command) - 1) command[length ++] = (char)value;
    }
    command[length] = 0;
    while (Serial.available() > 0 && (Serial.peek() == '\r' || Serial.peek() == '\n')) Serial.read();
    if (length == 1 && command[0] == '1') {
        legacy = true;
        return '1';
    }
    bool alpha_a = command[0] == 'A' || command[0] == 'a';
    bool alpha_b = command[0] == 'B' || command[0] == 'b';
    if (length < 2 || (!alpha_a && !alpha_b) || command[1] < '0' || command[1] > '9') {
        return 0;
    }
    if (alpha_b) {
        if (command[1] == '0') return 'C';
        if (command[1] == '1') return 'M';
        return 0;
    }
    profile = command[1];
    if (length == 22 && command[2] == ':' && command[7] == ':' && command[12] == ':' && command[17] == ':') {
        custom_color = parseHexWord(command + 3, custom_words[0])
            && parseHexWord(command + 8, custom_words[1])
            && parseHexWord(command + 13, custom_words[2])
            && parseHexWord(command + 18, custom_words[3]);
    }
    return profile;
}

void setup() {
    Serial.begin(kDefaultSerialBaud);
    controller.add(classic_comm);
    controller.add(color_comm);
    serial_follower.setIndicator(led);
    serial_follower.setProngTester(prong_tester);
}

void loop() {
    if (!alphaCommandPending()) {
        serial_follower.loop();
        return;
    }

    bool legacy = false;
    bool custom_color = false;
    uint16_t custom_words[4] = {0, 0, 0, 0};
    char profile = consumeAlphaCommand(legacy, custom_color, custom_words);
    bool classic_profile = (profile >= '0' && profile <= '3') || profile == 'C' || profile == 'M';
    bool color_profile = profile >= '4' && profile <= '9';
    if (!classic_profile && !color_profile) {
        Serial.println(F("alpha:error:unknown-profile"));
        return;
    }

    bool fast_color_serial = color_profile && !custom_color;
    if (classic_profile) {
        Serial.print(F("alpha:armed:family-battle-v12:"));
        Serial.println(profile);
        Serial.flush();
        bool go_first = legacy || profile == '2' || profile == 'C';
        alpha_classic.configure(profile, go_first, profile == '0' && custom_color, custom_words);
        if (go_first) delay(DMCOMM_GOFIRST_BEFORE_MILLIS);
        controller.execute(alpha_classic);
        alpha_classic.printResult(Serial);
    } else {
        // Weighted legacy Color profiles still need a host decision. Native
        // proxies are preloaded, stay at 9600 and answer without host latency.
        if (fast_color_serial) {
            Serial.println(F("alpha:switch-baud:115200"));
            Serial.flush();
            Serial.end();
            Serial.begin(kColorAlphaSerialBaud);
            delay(80);
        }
        Serial.print(F("alpha:armed:family-battle-v12:"));
        Serial.println(profile);
        Serial.flush();
        alpha_color.configure(profile, custom_color, custom_words);
        controller.execute(alpha_color);
        alpha_color.printResult(Serial);
    }
    Serial.println();
    Serial.println(F("alpha:done:default-mode"));
    Serial.flush();
    if (fast_color_serial) {
        Serial.end();
        Serial.begin(kDefaultSerialBaud);
    }
}
